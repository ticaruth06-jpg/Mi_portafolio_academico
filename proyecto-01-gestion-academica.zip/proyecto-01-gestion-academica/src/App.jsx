import { useState } from 'react'
import Sidebar from './components/Sidebar.jsx'
import Panel from './pages/Panel.jsx'
import Estudiantes from './pages/Estudiantes.jsx'
import Calificaciones from './pages/Calificaciones.jsx'
import { initialStudents } from './data/initialStudents.js'

const TITULOS = { panel: 'Panel general', estudiantes: 'Estudiantes', calificaciones: 'Calificaciones' }

export default function App() {
  // Estado principal: los datos viven en memoria y se pierden al recargar.
  const [students, setStudents] = useState(initialStudents)
  const [view, setView] = useState('panel')
  const [activity, setActivity] = useState([])

  const log = (texto) =>
    setActivity((prev) => [{ id: Date.now() + Math.random(), texto, hora: new Date() }, ...prev].slice(0, 5))

  const addStudent = (data) => {
    const nuevo = { ...data, id: Date.now(), notas: [] }
    setStudents((prev) => [...prev, nuevo])
    log(`Nuevo estudiante registrado: ${data.nombres} ${data.apellidos}`)
    return nuevo
  }

  // map() devuelve un arreglo nuevo: no se muta el estado (inmutabilidad).
  const updateStudent = (id, data) => {
    setStudents((prev) => prev.map((s) => (s.id === id ? { ...s, ...data } : s)))
    log(`Datos actualizados: ${data.nombres} ${data.apellidos}`)
  }

  const deleteStudent = (id) => {
    const s = students.find((x) => x.id === id)
    setStudents((prev) => prev.filter((x) => x.id !== id))
    if (s) log(`Estudiante eliminado: ${s.nombres} ${s.apellidos}`)
  }

  const addGrade = (id, nota) => {
    const s = students.find((x) => x.id === id)
    setStudents((prev) => prev.map((x) => (x.id === id ? { ...x, notas: [...x.notas, nota] } : x)))
    if (s) log(`Calificación registrada: ${s.nombres} ${s.apellidos} · ${nota}`)
  }

  const common = { students, activity, goTo: setView }

  return (
    <div className="shell">
      <Sidebar view={view} onChange={setView} />
      <div className="main">
        <header className="topbar">
          <nav className="crumbs">
            <span>Espacio académico</span>
            <span className="sep">›</span>
            <strong>{TITULOS[view]}</strong>
          </nav>
          <div className="topbar-right">
            <span className="period">2026 · Segundo semestre</span>
            <div className="user">
              <span className="avatar sm">LM</span>
              <div>
                <b>Lucía Martínez</b>
                <small>Administradora</small>
              </div>
            </div>
          </div>
        </header>
        <main className="content">
          {view === 'panel' && <Panel {...common} />}
          {view === 'estudiantes' && (
            <Estudiantes {...common} onAdd={addStudent} onUpdate={updateStudent} onDelete={deleteStudent} />
          )}
          {view === 'calificaciones' && <Calificaciones {...common} onAddGrade={addGrade} />}
        </main>
      </div>
    </div>
  )
}
