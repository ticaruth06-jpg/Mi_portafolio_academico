export const initialStudents = [
  { id: 1, codigo: 'EST-001', nombres: 'Ana', apellidos: 'García', carrera: 'Ingeniería de Sistemas', notas: [18, 18.8, 18.4] },
  { id: 2, codigo: 'EST-002', nombres: 'Carlos', apellidos: 'Mendoza', carrera: 'Ingeniería de Sistemas', notas: [16.4, 17.2, 18] },
  { id: 3, codigo: 'EST-003', nombres: 'Valentina', apellidos: 'Ríos', carrera: 'Administración', notas: [17, 18, 18.4] },
  { id: 4, codigo: 'EST-004', nombres: 'Diego', apellidos: 'Ramírez', carrera: 'Contabilidad', notas: [10, 10.8, 11.6] },
  { id: 5, codigo: 'EST-005', nombres: 'Sofía', apellidos: 'Herrera', carrera: 'Administración', notas: [18.6, 19, 19.4] },
  { id: 6, codigo: 'EST-006', nombres: 'Camila', apellidos: 'López', carrera: 'Derecho', notas: [11, 11.4, 11.8] },
  { id: 7, codigo: 'EST-007', nombres: 'Mateo', apellidos: 'Torres', carrera: 'Derecho', notas: [11.2, 11.6, 12.2] },
  { id: 8, codigo: 'EST-008', nombres: 'Isabella', apellidos: 'Cruz', carrera: 'Contabilidad', notas: [17, 17.4, 17.8] },
  { id: 9, codigo: 'EST-009', nombres: 'Emilia', apellidos: 'Vargas', carrera: 'Ingeniería de Sistemas', notas: [16, 16.8, 17.6] },
  { id: 10, codigo: 'EST-010', nombres: 'Gabriel', apellidos: 'Ruiz', carrera: 'Administración', notas: [14, 15, 16] },
]

export const carreras = ['Ingeniería de Sistemas', 'Administración', 'Contabilidad', 'Derecho']
