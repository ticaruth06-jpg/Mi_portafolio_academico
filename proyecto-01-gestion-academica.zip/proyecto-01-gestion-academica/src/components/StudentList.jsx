import StudentItem from './StudentItem.jsx'

export default function StudentList({ students, selectedId, onSelect, onDelete }) {
  if (students.length === 0) {
    return <p className="empty">No hay estudiantes que coincidan. Prueba con otro nombre o código, o registra uno nuevo.</p>
  }
  return (
    <div className="table-wrap">
      <table className="table">
        <thead>
          <tr><th>Estudiante</th><th>Carrera</th><th>Promedio</th><th>Rendimiento</th><th /></tr>
        </thead>
        <tbody>
          {students.map((s) => (
            <StudentItem key={s.id} student={s} selected={s.id === selectedId} onSelect={onSelect} onDelete={onDelete} />
          ))}
        </tbody>
      </table>
    </div>
  )
}
