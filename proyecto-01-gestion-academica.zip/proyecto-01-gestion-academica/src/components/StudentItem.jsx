import { Pencil, Trash2 } from 'lucide-react'
import { promedio, nivel, fmt, iniciales, ETIQUETAS } from '../utils/grades.js'

export default function StudentItem({ student, selected, onSelect, onDelete }) {
  const prom = promedio(student.notas)
  const n = nivel(prom)
  return (
    <tr className={selected ? 'selected' : ''} onClick={() => onSelect(student.id)}>
      <td>
        <div className="person">
          <span className="avatar">{iniciales(student)}</span>
          <div>
            <b>{student.nombres} {student.apellidos}</b>
            <small>{student.codigo}</small>
          </div>
        </div>
      </td>
      <td className="muted">{student.carrera}</td>
      <td><span className={`score ${n}`}>{fmt(prom)}</span></td>
      <td><span className={`pill ${n}`}>● {ETIQUETAS[n]}</span></td>
      <td className="row-actions">
        <button className="icon-btn" title="Editar" aria-label="Editar" onClick={(e) => { e.stopPropagation(); onSelect(student.id) }}>
          <Pencil size={15} />
        </button>
        <button className="icon-btn danger" title="Eliminar" aria-label="Eliminar" onClick={(e) => { e.stopPropagation(); onDelete(student) }}>
          <Trash2 size={15} />
        </button>
      </td>
    </tr>
  )
}
