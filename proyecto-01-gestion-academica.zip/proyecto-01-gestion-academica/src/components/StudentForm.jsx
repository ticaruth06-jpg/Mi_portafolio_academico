import { useEffect, useState } from 'react'
import { Check, Lock, Trash2, X } from 'lucide-react'
import { carreras } from '../data/initialStudents.js'
import { iniciales, promedio, fmt, nivel, ETIQUETAS } from '../utils/grades.js'

const VACIO = { codigo: '', nombres: '', apellidos: '', carrera: '' }

// Registra (RF01) o edita (RF04). Valida los campos obligatorios (RNF02).
export default function StudentForm({ student, students, onSave, onCancel, onDelete }) {
  const editando = Boolean(student)
  const [form, setForm] = useState(VACIO)
  const [errores, setErrores] = useState({})

  useEffect(() => {
    setForm(student ? { codigo: student.codigo, nombres: student.nombres, apellidos: student.apellidos, carrera: student.carrera } : VACIO)
    setErrores({})
  }, [student])

  const set = (campo) => (e) => setForm((f) => ({ ...f, [campo]: e.target.value }))

  const validar = () => {
    const err = {}
    const codigo = form.codigo.trim().toUpperCase()
    if (!codigo) err.codigo = 'Ingresa el código del estudiante.'
    else if (!editando && students.some((s) => s.codigo === codigo)) err.codigo = 'Ese código ya está registrado.'
    if (!form.nombres.trim()) err.nombres = 'Ingresa los nombres.'
    if (!form.apellidos.trim()) err.apellidos = 'Ingresa los apellidos.'
    if (!form.carrera) err.carrera = 'Selecciona una carrera.'
    setErrores(err)
    return Object.keys(err).length === 0
  }

  const submit = (e) => {
    e.preventDefault()
    if (!validar()) return
    onSave({
      codigo: form.codigo.trim().toUpperCase(),
      nombres: form.nombres.trim(),
      apellidos: form.apellidos.trim(),
      carrera: form.carrera,
    })
  }

  const prom = editando ? promedio(student.notas) : null
  const n = nivel(prom)

  return (
    <form className="card side-form" onSubmit={submit} noValidate>
      <div className="side-head">
        <h3>{editando ? 'Ficha del estudiante' : 'Nuevo estudiante'}</h3>
        {editando && <button type="button" className="icon-btn" onClick={onCancel} aria-label="Cerrar"><X size={16} /></button>}
      </div>

      {editando && (
        <>
          <div className="person big">
            <span className="avatar lg">{iniciales(student)}</span>
            <div><b>{student.nombres} {student.apellidos}</b><small>{student.codigo}</small></div>
          </div>
          <div className={`mini-score ${n}`}>
            <div><small>Promedio general</small><strong>{fmt(prom)}</strong></div>
            <div className="right"><span className={`pill ${n}`}>● {ETIQUETAS[n]}</span><small>{student.notas.length} calificaciones</small></div>
          </div>
        </>
      )}

      <label className="field">
        <span>Código del estudiante *</span>
        <div className="with-icon">
          <input value={form.codigo} onChange={set('codigo')} disabled={editando} placeholder="EST-011" />
          {editando && <Lock size={15} />}
        </div>
        {errores.codigo && <em className="error">{errores.codigo}</em>}
      </label>

      <div className="two">
        <label className="field">
          <span>Nombres *</span>
          <input value={form.nombres} onChange={set('nombres')} />
          {errores.nombres && <em className="error">{errores.nombres}</em>}
        </label>
        <label className="field">
          <span>Apellidos *</span>
          <input value={form.apellidos} onChange={set('apellidos')} />
          {errores.apellidos && <em className="error">{errores.apellidos}</em>}
        </label>
      </div>

      <label className="field">
        <span>Carrera *</span>
        <select value={form.carrera} onChange={set('carrera')}>
          <option value="">Seleccionar carrera</option>
          {carreras.map((c) => <option key={c}>{c}</option>)}
        </select>
        {errores.carrera && <em className="error">{errores.carrera}</em>}
      </label>

      <div className="btn-row">
        <button type="button" className="btn" onClick={onCancel}>Cancelar</button>
        <button type="submit" className="btn primary"><Check size={16} /> {editando ? 'Guardar cambios' : 'Registrar estudiante'}</button>
      </div>
      {editando && (
        <button type="button" className="link-danger" onClick={() => onDelete(student)}>
          <Trash2 size={14} /> Eliminar estudiante
        </button>
      )}
    </form>
  )
}
