import { GraduationCap, LayoutGrid, Users, NotebookPen } from 'lucide-react'

const ITEMS = [
  { id: 'panel', label: 'Panel general', icon: LayoutGrid },
  { id: 'estudiantes', label: 'Estudiantes', icon: Users },
  { id: 'calificaciones', label: 'Calificaciones', icon: NotebookPen },
]

export default function Sidebar({ view, onChange }) {
  return (
    <aside className="sidebar">
      <div className="brand">
        <span className="brand-mark"><GraduationCap size={20} /></span>
        <span className="brand-name">aula</span>
        <small>/ ACADÉMICO</small>
      </div>
      <div className="workspace">
        <b>Instituto Horizonte</b>
        <small>Gestión académica</small>
      </div>
      <p className="nav-label">GESTIÓN ACADÉMICA</p>
      <nav>
        {ITEMS.map(({ id, label, icon: Icon }) => (
          <button key={id} className={`nav-item ${view === id ? 'active' : ''}`} onClick={() => onChange(id)}>
            <Icon size={18} />
            <span>{label}</span>
            {view === id && <i className="dot" />}
          </button>
        ))}
      </nav>
      <div className="period-card">
        <small>● PERÍODO EN CURSO</small>
        <b>Segundo semestre</b>
        <small>Ago — Dic 2026</small>
        <div className="bar"><i style={{ width: '61%' }} /></div>
        <small>Semana 11 de 18</small>
      </div>
    </aside>
  )
}
