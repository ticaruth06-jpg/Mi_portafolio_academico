import { Users, TrendingUp, CheckCircle2, HeartPulse } from 'lucide-react'
import { promedio, nivel, fmt } from '../utils/grades.js'

// Indicadores generales (RF07: promedio general calculado con reduce()).
export default function StudentSummary({ students }) {
  const promedios = students.map((s) => promedio(s.notas)).filter((p) => p !== null)
  const general = promedios.length ? promedios.reduce((a, p) => a + p, 0) / promedios.length : null
  const aprobados = promedios.filter((p) => nivel(p) !== 'riesgo').length
  const seguimiento = promedios.length - aprobados
  const pct = promedios.length ? Math.round((aprobados / promedios.length) * 100) : 0

  const cards = [
    { label: 'Estudiantes registrados', value: students.length, note: 'en el período actual', icon: Users },
    { label: 'Promedio general', value: `${fmt(general)} / 20`, note: 'sobre estudiantes con notas', icon: TrendingUp },
    { label: 'Estudiantes aprobados', value: `${pct} %`, note: `${aprobados} de ${promedios.length} con notas`, icon: CheckCircle2 },
    { label: 'Requieren acompañamiento', value: seguimiento, note: 'con promedio menor a 12', icon: HeartPulse },
  ]
  return (
    <div className="stats">
      {cards.map(({ label, value, note, icon: Icon }) => (
        <div className="card stat" key={label}>
          <div className="stat-top"><span>{label}</span><Icon size={18} /></div>
          <strong>{value}</strong>
          <small>{note}</small>
        </div>
      ))}
    </div>
  )
}
