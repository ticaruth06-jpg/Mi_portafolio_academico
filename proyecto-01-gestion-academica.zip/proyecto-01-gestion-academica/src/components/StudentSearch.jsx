import { Search } from 'lucide-react'

export default function StudentSearch({ value, onChange }) {
  return (
    <label className="search">
      <input
        type="search"
        value={value}
        placeholder="Buscar por nombre o código…"
        onChange={(e) => onChange(e.target.value)}
      />
      <Search size={16} />
    </label>
  )
}
