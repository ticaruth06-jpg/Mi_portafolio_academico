// Escala vigente: 0 a 20 (RF06). Los umbrales se centralizan aquí.
export const NOTA_MAX = 20
export const UMBRAL_APROBADO = 12
export const UMBRAL_DESTACADO = 18

export const promedio = (notas) =>
  notas.length === 0 ? null : notas.reduce((acc, n) => acc + n, 0) / notas.length

export const nivel = (prom) => {
  if (prom === null) return 'sin'
  if (prom >= UMBRAL_DESTACADO) return 'destacado'
  if (prom >= UMBRAL_APROBADO) return 'aprobado'
  return 'riesgo'
}

export const ETIQUETAS = {
  destacado: 'Destacado',
  aprobado: 'Aprobado',
  riesgo: 'En riesgo',
  sin: 'Sin notas',
}

export const fmt = (n) => (n === null ? '—' : n.toFixed(1))
export const iniciales = (s) => `${s.nombres[0] ?? ''}${s.apellidos[0] ?? ''}`.toUpperCase()
