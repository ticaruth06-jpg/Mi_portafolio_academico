import { useMemo, useState } from 'react'
import { Plus } from 'lucide-react'
import PageHeader from '../components/PageHeader.jsx'
import StudentSummary from '../components/StudentSummary.jsx'
import StudentSearch from '../components/StudentSearch.jsx'
import StudentList from '../components/StudentList.jsx'
import StudentForm from '../components/StudentForm.jsx'

export default function Estudiantes({ students, onAdd, onUpdate, onDelete }) {
  const [busqueda, setBusqueda] = useState('')
  const [selectedId, setSelectedId] = useState(null)

  // RF03: filter() por código o nombre completo.
  const visibles = useMemo(() => {
    const q = busqueda.trim().toLowerCase()
    if (!q) return students
    return students.filter((s) => `${s.codigo} ${s.nombres} ${s.apellidos}`.toLowerCase().includes(q))
  }, [students, busqueda])

  // find() devuelve un único estudiante: el que se está editando.
  const seleccionado = students.find((s) => s.id === selectedId) ?? null

  const guardar = (data) => {
    if (seleccionado) onUpdate(seleccionado.id, data)
    else setSelectedId(onAdd(data).id)
  }

  const eliminar = (s) => {
    if (!window.confirm(`¿Eliminar a ${s.nombres} ${s.apellidos}? Esta acción no se puede deshacer.`)) return
    onDelete(s.id)
    if (s.id === selectedId) setSelectedId(null)
  }

  return (
    <>
      <PageHeader
        eyebrow="COMUNIDAD ACADÉMICA"
        title="Estudiantes"
        subtitle="Un lugar para conocer, organizar y acompañar a cada estudiante."
      >
        <button className="btn primary" onClick={() => setSelectedId(null)}><Plus size={16} /> Nuevo estudiante</button>
      </PageHeader>

      <StudentSummary students={students} />

      <div className="split">
        <section className="card">
          <div className="card-head">
            <h3>Directorio de estudiantes <span className="chip">{visibles.length}</span></h3>
          </div>
          <StudentSearch value={busqueda} onChange={setBusqueda} />
          <StudentList students={visibles} selectedId={selectedId} onSelect={setSelectedId} onDelete={eliminar} />
        </section>
        <StudentForm
          student={seleccionado}
          students={students}
          onSave={guardar}
          onCancel={() => setSelectedId(null)}
          onDelete={eliminar}
        />
      </div>
    </>
  )
}
