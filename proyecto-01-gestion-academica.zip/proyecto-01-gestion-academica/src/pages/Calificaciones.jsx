import { useState } from 'react'
import { Check, Pencil, PlusCircle } from 'lucide-react'
import PageHeader from '../components/PageHeader.jsx'
import { NOTA_MAX, promedio, nivel, fmt, iniciales, ETIQUETAS } from '../utils/grades.js'

export default function Calificaciones({ students, onAddGrade }) {
  const [studentId, setStudentId] = useState('')
  const [nota, setNota] = useState('')
  const [error, setError] = useState('')

  const columnas = Math.max(3, ...students.map((s) => s.notas.length))
  const conteo = { destacado: 0, aprobado: 0, riesgo: 0 }
  students.forEach((s) => { const n = nivel(promedio(s.notas)); if (n in conteo) conteo[n] += 1 })
  const total = Math.max(1, conteo.destacado + conteo.aprobado + conteo.riesgo)

  const elegido = students.find((s) => s.id === Number(studentId))

  // RF06: la calificación debe estar entre 0 y 20.
  const guardar = (e) => {
    e.preventDefault()
    const valor = Number(nota)
    if (!elegido) return setError('Selecciona un estudiante.')
    if (nota.trim() === '' || Number.isNaN(valor)) return setError('Ingresa una calificación numérica.')
    if (valor < 0 || valor > NOTA_MAX) return setError(`La calificación debe estar entre 0 y ${NOTA_MAX}.`)
    onAddGrade(elegido.id, Math.round(valor * 10) / 10)
    setNota('')
    setError('')
  }

  return (
    <>
      <PageHeader
        eyebrow="DEL DATO AL ACOMPAÑAMIENTO"
        title="Calificaciones y rendimiento"
        subtitle="Registra notas, consulta promedios y descubre dónde impulsar el aprendizaje."
      />

      <div className="split">
        <section className="card">
          <div className="card-head"><h3>Libro de calificaciones</h3><small className="muted">{students.length} estudiantes · Notas de 0 a {NOTA_MAX}</small></div>
          <div className="table-wrap">
            <table className="table grades">
              <thead>
                <tr>
                  <th>Estudiante</th>
                  {Array.from({ length: columnas }, (_, i) => <th key={i} className="num">Nota {i + 1}</th>)}
                  <th className="num">Promedio</th><th>Rendimiento</th><th />
                </tr>
              </thead>
              <tbody>
                {students.map((s) => {
                  const prom = promedio(s.notas)
                  const n = nivel(prom)
                  return (
                    <tr key={s.id}>
                      <td>
                        <div className="person"><span className="avatar">{iniciales(s)}</span>
                          <div><b>{s.nombres} {s.apellidos}</b><small>{s.codigo}</small></div></div>
                      </td>
                      {Array.from({ length: columnas }, (_, i) => <td key={i} className="num">{s.notas[i] !== undefined ? s.notas[i].toFixed(1) : '—'}</td>)}
                      <td className="num"><span className={`score ${n}`}>{fmt(prom)}</span></td>
                      <td><span className={`pill ${n}`}>● {ETIQUETAS[n]}</span></td>
                      <td><button className="icon-btn" aria-label="Registrar nota" onClick={() => { setStudentId(String(s.id)); setError('') }}><Pencil size={15} /></button></td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </section>

        <aside className="card dist">
          <h3>Cada resultado, una historia</h3>
          <small className="muted">Distribución de promedios</small>
          <div className="stack">
            <i className="destacado" style={{ flex: conteo.destacado }} />
            <i className="aprobado" style={{ flex: conteo.aprobado }} />
            <i className="riesgo" style={{ flex: conteo.riesgo }} />
          </div>
          <ul>
            <li><span><i className="sq destacado" /> Destacado <small>18–20</small></span><b>{conteo.destacado}</b></li>
            <li><span><i className="sq aprobado" /> Aprobado <small>12–17.9</small></span><b>{conteo.aprobado}</b></li>
            <li><span><i className="sq riesgo" /> En riesgo <small>0–11.9</small></span><b>{conteo.riesgo}</b></li>
          </ul>
          <small className="muted">{Math.round(((total - conteo.riesgo) / total) * 100)} % del grupo aprobado</small>
        </aside>
      </div>

      <form className="card grade-form" onSubmit={guardar} noValidate>
        <h3><PlusCircle size={18} /> Registrar una calificación</h3>
        <div className="grade-fields">
          <label className="field"><span>Estudiante</span>
            <select value={studentId} onChange={(e) => { setStudentId(e.target.value); setError('') }}>
              <option value="">Seleccionar estudiante</option>
              {students.map((s) => <option key={s.id} value={s.id}>{s.codigo} · {s.nombres} {s.apellidos}</option>)}
            </select>
          </label>
          <label className="field"><span>Evaluación</span>
            <input disabled value={elegido ? `Nota ${elegido.notas.length + 1}` : '—'} />
          </label>
          <label className="field"><span>Calificación</span>
            <input inputMode="decimal" placeholder={`0.0 – ${NOTA_MAX}.0`} value={nota} onChange={(e) => setNota(e.target.value)} />
          </label>
          <button className="btn primary" type="submit"><Check size={16} /> Guardar calificación</button>
        </div>
        {error && <em className="error">{error}</em>}
        <small className="muted">El promedio se calcula automáticamente con las notas registradas.</small>
      </form>
    </>
  )
}
