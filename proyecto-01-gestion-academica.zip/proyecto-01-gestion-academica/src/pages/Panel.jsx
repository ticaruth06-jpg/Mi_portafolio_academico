import { Plus } from 'lucide-react'
import PageHeader from '../components/PageHeader.jsx'
import StudentSummary from '../components/StudentSummary.jsx'
import { promedio, nivel, fmt, iniciales } from '../utils/grades.js'
import { carreras } from '../data/initialStudents.js'

function Evolucion({ students }) {
  // Promedio del grupo por cada evaluación (Nota 1, 2, 3…), calculado con reduce().
  const max = Math.max(3, ...students.map((s) => s.notas.length))
  const puntos = Array.from({ length: max }, (_, i) => {
    const notas = students.map((s) => s.notas[i]).filter((n) => n !== undefined)
    return notas.length ? notas.reduce((a, n) => a + n, 0) / notas.length : null
  })
  const W = 640, H = 200, P = 36
  const x = (i) => P + (i * (W - 2 * P)) / Math.max(1, max - 1)
  const y = (v) => H - P - ((v - 10) / 10) * (H - 2 * P)
  const validos = puntos.map((v, i) => (v === null ? null : [x(i), y(v), v])).filter(Boolean)
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="chart" role="img" aria-label="Promedio del grupo por evaluación">
      {[10, 12.5, 15, 17.5, 20].map((v) => (
        <g key={v}><line x1={P} x2={W - P} y1={y(v)} y2={y(v)} className="grid" /><text x={4} y={y(v) + 4}>{v}</text></g>
      ))}
      <polyline fill="none" className="line" points={validos.map(([a, b]) => `${a},${b}`).join(' ')} />
      {validos.map(([a, b, v], i) => (
        <g key={i}><circle cx={a} cy={b} r="4" className="pt" /><text x={a} y={b - 10} textAnchor="middle" className="val">{v.toFixed(1)}</text>
          <text x={a} y={H - 8} textAnchor="middle">Nota {i + 1}</text></g>
      ))}
    </svg>
  )
}

export default function Panel({ students, activity, goTo }) {
  const enSeguimiento = students.filter((s) => nivel(promedio(s.notas)) === 'riesgo')
  const porCarrera = carreras.map((c) => {
    const proms = students.filter((s) => s.carrera === c).map((s) => promedio(s.notas)).filter((p) => p !== null)
    return { c, prom: proms.length ? proms.reduce((a, p) => a + p, 0) / proms.length : null }
  }).filter((x) => x.prom !== null).sort((a, b) => b.prom - a.prom)

  return (
    <>
      <PageHeader eyebrow="UNA MIRADA A TU INSTITUCIÓN" title="Cada avance cuenta." subtitle="Este es el pulso académico de Horizonte.">
        <button className="btn primary" onClick={() => goTo('estudiantes')}><Plus size={16} /> Registrar estudiante</button>
      </PageHeader>
      <StudentSummary students={students} />
      <div className="split">
        <section className="card">
          <h3>Evolución del promedio</h3>
          <small className="muted">Promedio del grupo por evaluación · escala de 0 a 20</small>
          <Evolucion students={students} />
        </section>
        <aside className="card">
          <h3>Por carrera</h3>
          <small className="muted">Promedios del período actual</small>
          <ul className="bars">
            {porCarrera.map(({ c, prom }) => (
              <li key={c}><div><span>{c}</span><b>{fmt(prom)}</b></div><div className="track"><i style={{ width: `${(prom / 20) * 100}%` }} /></div></li>
            ))}
          </ul>
        </aside>
      </div>
      <div className="split">
        <section className="card">
          <div className="card-head"><h3>La atención marca la diferencia</h3><span className="chip warn">{enSeguimiento.length} en seguimiento</span></div>
          <small className="muted">Estudiantes con promedio inferior a 12. Un buen momento para acompañar.</small>
          {enSeguimiento.length === 0 && <p className="empty">Nadie necesita seguimiento por ahora.</p>}
          <ul className="follow">
            {enSeguimiento.map((s) => (
              <li key={s.id}>
                <div className="person"><span className="avatar">{iniciales(s)}</span><div><b>{s.nombres} {s.apellidos}</b><small>{s.carrera}</small></div></div>
                <span className="score riesgo">{fmt(promedio(s.notas))}</span>
              </li>
            ))}
          </ul>
        </section>
        <aside className="card">
          <h3>Actividad reciente</h3>
          {activity.length === 0 && <p className="empty">Aún no hay movimientos. Registra un estudiante o una nota.</p>}
          <ul className="activity">
            {activity.map((a) => (
              <li key={a.id}><b>{a.texto}</b><small>{a.hora.toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit' })}</small></li>
            ))}
          </ul>
        </aside>
      </div>
    </>
  )
}
