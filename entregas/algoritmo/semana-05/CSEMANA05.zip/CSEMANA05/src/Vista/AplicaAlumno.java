package Vista;

import DAO.DAOAlumno;
import Modelo.Alumno;
import java.util.ArrayList;
import java.util.Scanner;

public class AplicaAlumno {

    // Scanner para ingresar datos
    static Scanner teclado = new Scanner(System.in);

    // Objeto DAO
    static DAOAlumno dao = new DAOAlumno();

    public static void main(String[] args) {

        menu();
    }

    // =====================================================
    // MÉTODO MENU
    // =====================================================
    public static void menu() {

        int op;

        do {

            System.out.println("\n\tMenu de Opciones");
            System.out.println("==============================");
            System.out.println("[1] Ingresar Datos del Alumno");
            System.out.println("[2] Listar Datos de los Alumnos");
            System.out.println("[3] Buscar Datos del Alumno");
            System.out.println("[4] Modificar Datos del Alumno");
            System.out.println("[5] Eliminar Alumno");
            System.out.println("[6]  Buscar Alumno por Nombre");
            System.out.println("[7]  Listar Alumnos por Carrera");
            System.out.println("[8]  Ordenar por Apellidos");
            System.out.println("[9]  Ordenar por Edad");
            System.out.println("[10] Invertir Lista");
            System.out.println("[11] Mostrar Primer Alumno");
            System.out.println("[12] Mostrar Ultimo Alumno");
            System.out.println("[13] Eliminar por Carrera");
            System.out.println("[14] Contar Alumnos por Carrera");
            System.out.println("[15] Mostrar Rango de Alumnos");
            System.out.println("[16] Salir");
            System.out.println("==============================");
            System.out.print("Ingrese una opcion: ");

            op = teclado.nextInt();
            teclado.nextLine();

            switch (op) {

                case 1:
                    ingresarAlumno();
                    break;

                case 2:
                    listarAlumnos();
                    break;

                case 3:
                    buscarAlumno();
                    break;

                case 4:
                    modificarAlumno();
                    break;

                case 5:
                    eliminarAlumno();
                    break;
                    
                 case 6:
                    buscarPorNombre();
                    break;

                case 7:
                    listarPorCarrera();
                    break;

                case 8:
                    ordenarPorApellidos();
                    break;

                case 9:
                    ordenarPorEdad();
                    break;

                case 10:
                    invertirLista();
                    break;

                case 11:
                    mostrarPrimerAlumno();
                    break;

                case 12:
                    mostrarUltimoAlumno();
                    break;

                case 13:
                    eliminarPorCarrera();
                    break;

                case 14:
                    contarPorCarrera();
                    break;

                case 15:
                    mostrarRangoAlumnos();
                    break;

                case 16:
                    System.out.println("\nPrograma finalizado...");
                    break;

                default:
                    System.out.println("\nOpción incorrecta.");
            }

        } while (op != 16);
    }
    // =====================================================
    // 1. INGRESAR ALUMNO
    // =====================================================
    public static void ingresarAlumno() {

        System.out.println("\n===== INGRESAR DATOS DEL ALUMNO =====");

        System.out.print("Ingrese codigo: ");
        int codigo = teclado.nextInt();
        teclado.nextLine();

        // Verificar que el código no exista
        if (dao.buscar(codigo) != null) {
            System.out.println("El codigo ya existe.");
            return;
        }

        System.out.print("Ingrese nombres: ");
        String nombres = teclado.nextLine();

        System.out.print("Ingrese apellidos: ");
        String apellidos = teclado.nextLine();

        System.out.print("Ingrese edad: ");
        int edad = teclado.nextInt();
        teclado.nextLine();

        System.out.print("Ingrese carrera: ");
        String carrera = teclado.nextLine();

        // Crear objeto Alumno
        Alumno alumno = new Alumno(
                codigo,
                nombres,
                apellidos,
                edad,
                carrera
        );

        // Agregar mediante DAO
        dao.agregar(alumno);

        System.out.println("\nAlumno registrado correctamente.");
    }

    // =====================================================
    // 2. LISTAR ALUMNOS
    // =====================================================
    public static void listarAlumnos() {

        System.out.println("\n===== LISTADO DE ALUMNOS =====");

        if (!dao.existeAlumnos()) {
            System.out.println("No existen alumnos registrados.");
            return;
        }

        for (Alumno alumno : dao.listar()) {
            System.out.println(alumno);
        }

        System.out.println("\nTotal de alumnos: "
                + dao.cantidadAlumnos());
    }

    // =====================================================
    // 3. BUSCAR ALUMNO
    // =====================================================
    public static void buscarAlumno() {

        System.out.println("\n===== BUSCAR ALUMNO =====");

        System.out.print("Ingrese código del alumno: ");
        int codigo = teclado.nextInt();
        teclado.nextLine();

        Alumno alumno = dao.buscar(codigo);

        if (alumno != null) {

            System.out.println("\nAlumno encontrado:");
            System.out.println(alumno);

        } else {

            System.out.println("\nAlumno no encontrado.");
        }
    }

    // =====================================================
    // 4. MODIFICAR ALUMNO
    // =====================================================
    public static void modificarAlumno() {

        System.out.println("\n===== MODIFICAR ALUMNO =====");

        System.out.print("Ingrese código del alumno: ");
        int codigo = teclado.nextInt();
        teclado.nextLine();

        Alumno alumno = dao.buscar(codigo);

        if (alumno == null) {

            System.out.println("\nAlumno no encontrado.");
            return;
        }

        System.out.println("\nDatos actuales:");
        System.out.println(alumno);

        System.out.println("\nIngrese los nuevos datos:");

        System.out.print("Nombres: ");
        String nombres = teclado.nextLine();

        System.out.print("Apellidos: ");
        String apellidos = teclado.nextLine();

        System.out.print("Edad: ");
        int edad = teclado.nextInt();
        teclado.nextLine();

        System.out.print("Carrera: ");
        String carrera = teclado.nextLine();

        // Crear nuevo objeto
        Alumno alumnoNuevo = new Alumno(
                codigo,
                nombres,
                apellidos,
                edad,
                carrera
        );

        // Modificar
        if (dao.modificar(codigo, alumnoNuevo)) {

            System.out.println("\nAlumno modificado correctamente.");

        } else {

            System.out.println("\nNo se pudo modificar el alumno.");
        }
    }

    // =====================================================
    // 5. ELIMINAR ALUMNO
    // =====================================================
    public static void eliminarAlumno() {

        System.out.println("\n===== ELIMINAR ALUMNO =====");

        System.out.print("Ingrese código del alumno: ");
        int codigo = teclado.nextInt();
        teclado.nextLine();

        // Buscar antes de eliminar
        Alumno alumno = dao.buscar(codigo);

        if (alumno == null) {

            System.out.println("\nAlumno no encontrado.");
            return;
        }

        System.out.println("\nAlumno encontrado:");
        System.out.println(alumno);

        System.out.print("\n¿Está seguro de eliminarlo? (S/N): ");
        String respuesta = teclado.nextLine();

        if (respuesta.equalsIgnoreCase("S")) {

            if (dao.eliminar(codigo)) {
                System.out.println("\nAlumno eliminado correctamente.");
            }

        } else {

            System.out.println("\nOperación cancelada.");
        }
    }

    // =====================================================
    // 6. BUSCAR ALUMNO POR NOMBRE
    // =====================================================
    public static void buscarPorNombre() {

        System.out.println("\n===== BUSCAR ALUMNOS POR NOMBRE =====");

        System.out.print("Ingrese el nombre a buscar: ");
        String nombre = teclado.nextLine();

        ArrayList<Alumno> resultados = dao.buscarPorNombre(nombre);

        if (resultados.isEmpty()) {

            System.out.println("\nNo se encontraron coincidencias.");

        } else {

            System.out.println("\nAlumnos encontrados:");
            for (Alumno alumno : resultados) {
                System.out.println(alumno);
            }
        }
    }

    // =====================================================
    // 7. LISTAR ALUMNOS POR CARRERA
    // =====================================================
    public static void listarPorCarrera() {

        System.out.println("\n===== LISTAR ALUMNOS POR CARRERA =====");

        System.out.print("Ingrese la carrera: ");
        String carrera = teclado.nextLine();

        ArrayList<Alumno> resultados = dao.listarPorCarrera(carrera);

        if (resultados.isEmpty()) {

            System.out.println("\nNo hay alumnos registrados en esta carrera.");

        } else {

            System.out.println("\nAlumnos en " + carrera + ":");
            for (Alumno alumno : resultados) {
                System.out.println(alumno);
            }
        }
    }

    // =====================================================
    // 8. ORDENAR POR APELLIDOS
    // =====================================================
    public static void ordenarPorApellidos() {

        System.out.println("\n===== ORDENAR POR APELLIDOS =====");

        if (!dao.existeAlumnos()) {

            System.out.println("No existen alumnos registrados.");
            return;
        }

        dao.ordenarPorApellidos();
        System.out.println("Lista ordenada por apellidos alfabéticamente.");
    }

    // =====================================================
    // 9. ORDENAR POR EDAD
    // =====================================================
    public static void ordenarPorEdad() {

        System.out.println("\n===== ORDENAR POR EDAD =====");

        if (!dao.existeAlumnos()) {

            System.out.println("No existen alumnos registrados.");
            return;
        }

        dao.ordenarPorEdad();
        System.out.println("Lista ordenada por edad de menor a mayor.");
    }

    // =====================================================
    // 10. INVERTIR LISTA
    // =====================================================
    public static void invertirLista() {

        System.out.println("\n===== INVERTIR LISTA DE ALUMNOS =====");

        if (!dao.existeAlumnos()) {

            System.out.println("No existen alumnos registrados.");
            return;
        }

        dao.invertirLista();
        System.out.println("El orden de la lista ha sido invertido.");
    }

    // =====================================================
    // 11. MOSTRAR PRIMER ALUMNO
    // =====================================================
    public static void mostrarPrimerAlumno() {

        System.out.println("\n===== PRIMER ALUMNO DE LA LISTA =====");

        Alumno alumno = dao.obtenerPrimero();

        if (alumno != null) {

            System.out.println(alumno);

        } else {

            System.out.println("No existen alumnos registrados.");
        }
    }

    // =====================================================
    // 12. MOSTRAR ÚLTIMO ALUMNO
    // =====================================================
    public static void mostrarUltimoAlumno() {

        System.out.println("\n===== ÚLTIMO ALUMNO DE LA LISTA =====");

        Alumno alumno = dao.obtenerUltimo();

        if (alumno != null) {

            System.out.println(alumno);

        } else {

            System.out.println("No existen alumnos registrados.");
        }
    }

    // =====================================================
    // 13. ELIMINAR ALUMNOS POR CARRERA
    // =====================================================
    public static void eliminarPorCarrera() {

        System.out.println("\n===== ELIMINAR ALUMNOS POR CARRERA =====");

        System.out.print("Ingrese la carrera a eliminar: ");
        String carrera = teclado.nextLine();

        System.out.print("¿Está seguro de eliminar todos los alumnos de la carrera " + carrera + "? (S/N): ");
        String respuesta = teclado.nextLine();

        if (respuesta.equalsIgnoreCase("S")) {

            if (dao.eliminarPorCarrera(carrera)) {

                System.out.println("\nAlumnos de la carrera " + carrera + " eliminados correctamente.");

            } else {

                System.out.println("\nNo se encontraron alumnos pertenecientes a esa carrera.");
            }

        } else {

            System.out.println("\nOperación cancelada.");
        }
    }

    // =====================================================
    // 14. CONTAR ALUMNOS POR CARRERA
    // =====================================================
    public static void contarPorCarrera() {

        System.out.println("\n===== CONTAR ALUMNOS POR CARRERA =====");

        System.out.print("Ingrese la carrera: ");
        String carrera = teclado.nextLine();

        int total = dao.contarPorCarrera(carrera);

        System.out.println("\nTotal de alumnos en " + carrera + ": " + total);
    }

    // =====================================================
    // 15. MOSTRAR RANGO DE ALUMNOS
    // =====================================================
    public static void mostrarRangoAlumnos() {

        System.out.println("\n===== MOSTRAR ALUMNOS POR RANGO =====");

        if (!dao.existeAlumnos()) {

            System.out.println("No existen alumnos registrados.");
            return;
        }

        System.out.print("Ingrese posición inicial (1 - " + dao.cantidadAlumnos() + "): ");
        int inicio = teclado.nextInt();

        System.out.print("Ingrese posición final (1 - " + dao.cantidadAlumnos() + "): ");
        int fin = teclado.nextInt();
        teclado.nextLine();

        ArrayList<Alumno> rango = dao.mostrarRango(inicio, fin);

        if (rango.isEmpty()) {

            System.out.println("\nRango inválido.");

        } else {

            System.out.println("\nAlumnos en el rango [" + inicio + " - " + fin + "]:");
            for (Alumno alumno : rango) {
                System.out.println(alumno);
            }
        }
    }
}