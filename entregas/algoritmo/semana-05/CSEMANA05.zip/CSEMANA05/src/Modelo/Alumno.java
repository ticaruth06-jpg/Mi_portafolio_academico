package Modelo;

public class Alumno {

    // Atributos
    private int codigo;
    private String nombres;
    private String apellidos;
    private int edad;
    private String carrera;

    // Constructor vacío
    public Alumno() {
    }

    // Constructor con parámetros
    public Alumno(int codigo, String nombres, String apellidos,
            int edad, String carrera) {
        this.codigo = codigo;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.edad = edad;
        this.carrera = carrera;
    }

    // Getter y Setter de codigo
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    // Getter y Setter de nombres
    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    // Getter y Setter de apellidos
    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    // Getter y Setter de edad
    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    // Getter y Setter de carrera
    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    // Método toString()
    @Override
    public String toString() {
        return "Código: " + codigo
                + " | Nombres: " + nombres
                + " | Apellidos: " + apellidos
                + " | Edad: " + edad
                + " | Carrera: " + carrera;
    }
}
