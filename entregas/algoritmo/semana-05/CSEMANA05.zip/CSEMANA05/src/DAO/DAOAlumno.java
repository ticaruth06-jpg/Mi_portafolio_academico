package DAO;

import Modelo.Alumno;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class DAOAlumno {

    // ArrayList que almacenará los alumnos
    private final ArrayList<Alumno> listaAlumnos;

    // Constructor
    public DAOAlumno() {
        listaAlumnos = new ArrayList<>();
    }

    // ==========================================
    // MÉTODO PARA AGREGAR UN ALUMNO
    // ==========================================
    public void agregar(Alumno alumno) {
        listaAlumnos.add(alumno);
    }

    // ==========================================
    // MÉTODO PARA LISTAR TODOS LOS ALUMNOS
    // ==========================================
    public ArrayList<Alumno> listar() {
        return listaAlumnos;
    }

    // ==========================================
    // MÉTODO PARA BUSCAR POR CÓDIGO
    // ==========================================
    public Alumno buscar(int codigo) {

        for (int i = 0; i < listaAlumnos.size(); i++) {

            Alumno alumno = listaAlumnos.get(i);

            if (alumno.getCodigo() == codigo) {
                return alumno;
            }
        }

        return null;
    }

    // ==========================================
    // MÉTODO PARA MODIFICAR
    // ==========================================
    public boolean modificar(int codigo, Alumno alumnoNuevo) {

        for (int i = 0; i < listaAlumnos.size(); i++) {

            Alumno alumno = listaAlumnos.get(i);

            if (alumno.getCodigo() == codigo) {

                listaAlumnos.set(i, alumnoNuevo);

                return true;
            }
        }

        return false;
    }

    // ==========================================
    // MÉTODO PARA ELIMINAR
    // ==========================================
    public boolean eliminar(int codigo) {

        for (int i = 0; i < listaAlumnos.size(); i++) {

            Alumno alumno = listaAlumnos.get(i);

            if (alumno.getCodigo() == codigo) {

                listaAlumnos.remove(i);

                return true;
            }
        }

        return false;
    }

    // ==========================================
    // MÉTODO PARA SABER SI EXISTEN ALUMNOS
    // ==========================================
    public boolean existeAlumnos() {
        return !listaAlumnos.isEmpty();
    }

    // ==========================================
    // MÉTODO PARA OBTENER CANTIDAD DE ALUMNOS
    // ==========================================
    public int cantidadAlumnos() {
        return listaAlumnos.size();
    }

    // ==========================================
    // 6. BUSCAR ALUMNOS POR NOMBRE
    // ==========================================
    public ArrayList<Alumno> buscarPorNombre(String nombre) {
        ArrayList<Alumno> encontrados = new ArrayList<>();
        for (int i = 0; i < listaAlumnos.size(); i++) {
            Alumno alumno = listaAlumnos.get(i);
            if (alumno.getNombres().toLowerCase().contains(nombre.toLowerCase())) {
                encontrados.add(alumno);
            } else {
            }
        }
        return encontrados;
    }

    // ==========================================
    // 7. LISTAR ALUMNOS POR CARRERA
    // ==========================================
    public ArrayList<Alumno> listarPorCarrera(String carrera) {
        ArrayList<Alumno> porCarrera = new ArrayList<>();
        for (int i = 0; i < listaAlumnos.size(); i++) {
            Alumno alumno = listaAlumnos.get(i);
            if (alumno.getCarrera().equalsIgnoreCase(carrera)) {
                porCarrera.add(alumno);
            }
        }
        return porCarrera;
    }

    // ==========================================
    // 8. ORDENAR POR APELLIDOS ALFABÉTICAMENTE
    // ==========================================
    public void ordenarPorApellidos() {
        Collections.sort(listaAlumnos, new Comparator<Alumno>() {
            @Override
            public int compare(Alumno a1, Alumno a2) {
                return a1.getApellidos().compareToIgnoreCase(a2.getApellidos());
            }
        });
    }

    // ==========================================
    // 9. ORDENAR POR EDAD
    // ==========================================
    public void ordenarPorEdad() {
        Collections.sort(listaAlumnos, new Comparator<Alumno>() {
            @Override
            public int compare(Alumno a1, Alumno a2) {
                return Integer.compare(a1.getEdad(), a2.getEdad());
            }
        });
    }

    // ==========================================
    // 10. INVERTIR ORDEN DE LA LISTA
    // ==========================================
    public void invertirLista() {
        Collections.reverse(listaAlumnos);
    }

    // ==========================================
    // 11. OBTENER PRIMER ALUMNO
    // ==========================================
    public Alumno obtenerPrimero() {
        if (!listaAlumnos.isEmpty()) {
            return listaAlumnos.get(0);
        }
        return null;
    }

    // ==========================================
    // 12. OBTENER ÚLTIMO ALUMNO
    // ==========================================
    public Alumno obtenerUltimo() {
        if (!listaAlumnos.isEmpty()) {
            return listaAlumnos.get(listaAlumnos.size() - 1);
        }
        return null;
    }

    // ==========================================
    // 13. ELIMINAR ALUMNOS POR CARRERA
    // ==========================================
    public boolean eliminarPorCarrera(String carrera) {
        boolean eliminado = false;
        for (int i = listaAlumnos.size() - 1; i >= 0; i--) {
            Alumno alumno = listaAlumnos.get(i);
            if (alumno.getCarrera().equalsIgnoreCase(carrera)) {
                listaAlumnos.remove(i);
                eliminado = true;
            }
        }
        return eliminado;
    }

    // ==========================================
    // 14. CONTAR ALUMNOS POR CARRERA
    // ==========================================
    public int contarPorCarrera(String carrera) {
        int contador = 0;
        for (int i = 0; i < listaAlumnos.size(); i++) {
            Alumno alumno = listaAlumnos.get(i);
            if (alumno.getCarrera().equalsIgnoreCase(carrera)) {
                contador++;
            }
        }
        return contador;
    }

    // ==========================================
    // 15. MOSTRAR ALUMNOS EN UN RANGO DE POSICIONES
    // ==========================================
    public ArrayList<Alumno> mostrarRango(int inicio, int fin) {
        ArrayList<Alumno> rango = new ArrayList<>();
        if (inicio >= 1 && fin <= listaAlumnos.size() && inicio <= fin) {
            for (int i = inicio - 1; i < fin; i++) {
                rango.add(listaAlumnos.get(i));
            }
        }
        return rango;
    }
}