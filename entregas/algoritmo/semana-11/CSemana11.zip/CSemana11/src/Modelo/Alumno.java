package Modelo;

public class Alumno {

    private String codigo;
    private String nombres;
    private String carrera;
    private int semestre;

    public Alumno() {
    }

    public Alumno(String codigo, String nombres,
                  String carrera, int semestre) {
        this.codigo = codigo;
        this.nombres = nombres;
        this.carrera = carrera;
        this.semestre = semestre;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }

    @Override
    public String toString() {
        return "Código: " + codigo
                + " | Nombres: " + nombres
                + " | Carrera: " + carrera
                + " | Semestre: " + semestre;
    }
}
