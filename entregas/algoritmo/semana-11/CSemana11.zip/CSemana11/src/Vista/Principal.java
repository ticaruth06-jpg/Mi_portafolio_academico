package Vista;

import DAO.CListaCircular;
import Modelo.Alumno;
import java.util.ArrayList;

public class Principal {

    public static void main(String[] args) {

        // Instanciar la lista circular
        CListaCircular lista = new CListaCircular();

        // Instanciar la vista
        MenuOpciones menu = new MenuOpciones();

        int opcion;

        do {

            menu.mostrarMenu();

            opcion = menu.leerEntero("Seleccione una opcion: ");

            switch (opcion) {

                // 1. INSERTAR AL INICIO
                case 1: {
                    Alumno alumno = menu.leerAlumno();
                    lista.insertarInicio(alumno);
                    menu.mostrarMensaje("Alumno insertado al inicio correctamente.");
                    break;
                }

                // 2. INSERTAR AL FINAL
                case 2: {
                    Alumno alumno = menu.leerAlumno();
                    lista.insertarFinal(alumno);
                    menu.mostrarMensaje("Alumno insertado al final correctamente.");
                    break;
                }

                // 3. INSERTAR EN POSICION X
                case 3: {
                    int posicion = menu.leerEntero("Ingrese la posicion donde insertar: ");
                    Alumno alumno = menu.leerAlumno();
                    lista.insertarPorPosicion(posicion, alumno);
                    menu.mostrarMensaje("Operacion de insercion por posicion finalizada.");
                    break;
                }

                // 4. INSERTAR POR REFERENCIA
                case 4: {
                    String referencia = menu.leerTexto("Ingrese el codigo de referencia: ");
                    Alumno alumno = menu.leerAlumno();
                    lista.insertarPorReferencia(referencia, alumno);
                    menu.mostrarMensaje("Operacion de insercion por referencia finalizada.");
                    break;
                }

                // 5. ELIMINAR AL INICIO
                case 5: {
                    lista.eliminarInicio();
                    menu.mostrarMensaje("Se ha eliminado el elemento al inicio (si la lista no estaba vacia).");
                    break;
                }

                // 6. ELIMINAR AL FINAL
                case 6: {
                    lista.eliminarFinal();
                    menu.mostrarMensaje("Se ha eliminado el elemento al final (si la lista no estaba vacia).");
                    break;
                }

                // 7. ELIMINAR EN POSICION X
                case 7: {
                    int posicion = menu.leerEntero("Ingrese la posicion a eliminar: ");
                    lista.eliminarPorPosicion(posicion);
                    menu.mostrarMensaje("Operacion de eliminacion por posicion finalizada.");
                    break;
                }

                // 8. ELIMINAR POR REFERENCIA
                case 8: {
                    String codigo = menu.leerTexto("Ingrese el codigo del alumno a eliminar: ");
                    lista.eliminarPorReferencia(codigo);
                    menu.mostrarMensaje("Operacion de eliminacion por referencia finalizada.");
                    break;
                }

                // 9. BUSCAR ALUMNO
                case 9: {
                    String codigo = menu.leerTexto("Ingrese el codigo del alumno: ");
                    Alumno alumno = lista.buscar(codigo);
                    menu.mostrarAlumno(alumno);
                    break;
                }

                // 10. RECORRER LISTA
                case 10: {
                    ArrayList<Alumno> alumnos = lista.obtenerLista();
                    menu.mostrarLista(alumnos);
                    break;
                }

                // 11. ORDENAR LISTA
                case 11: {
                    lista.ordenar();
                    menu.mostrarMensaje("Lista ordenada por codigo ascendente.");
                    menu.mostrarLista(lista.obtenerLista());
                    break;
                }

                // 12. INTERCAMBIAR ELEMENTOS
                case 12: {
                    int posicion1 = menu.leerEntero("Ingrese la primera posicion: ");
                    int posicion2 = menu.leerEntero("Ingrese la segunda posicion: ");
                    lista.intercambiar(posicion1, posicion2);
                    menu.mostrarMensaje("Proceso de intercambio finalizado.");
                    menu.mostrarLista(lista.obtenerLista());
                    break;
                }

                // 13. OBTENER TAMANIO
                case 13: {
                    menu.mostrarMensaje("Cantidad de alumnos registrados: " + lista.getTamanio());
                    break;
                }

                // 14. MODIFICAR ALUMNO
                case 14: {
                    String codigo = menu.leerTexto("Ingrese el codigo del alumno a modificar: ");
                    menu.mostrarMensaje("Ingrese los nuevos datos del alumno:");
                    Alumno nuevoAlumno = menu.leerAlumno();
                    
                    boolean modificado = lista.modificar(codigo, nuevoAlumno);
                    if (modificado) {
                        menu.mostrarMensaje("Datos del alumno modificados correctamente.");
                    } else {
                        menu.mostrarMensaje("No se encontro el alumno con ese codigo.");
                    }
                    break;
                }

                // SALIR
                case 0: {
                    menu.mostrarMensaje("Gracias por utilizar el sistema.");
                    break;
                }

                // OPCION INCORRECTA
                default: {
                    menu.mostrarMensaje("Opcion incorrecta. Intente nuevamente.");
                    break;
                }
            }

        } while (opcion != 0);
    }
}