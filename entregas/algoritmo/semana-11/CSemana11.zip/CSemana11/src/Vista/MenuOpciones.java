
package Vista;

import Modelo.Alumno;
import java.util.ArrayList;
import java.util.Scanner;

public class MenuOpciones {

    private Scanner teclado;

    public MenuOpciones() {
        teclado = new Scanner(System.in);
    }

    // Mostrar menu principal
    public void mostrarMenu() {

        System.out.println("\n======================================");
        System.out.println("   SISTEMA DE GESTION DE ALUMNOS");
        System.out.println("   LISTA CIRCULAR SIMPLEMENTE ENLAZADA");
        System.out.println("======================================");

        System.out.println("\n--- INSERCION ---");
        System.out.println("1. Insertar al inicio");
        System.out.println("2. Insertar al final");
        System.out.println("3. Insertar en posicion X");
        System.out.println("4. Insertar por referencia");

        System.out.println("\n--- ELIMINACION ---");
        System.out.println("5. Eliminar al inicio");
        System.out.println("6. Eliminar al final");
        System.out.println("7. Eliminar en posicion X");
        System.out.println("8. Eliminar por referencia");

        System.out.println("\n--- CONSULTAS Y OPERACIONES ---");
        System.out.println("9. Buscar alumno");
        System.out.println("10. Recorrer lista");
        System.out.println("11. Ordenar lista");
        System.out.println("12. Intercambiar elementos");
        System.out.println("13. Obtener tamanio");
        System.out.println("14. Modificar alumno");

        System.out.println("\n0. Salir");

        System.out.println("======================================");
    }

    // Leer un numero entero
    public int leerEntero(String mensaje) {

        while (true) {

            System.out.print(mensaje);

            try {
                int numero = Integer.parseInt(
                        teclado.nextLine().trim());

                return numero;

            } catch (NumberFormatException e) {
                System.out.println("Error: Ingrese un numero entero.");
            }
        }
    }

    // Leer una cadena
    public String leerTexto(String mensaje) {

        while (true) {

            System.out.print(mensaje);

            String texto = teclado.nextLine().trim();

            if (!texto.isEmpty()) {
                return texto;
            }

            System.out.println("El campo no puede estar vacio.");
        }
    }

    // Leer datos de un alumno
    public Alumno leerAlumno() {

        System.out.println("\n--- REGISTRO DE ALUMNO ---");

        String codigo = leerTexto("Ingrese codigo: ");

        String nombres = leerTexto("Ingrese nombres: ");

        String carrera = leerTexto("Ingrese carrera: ");

        int semestre;

        do {
            semestre = leerEntero("Ingrese semestre: ");

            if (semestre < 1) {
                System.out.println("El semestre debe ser mayor que cero.");
            }

        } while (semestre < 1);

        return new Alumno(codigo, nombres, carrera, semestre);
    }

    // Mostrar un alumno
    public void mostrarAlumno(Alumno alumno) {

        if (alumno == null) {
            System.out.println("No se encontro el alumno.");
        } else {
            System.out.println("\n--- DATOS DEL ALUMNO ---");
            System.out.println(alumno);
        }
    }

    // Mostrar todos los alumnos
    public void mostrarLista(ArrayList<Alumno> alumnos) {

        if (alumnos.isEmpty()) {
            System.out.println("\nLa lista esta vacia.");
            return;
        }

        System.out.println("\n========== LISTA DE ALUMNOS ==========");

        int posicion = 1;

        for (Alumno alumno : alumnos) {

            System.out.println("Posicion " + posicion);
            System.out.println(alumno);
            System.out.println("--------------------------------------");

            posicion++;
        }

        System.out.println("Total de alumnos: " + alumnos.size());
    }

    // Mostrar mensaje
    public void mostrarMensaje(String mensaje) {
        System.out.println("\n" + mensaje);
    }
}
