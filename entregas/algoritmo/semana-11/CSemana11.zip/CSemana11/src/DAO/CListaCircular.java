package DAO;

import Modelo.Alumno;
import Modelo.CNodo;
import java.util.ArrayList;

public class CListaCircular {
    private CNodo ultimo;
    private int tamanio;

    public CListaCircular() {
        this.ultimo = null;
        this.tamanio = 0;
    }

    public boolean esVacia() {
        return ultimo == null;
    }

    // 1. Insertar al inicio
    public void insertarInicio(Alumno alumno) {
        CNodo nuevo = new CNodo(alumno);
        if (esVacia()) {
            ultimo = nuevo;
            ultimo.setSiguiente(ultimo);
        } else {
            nuevo.setSiguiente(ultimo.getSiguiente());
            ultimo.setSiguiente(nuevo);
        }
        tamanio++;
    }

    // 2. Insertar al final
    public void insertarFinal(Alumno alumno) {
        insertarInicio(alumno);
        ultimo = ultimo.getSiguiente();
    }

    // 3. Insertar en posición X (1-indexed)
    public void insertarPorPosicion(int pos, Alumno alumno) {
        if (pos < 1 || pos > tamanio + 1) {
            System.out.println("Posicion fuera de rango.");
            return;
        }
        if (pos == 1) {
            insertarInicio(alumno);
        } else if (pos == tamanio + 1) {
            insertarFinal(alumno);
        } else {
            CNodo actual = ultimo.getSiguiente();
            for (int i = 1; i < pos - 1; i++) {
                actual = actual.getSiguiente();
            }
            CNodo nuevo = new CNodo(alumno);
            nuevo.setSiguiente(actual.getSiguiente());
            actual.setSiguiente(nuevo);
            tamanio++;
        }
    }

    // 4. Insertar por referencia (después de un código de alumno existente)
    public void insertarPorReferencia(String codigoRef, Alumno alumno) {
        if (esVacia()) return;
        CNodo actual = ultimo.getSiguiente();
        do {
            if (actual.getAlumno().getCodigo().equalsIgnoreCase(codigoRef)) {
                CNodo nuevo = new CNodo(alumno);
                nuevo.setSiguiente(actual.getSiguiente());
                actual.setSiguiente(nuevo);
                if (actual == ultimo) {
                    ultimo = nuevo;
                }
                tamanio++;
                return;
            }
            actual = actual.getSiguiente();
        } while (actual != ultimo.getSiguiente());
        System.out.println("Referencia no encontrada.");
    }

    // 5. Eliminar al inicio
    public void eliminarInicio() {
        if (esVacia()) return;
        if (ultimo.getSiguiente() == ultimo) {
            ultimo = null;
        } else {
            ultimo.setSiguiente(ultimo.getSiguiente().getSiguiente());
        }
        tamanio--;
    }

    // 6. Eliminar al final
    public void eliminarFinal() {
        if (esVacia()) return;
        if (ultimo.getSiguiente() == ultimo) {
            ultimo = null;
        } else {
            CNodo actual = ultimo.getSiguiente();
            while (actual.getSiguiente() != ultimo) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(ultimo.getSiguiente());
            ultimo = actual;
        }
        tamanio--;
    }

    // 7. Eliminar en posición X
    public void eliminarPorPosicion(int pos) {
        if (pos < 1 || pos > tamanio) {
            System.out.println("Posicion fuera de rango.");
            return;
        }
        if (pos == 1) {
            eliminarInicio();
        } else if (pos == tamanio) {
            eliminarFinal();
        } else {
            CNodo actual = ultimo.getSiguiente();
            for (int i = 1; i < pos - 1; i++) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(actual.getSiguiente().getSiguiente());
            tamanio--;
        }
    }

    // 8. Eliminar por referencia
    public void eliminarPorReferencia(String codigo) {
        if (esVacia()) return;
        CNodo actual = ultimo.getSiguiente();
        CNodo anterior = ultimo;
        do {
            if (actual.getAlumno().getCodigo().equalsIgnoreCase(codigo)) {
                if (actual == ultimo.getSiguiente() && actual == ultimo) {
                    ultimo = null;
                } else if (actual == ultimo.getSiguiente()) {
                    eliminarInicio();
                    return;
                } else if (actual == ultimo) {
                    eliminarFinal();
                    return;
                } else {
                    anterior.setSiguiente(actual.getSiguiente());
                    tamanio--;
                }
                return;
            }
            anterior = actual;
            actual = actual.getSiguiente();
        } while (actual != ultimo.getSiguiente());
        System.out.println("Alumno no encontrado para eliminar.");
    }

    // 9. Buscar alumno por código
    public Alumno buscar(String codigo) {
        if (esVacia()) return null;
        CNodo actual = ultimo.getSiguiente();
        do {
            if (actual.getAlumno().getCodigo().equalsIgnoreCase(codigo)) {
                return actual.getAlumno();
            }
            actual = actual.getSiguiente();
        } while (actual != ultimo.getSiguiente());
        return null;
    }

    // 10. Recorrer lista (convierte la lista circular a ArrayList para imprimirla con MenuOpciones)
    public ArrayList<Alumno> obtenerLista() {
        ArrayList<Alumno> lista = new ArrayList<>();
        if (esVacia()) return lista;
        CNodo actual = ultimo.getSiguiente();
        do {
            lista.add(actual.getAlumno());
            actual = actual.getSiguiente();
        } while (actual != ultimo.getSiguiente());
        return lista;
    }

    // 11. Ordenar lista (por código)
    public void ordenar() {
        if (tamanio < 2) return;
        ArrayList<Alumno> lista = obtenerLista();
        lista.sort((a1, a2) -> a1.getCodigo().compareToIgnoreCase(a2.getCodigo()));
        ultimo = null;
        tamanio = 0;
        for (Alumno a : lista) {
            insertarFinal(a);
        }
    }

    // 12. Intercambiar elementos por posición
    public void intercambiar(int pos1, int pos2) {
        if (pos1 < 1 || pos1 > tamanio || pos2 < 1 || pos2 > tamanio) {
            System.out.println("Posiciones invalidas.");
            return;
        }
        ArrayList<Alumno> lista = obtenerLista();
        Alumno temp = lista.get(pos1 - 1);
        lista.set(pos1 - 1, lista.get(pos2 - 1));
        lista.set(pos2 - 1, temp);
        
        ultimo = null;
        tamanio = 0;
        for (Alumno a : lista) {
            insertarFinal(a);
        }
    }

    // 13. Obtener tamaño
    public int getTamanio() {
        return tamanio;
    }

    // 14. Modificar alumno
    public boolean modificar(String codigo, Alumno nuevoAlumno) {
        if (esVacia()) return false;
        CNodo actual = ultimo.getSiguiente();
        do {
            if (actual.getAlumno().getCodigo().equalsIgnoreCase(codigo)) {
                actual.setAlumno(nuevoAlumno);
                return true;
            }
            actual = actual.getSiguiente();
        } while (actual != ultimo.getSiguiente());
        return false;
    }
}