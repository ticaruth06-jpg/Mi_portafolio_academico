package Modelo;

public class Turno {

    private int numeroTurno;
    private String fecha;
    private String hora;
    private String estado; // PENDIENTE, ATENDIDO, CANCELADO, REPROGRAMADO

    public Turno() {
    }

    public Turno(int numeroTurno, String fecha, String hora, String estado) {
        this.numeroTurno = numeroTurno;
        this.fecha = fecha;
        this.hora = hora;
        this.estado = estado;
    }

    public int getNumeroTurno() {
        return numeroTurno;
    }

    public void setNumeroTurno(int numeroTurno) {
        this.numeroTurno = numeroTurno;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Turno Nro " + numeroTurno
                + " | Fecha: " + fecha
                + " | Hora: " + hora
                + " | Estado: " + estado;
    }
}
