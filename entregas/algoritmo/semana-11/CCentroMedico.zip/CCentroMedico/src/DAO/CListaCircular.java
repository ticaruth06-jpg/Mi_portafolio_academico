package DAO;

import Modelo.CNodo;
import Modelo.Paciente;
import java.util.ArrayList;

/**
 * Lista circular simplemente enlazada de pacientes.
 * Se guarda la referencia al ULTIMO nodo; el primero siempre es
 * ultimo.getSiguiente(). El ultimo nodo apunta al primero (nunca a null).
 * Las posiciones se numeran a partir de 1.
 */
public class CListaCircular {

    private CNodo ultimo;
    private int tamanio;

    public CListaCircular() {
        this.ultimo = null;
        this.tamanio = 0;
    }

    public boolean esVacia() {
        return ultimo == null;
    }

    public int getTamanio() {
        return tamanio;
    }

    // ------------------------------------------------------------------
    // VALIDACIONES (codigos y numeros de turno unicos)
    // ------------------------------------------------------------------
    public boolean existeCodigo(String codigo) {
        return buscarNodo(codigo) != null;
    }

    public boolean existeTurno(int numeroTurno) {
        if (esVacia()) return false;
        CNodo actual = ultimo.getSiguiente();
        do {
            if (actual.getDato().getTurno().getNumeroTurno() == numeroTurno) {
                return true;
            }
            actual = actual.getSiguiente();
        } while (actual != ultimo.getSiguiente());
        return false;
    }

    private void validarDuplicados(Paciente p) {
        if (existeCodigo(p.getCodigo())) {
            throw new IllegalArgumentException(
                    "Ya existe un paciente con el codigo " + p.getCodigo() + ".");
        }
        if (existeTurno(p.getTurno().getNumeroTurno())) {
            throw new IllegalArgumentException(
                    "Ya existe el numero de turno " + p.getTurno().getNumeroTurno() + ".");
        }
    }

    // ------------------------------------------------------------------
    // METODOS AUXILIARES PRIVADOS
    // ------------------------------------------------------------------
    private CNodo buscarNodo(String codigo) {
        if (esVacia()) return null;
        CNodo actual = ultimo.getSiguiente();
        do {
            if (actual.getDato().getCodigo().equalsIgnoreCase(codigo)) {
                return actual;
            }
            actual = actual.getSiguiente();
        } while (actual != ultimo.getSiguiente());
        return null;
    }

    // Nodo ubicado en la posicion pos (1..tamanio)
    private CNodo nodoEnPosicion(int pos) {
        CNodo actual = ultimo.getSiguiente();
        for (int i = 1; i < pos; i++) {
            actual = actual.getSiguiente();
        }
        return actual;
    }

    // Nodo anterior a "objetivo": se avanza por el circulo hasta volver a el
    private CNodo nodoAnteriorA(CNodo objetivo) {
        CNodo actual = objetivo;
        while (actual.getSiguiente() != objetivo) {
            actual = actual.getSiguiente();
        }
        return actual;
    }

    // Desenlaza el nodo que esta DESPUES de "anterior" y devuelve su paciente
    private Paciente desenlazar(CNodo anterior) {
        CNodo borrar = anterior.getSiguiente();
        if (borrar == anterior) {          // unico elemento
            ultimo = null;
        } else {
            anterior.setSiguiente(borrar.getSiguiente());
            if (borrar == ultimo) {        // se elimino el ultimo
                ultimo = anterior;
            }
        }
        borrar.setSiguiente(null);
        tamanio--;
        return borrar.getDato();
    }

    // ------------------------------------------------------------------
    // A. REGISTRO DE PACIENTES
    // ------------------------------------------------------------------

    // Registrar al inicio
    public void insertarInicio(Paciente paciente) {
        validarDuplicados(paciente);
        CNodo nuevo = new CNodo(paciente);
        if (esVacia()) {
            nuevo.setSiguiente(nuevo);     // se apunta a si mismo
            ultimo = nuevo;
        } else {
            nuevo.setSiguiente(ultimo.getSiguiente());
            ultimo.setSiguiente(nuevo);
        }
        tamanio++;
    }

    // Registrar al final
    public void insertarFinal(Paciente paciente) {
        insertarInicio(paciente);          // enlaza como primero...
        ultimo = ultimo.getSiguiente();    // ...y se convierte en el ultimo
    }

    // Insertar en posicion X (1..tamanio+1). Devuelve false si la posicion es invalida
    public boolean insertarPorPosicion(int pos, Paciente paciente) {
        if (pos < 1 || pos > tamanio + 1) {
            return false;
        }
        if (pos == 1) {
            insertarInicio(paciente);
        } else if (pos == tamanio + 1) {
            insertarFinal(paciente);
        } else {
            validarDuplicados(paciente);
            CNodo anterior = nodoEnPosicion(pos - 1);
            CNodo nuevo = new CNodo(paciente);
            nuevo.setSiguiente(anterior.getSiguiente());
            anterior.setSiguiente(nuevo);
            tamanio++;
        }
        return true;
    }

    // Insertar despues de otro paciente identificado por su codigo
    public boolean insertarDespuesDe(String codigoRef, Paciente paciente) {
        CNodo ref = buscarNodo(codigoRef);
        if (ref == null) {
            return false;
        }
        validarDuplicados(paciente);
        CNodo nuevo = new CNodo(paciente);
        nuevo.setSiguiente(ref.getSiguiente());
        ref.setSiguiente(nuevo);
        if (ref == ultimo) {
            ultimo = nuevo;
        }
        tamanio++;
        return true;
    }

    // ------------------------------------------------------------------
    // B. GESTION DE TURNOS
    // ------------------------------------------------------------------

    // Atender al siguiente paciente: sale el primero y el inicio avanza al siguiente
    public Paciente atenderSiguiente() {
        if (esVacia()) return null;
        Paciente atendido = desenlazar(ultimo);
        atendido.getTurno().setEstado("ATENDIDO");
        return atendido;
    }

    // Eliminar un turno cancelado por codigo de paciente
    public Paciente eliminarPorCodigo(String codigo) {
        CNodo nodo = buscarNodo(codigo);
        if (nodo == null) return null;
        Paciente eliminado = desenlazar(nodoAnteriorA(nodo));
        eliminado.getTurno().setEstado("CANCELADO");
        return eliminado;
    }

    // Eliminar el primer turno pendiente
    public Paciente eliminarInicio() {
        if (esVacia()) return null;
        Paciente eliminado = desenlazar(ultimo);
        eliminado.getTurno().setEstado("CANCELADO");
        return eliminado;
    }

    // Eliminar el ultimo turno pendiente
    public Paciente eliminarFinal() {
        if (esVacia()) return null;
        Paciente eliminado = desenlazar(nodoAnteriorA(ultimo));
        eliminado.getTurno().setEstado("CANCELADO");
        return eliminado;
    }

    // Reprogramar: se quita al paciente y se inserta en otra posicion (1..tamanio)
    // Devuelve 0 = OK, 1 = paciente no encontrado, 2 = posicion invalida
    public int reprogramar(String codigo, int nuevaPos) {
        CNodo nodo = buscarNodo(codigo);
        if (nodo == null) return 1;
        if (nuevaPos < 1 || nuevaPos > tamanio) return 2;
        Paciente p = desenlazar(nodoAnteriorA(nodo));
        p.getTurno().setEstado("REPROGRAMADO");
        insertarPorPosicion(nuevaPos, p);
        return 0;
    }

    // ------------------------------------------------------------------
    // C. CONSULTAS
    // ------------------------------------------------------------------
    public Paciente buscar(String codigo) {
        CNodo nodo = buscarNodo(codigo);
        return (nodo == null) ? null : nodo.getDato();
    }

    // Paciente que sera atendido proximamente (el primero de la lista)
    public Paciente obtenerProximo() {
        return esVacia() ? null : ultimo.getSiguiente().getDato();
    }

    // Una sola vuelta: del primero al ultimo
    public ArrayList<Paciente> obtenerLista() {
        ArrayList<Paciente> lista = new ArrayList<>();
        if (esVacia()) return lista;
        CNodo actual = ultimo.getSiguiente();
        do {
            lista.add(actual.getDato());
            actual = actual.getSiguiente();
        } while (actual != ultimo.getSiguiente());
        return lista;
    }

    // Recorrido continuo: da "pasos" saltos, regresando al primero tras el ultimo
    public ArrayList<Paciente> recorrerCircular(int pasos) {
        ArrayList<Paciente> recorrido = new ArrayList<>();
        if (esVacia()) return recorrido;
        CNodo actual = ultimo.getSiguiente();
        for (int i = 0; i < pasos; i++) {
            recorrido.add(actual.getDato());
            actual = actual.getSiguiente();   // tras el ultimo vuelve al primero
        }
        return recorrido;
    }

    // ------------------------------------------------------------------
    // D. ADMINISTRACION
    // ------------------------------------------------------------------

    // Ordenar por numero de turno (burbuja intercambiando los datos de los nodos)
    public void ordenar() {
        if (tamanio < 2) return;
        for (int i = 0; i < tamanio - 1; i++) {
            CNodo actual = ultimo.getSiguiente();
            for (int j = 0; j < tamanio - 1 - i; j++) {
                CNodo sig = actual.getSiguiente();
                if (actual.getDato().getTurno().getNumeroTurno()
                        > sig.getDato().getTurno().getNumeroTurno()) {
                    Paciente temp = actual.getDato();
                    actual.setDato(sig.getDato());
                    sig.setDato(temp);
                }
                actual = sig;
            }
        }
    }

    // Intercambiar las posiciones de dos pacientes
    public boolean intercambiar(int pos1, int pos2) {
        if (pos1 < 1 || pos1 > tamanio || pos2 < 1 || pos2 > tamanio) {
            return false;
        }
        if (pos1 == pos2) return true;
        CNodo n1 = nodoEnPosicion(pos1);
        CNodo n2 = nodoEnPosicion(pos2);
        Paciente temp = n1.getDato();
        n1.setDato(n2.getDato());
        n2.setDato(temp);
        return true;
    }

    // Modificar datos de un paciente (valida que no se dupliquen codigo ni turno)
    public boolean modificar(String codigo, Paciente nuevo) {
        CNodo nodo = buscarNodo(codigo);
        if (nodo == null) return false;

        Paciente actual = nodo.getDato();
        if (!nuevo.getCodigo().equalsIgnoreCase(actual.getCodigo())
                && existeCodigo(nuevo.getCodigo())) {
            throw new IllegalArgumentException(
                    "Ya existe un paciente con el codigo " + nuevo.getCodigo() + ".");
        }
        if (nuevo.getTurno().getNumeroTurno() != actual.getTurno().getNumeroTurno()
                && existeTurno(nuevo.getTurno().getNumeroTurno())) {
            throw new IllegalArgumentException(
                    "Ya existe el numero de turno " + nuevo.getTurno().getNumeroTurno() + ".");
        }
        nodo.setDato(nuevo);
        return true;
    }
}
