package Vista;

import DAO.CListaCircular;
import Modelo.Paciente;

public class Principal {

    public static void main(String[] args) {

        // Instanciar la lista circular
        CListaCircular lista = new CListaCircular();

        // Instanciar la vista
        MenuOpciones menu = new MenuOpciones();

        int opcion;

        do {

            menu.mostrarMenu();

            opcion = menu.leerEntero("Seleccione una opcion: ");

            try {
                switch (opcion) {

                    // 1. REGISTRAR AL INICIO
                    case 1: {
                        Paciente paciente = menu.leerPaciente();
                        lista.insertarInicio(paciente);
                        menu.mostrarMensaje("Paciente registrado al inicio correctamente.");
                        break;
                    }

                    // 2. REGISTRAR AL FINAL
                    case 2: {
                        Paciente paciente = menu.leerPaciente();
                        lista.insertarFinal(paciente);
                        menu.mostrarMensaje("Paciente registrado al final correctamente.");
                        break;
                    }

                    // 3. INSERTAR EN POSICION X
                    case 3: {
                        int posicion = menu.leerEntero("Ingrese la posicion donde insertar (1 a "
                                + (lista.getTamanio() + 1) + "): ");
                        if (posicion < 1 || posicion > lista.getTamanio() + 1) {
                            menu.mostrarMensaje("Posicion fuera de rango.");
                            break;
                        }
                        Paciente paciente = menu.leerPaciente();
                        lista.insertarPorPosicion(posicion, paciente);
                        menu.mostrarMensaje("Paciente insertado en la posicion " + posicion + ".");
                        break;
                    }

                    // 4. INSERTAR DESPUES DE UN CODIGO
                    case 4: {
                        if (lista.esVacia()) {
                            menu.mostrarMensaje("La lista esta vacia. No hay referencia.");
                            break;
                        }
                        String referencia = menu.leerTexto("Ingrese el codigo del paciente de referencia: ");
                        if (!lista.existeCodigo(referencia)) {
                            menu.mostrarMensaje("No se encontro el paciente de referencia.");
                            break;
                        }
                        Paciente paciente = menu.leerPaciente();
                        lista.insertarDespuesDe(referencia, paciente);
                        menu.mostrarMensaje("Paciente insertado despues del codigo " + referencia + ".");
                        break;
                    }

                    // 5. ATENDER AL SIGUIENTE PACIENTE
                    case 5: {
                        Paciente atendido = lista.atenderSiguiente();
                        if (atendido == null) {
                            menu.mostrarMensaje("La lista esta vacia. No hay pacientes por atender.");
                        } else {
                            menu.mostrarMensaje("[ATENDIENDO PACIENTE]");
                            System.out.println(atendido);
                            Paciente proximo = lista.obtenerProximo();
                            if (proximo == null) {
                                menu.mostrarMensaje("No quedan pacientes pendientes.");
                            } else {
                                menu.mostrarMensaje("Siguiente en la lista: " + proximo.getNombres()
                                        + " " + proximo.getApellidos());
                            }
                        }
                        break;
                    }

                    // 6. ELIMINAR TURNO CANCELADO POR CODIGO
                    case 6: {
                        if (lista.esVacia()) {
                            menu.mostrarMensaje("La lista esta vacia.");
                            break;
                        }
                        String codigo = menu.leerTexto("Ingrese el codigo del paciente que cancelo: ");
                        Paciente eliminado = lista.eliminarPorCodigo(codigo);
                        if (eliminado == null) {
                            menu.mostrarMensaje("No se encontro el paciente con ese codigo.");
                        } else {
                            menu.mostrarMensaje("Turno cancelado y eliminado:");
                            System.out.println(eliminado);
                        }
                        break;
                    }

                    // 7. ELIMINAR EL PRIMER TURNO PENDIENTE
                    case 7: {
                        Paciente eliminado = lista.eliminarInicio();
                        if (eliminado == null) {
                            menu.mostrarMensaje("La lista esta vacia.");
                        } else {
                            menu.mostrarMensaje("Se elimino el primer turno pendiente:");
                            System.out.println(eliminado);
                        }
                        break;
                    }

                    // 8. ELIMINAR EL ULTIMO TURNO PENDIENTE
                    case 8: {
                        Paciente eliminado = lista.eliminarFinal();
                        if (eliminado == null) {
                            menu.mostrarMensaje("La lista esta vacia.");
                        } else {
                            menu.mostrarMensaje("Se elimino el ultimo turno pendiente:");
                            System.out.println(eliminado);
                        }
                        break;
                    }

                    // 9. REPROGRAMAR PACIENTE
                    case 9: {
                        if (lista.esVacia()) {
                            menu.mostrarMensaje("La lista esta vacia.");
                            break;
                        }
                        String codigo = menu.leerTexto("Ingrese el codigo del paciente a reprogramar: ");
                        if (!lista.existeCodigo(codigo)) {
                            menu.mostrarMensaje("No se encontro el paciente con ese codigo.");
                            break;
                        }
                        int nuevaPos = menu.leerEntero("Ingrese la nueva posicion (1 a "
                                + lista.getTamanio() + "): ");
                        int resultado = lista.reprogramar(codigo, nuevaPos);
                        if (resultado == 0) {
                            menu.mostrarMensaje("Paciente reprogramado a la posicion " + nuevaPos + ".");
                            menu.mostrarLista(lista.obtenerLista());
                        } else {
                            menu.mostrarMensaje("Posicion fuera de rango.");
                        }
                        break;
                    }

                    // 10. BUSCAR PACIENTE POR CODIGO
                    case 10: {
                        String codigo = menu.leerTexto("Ingrese el codigo del paciente: ");
                        menu.mostrarPaciente(lista.buscar(codigo));
                        break;
                    }

                    // 11. MOSTRAR PACIENTES PENDIENTES
                    case 11: {
                        menu.mostrarLista(lista.obtenerLista());
                        break;
                    }

                    // 12. CANTIDAD DE PACIENTES
                    case 12: {
                        menu.mostrarMensaje("Cantidad de pacientes registrados: " + lista.getTamanio());
                        break;
                    }

                    // 13. PROXIMO PACIENTE A ATENDER
                    case 13: {
                        Paciente proximo = lista.obtenerProximo();
                        if (proximo == null) {
                            menu.mostrarMensaje("No hay pacientes pendientes.");
                        } else {
                            menu.mostrarMensaje("[PROXIMO PACIENTE A ATENDER]");
                            System.out.println(proximo);
                        }
                        break;
                    }

                    // 14. RECORRIDO CIRCULAR CONTINUO
                    case 14: {
                        if (lista.esVacia()) {
                            menu.mostrarMensaje("No hay pacientes para recorrer.");
                            break;
                        }
                        int pasos = menu.leerEnteroPositivo("Ingrese cuantos pacientes recorrer (puede superar el total): ");
                        menu.mostrarRecorrido(lista.recorrerCircular(pasos), lista.getTamanio());
                        break;
                    }

                    // 15. ORDENAR POR NUMERO DE TURNO
                    case 15: {
                        if (lista.esVacia()) {
                            menu.mostrarMensaje("La lista esta vacia.");
                            break;
                        }
                        lista.ordenar();
                        menu.mostrarMensaje("Lista ordenada por numero de turno ascendente.");
                        menu.mostrarLista(lista.obtenerLista());
                        break;
                    }

                    // 16. INTERCAMBIAR POSICIONES
                    case 16: {
                        if (lista.getTamanio() < 2) {
                            menu.mostrarMensaje("Se necesitan al menos 2 pacientes para intercambiar.");
                            break;
                        }
                        int pos1 = menu.leerEntero("Ingrese la primera posicion: ");
                        int pos2 = menu.leerEntero("Ingrese la segunda posicion: ");
                        if (lista.intercambiar(pos1, pos2)) {
                            menu.mostrarMensaje("Posiciones " + pos1 + " y " + pos2 + " intercambiadas.");
                            menu.mostrarLista(lista.obtenerLista());
                        } else {
                            menu.mostrarMensaje("Posiciones invalidas (deben estar entre 1 y "
                                    + lista.getTamanio() + ").");
                        }
                        break;
                    }

                    // 17. MODIFICAR DATOS DE UN PACIENTE
                    case 17: {
                        if (lista.esVacia()) {
                            menu.mostrarMensaje("La lista esta vacia.");
                            break;
                        }
                        String codigo = menu.leerTexto("Ingrese el codigo del paciente a modificar: ");
                        if (!lista.existeCodigo(codigo)) {
                            menu.mostrarMensaje("No se encontro el paciente con ese codigo.");
                            break;
                        }
                        menu.mostrarMensaje("Ingrese los nuevos datos del paciente:");
                        Paciente nuevo = menu.leerPaciente();
                        lista.modificar(codigo, nuevo);
                        menu.mostrarMensaje("Datos del paciente modificados correctamente.");
                        break;
                    }

                    // SALIR
                    case 0: {
                        menu.mostrarMensaje("Gracias por utilizar el sistema.");
                        break;
                    }

                    // OPCION INCORRECTA
                    default: {
                        menu.mostrarMensaje("Opcion incorrecta. Intente nuevamente.");
                        break;
                    }
                }
            } catch (IllegalArgumentException e) {
                // Codigo o numero de turno duplicado
                menu.mostrarMensaje("[ERROR] " + e.getMessage());
            }

        } while (opcion != 0);
    }
}
