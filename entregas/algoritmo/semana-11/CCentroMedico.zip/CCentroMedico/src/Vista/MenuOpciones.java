package Vista;

import Modelo.Paciente;
import Modelo.Turno;
import java.util.ArrayList;
import java.util.Scanner;

public class MenuOpciones {

    private Scanner teclado;

    public MenuOpciones() {
        teclado = new Scanner(System.in);
    }

    // Mostrar menu principal
    public void mostrarMenu() {

        System.out.println("\n==============================================");
        System.out.println("   SISTEMA DE GESTION DE TURNOS - CENTRO MEDICO");
        System.out.println("   LISTA CIRCULAR SIMPLEMENTE ENLAZADA");
        System.out.println("==============================================");

        System.out.println("\n--- A. REGISTRO DE PACIENTES ---");
        System.out.println("1. Registrar paciente al inicio");
        System.out.println("2. Registrar paciente al final");
        System.out.println("3. Insertar paciente en posicion X");
        System.out.println("4. Insertar paciente despues de un codigo");

        System.out.println("\n--- B. GESTION DE TURNOS ---");
        System.out.println("5. Atender al siguiente paciente");
        System.out.println("6. Eliminar turno cancelado (por codigo)");
        System.out.println("7. Eliminar el primer turno pendiente");
        System.out.println("8. Eliminar el ultimo turno pendiente");
        System.out.println("9. Reprogramar paciente (otra posicion)");

        System.out.println("\n--- C. CONSULTAS ---");
        System.out.println("10. Buscar paciente por codigo");
        System.out.println("11. Mostrar pacientes pendientes");
        System.out.println("12. Cantidad de pacientes registrados");
        System.out.println("13. Mostrar proximo paciente a atender");
        System.out.println("14. Recorrido circular continuo");

        System.out.println("\n--- D. ADMINISTRACION ---");
        System.out.println("15. Ordenar pacientes por numero de turno");
        System.out.println("16. Intercambiar posiciones de dos pacientes");
        System.out.println("17. Modificar datos de un paciente");

        System.out.println("\n0. Salir");
        System.out.println("==============================================");
    }

    // Leer un numero entero
    public int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return Integer.parseInt(teclado.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Error: Ingrese un numero entero.");
            }
        }
    }

    // Leer un entero mayor que cero
    public int leerEnteroPositivo(String mensaje) {
        int numero;
        do {
            numero = leerEntero(mensaje);
            if (numero < 1) {
                System.out.println("El valor debe ser mayor que cero.");
            }
        } while (numero < 1);
        return numero;
    }

    // Leer una cadena no vacia
    public String leerTexto(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = teclado.nextLine().trim();
            if (!texto.isEmpty()) {
                return texto;
            }
            System.out.println("El campo no puede estar vacio.");
        }
    }

    // Leer una cadena que cumpla un patron (regex)
    private String leerConFormato(String mensaje, String regex, String error) {
        while (true) {
            String texto = leerTexto(mensaje);
            if (texto.matches(regex)) {
                return texto;
            }
            System.out.println(error);
        }
    }

    // Leer datos de un paciente con su turno
    public Paciente leerPaciente() {

        System.out.println("\n--- REGISTRO DE PACIENTE ---");

        String codigo = leerTexto("Ingrese codigo: ");
        String nombres = leerTexto("Ingrese nombres: ");
        String apellidos = leerTexto("Ingrese apellidos: ");
        String dni = leerConFormato("Ingrese DNI (8 digitos): ", "\\d{8}",
                "El DNI debe tener exactamente 8 digitos.");
        String especialidad = leerTexto("Ingrese especialidad: ");

        System.out.println("--- DATOS DEL TURNO ---");
        int numeroTurno = leerEnteroPositivo("Ingrese numero de turno: ");
        String fecha = leerConFormato("Ingrese fecha (dd/mm/aaaa): ",
                "\\d{2}/\\d{2}/\\d{4}", "Formato invalido. Ejemplo: 15/11/2026");
        String hora = leerConFormato("Ingrese hora (hh:mm): ",
                "([01]\\d|2[0-3]):[0-5]\\d", "Formato invalido. Ejemplo: 09:30");

        Turno turno = new Turno(numeroTurno, fecha, hora, "PENDIENTE");
        return new Paciente(codigo, nombres, apellidos, dni, especialidad, turno);
    }

    // Mostrar un paciente
    public void mostrarPaciente(Paciente paciente) {
        if (paciente == null) {
            System.out.println("\nNo se encontro el paciente.");
        } else {
            System.out.println("\n--- DATOS DEL PACIENTE ---");
            System.out.println(paciente);
        }
    }

    // Mostrar todos los pacientes pendientes
    public void mostrarLista(ArrayList<Paciente> pacientes) {

        if (pacientes.isEmpty()) {
            System.out.println("\nNo hay pacientes pendientes de atencion.");
            return;
        }

        System.out.println("\n====== PACIENTES PENDIENTES DE ATENCION ======");

        int posicion = 1;
        for (Paciente paciente : pacientes) {
            System.out.println("Posicion " + posicion);
            System.out.println(paciente);
            System.out.println("----------------------------------------------");
            posicion++;
        }

        System.out.println("Total de pacientes: " + pacientes.size());
    }

    // Mostrar el recorrido circular (indica cada vuelta completa)
    public void mostrarRecorrido(ArrayList<Paciente> recorrido, int tamanio) {

        if (recorrido.isEmpty()) {
            System.out.println("\nNo hay pacientes para recorrer.");
            return;
        }

        System.out.println("\n====== RECORRIDO CIRCULAR CONTINUO ======");

        for (int i = 0; i < recorrido.size(); i++) {
            if (i % tamanio == 0) {
                System.out.println(">>> Vuelta " + (i / tamanio + 1) + " <<<");
            }
            Paciente p = recorrido.get(i);
            System.out.println((i + 1) + ". " + p.getCodigo() + " - "
                    + p.getNombres() + " " + p.getApellidos()
                    + " (Turno " + p.getTurno().getNumeroTurno() + ")");
        }
    }

    // Mostrar mensaje
    public void mostrarMensaje(String mensaje) {
        System.out.println("\n" + mensaje);
    }
}
