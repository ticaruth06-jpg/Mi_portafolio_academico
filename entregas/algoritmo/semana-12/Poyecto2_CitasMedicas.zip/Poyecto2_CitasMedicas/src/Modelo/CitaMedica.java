package Modelo;

public class CitaMedica {
    private String codigoCita;
    private String dniPaciente;
    private String nombresApellidos;
    private String especialidad;
    private String nombreMedico;
    private String fechaAtencion; // Formato sugerido: YYYY-MM-DD para facilitar ordenamiento
    private String horaAtencion;  // Formato sugerido: HH:mm (24h)
    private String estado;        // "Registrada", "Atendida", "Cancelada"

    public CitaMedica() {
    }

    public CitaMedica(String codigoCita, String dniPaciente, String nombresApellidos, 
                      String especialidad, String nombreMedico, String fechaAtencion, 
                      String horaAtencion, String estado) {
        this.codigoCita = codigoCita;
        this.dniPaciente = dniPaciente;
        this.nombresApellidos = nombresApellidos;
        this.especialidad = especialidad;
        this.nombreMedico = nombreMedico;
        this.fechaAtencion = fechaAtencion;
        this.horaAtencion = horaAtencion;
        this.estado = estado;
    }

    // Getters y Setters
    public String getCodigoCita() { return codigoCita; }
    public void setCodigoCita(String codigoCita) { this.codigoCita = codigoCita; }

    public String getDniPaciente() { return dniPaciente; }
    public void setDniPaciente(String dniPaciente) { this.dniPaciente = dniPaciente; }

    public String getNombresApellidos() { return nombresApellidos; }
    public void setNombresApellidos(String nombresApellidos) { this.nombresApellidos = nombresApellidos; }

    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }

    public String getNombreMedico() { return nombreMedico; }
    public void setNombreMedico(String nombreMedico) { this.nombreMedico = nombreMedico; }

    public String getFechaAtencion() { return fechaAtencion; }
    public void setFechaAtencion(String fechaAtencion) { this.fechaAtencion = fechaAtencion; }

    public String getHoraAtencion() { return horaAtencion; }
    public void setHoraAtencion(String horaAtencion) { this.horaAtencion = horaAtencion; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    @Override
    public String toString() {
        return String.format("| %-8s | %-10s | %-22s | %-15s | %-18s | %-10s | %-6s | %-10s |",
                codigoCita, dniPaciente, nombresApellidos, especialidad, 
                nombreMedico, fechaAtencion, horaAtencion, estado);
    }
}