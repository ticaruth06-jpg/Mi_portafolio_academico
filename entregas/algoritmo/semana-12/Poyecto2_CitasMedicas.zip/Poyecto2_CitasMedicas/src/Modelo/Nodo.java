package Modelo;

public class Nodo {
    public CitaMedica dato;
    public Nodo anterior;
    public Nodo siguiente;

    public Nodo(CitaMedica dato) {
        this.dato = dato;
        this.anterior = null;
        this.siguiente = null;
    }
}