package DAO;

import Modelo.CitaMedica;
import Modelo.Nodo;

public class ListaCitas {
    private Nodo inicio;
    private Nodo fin;
    private int tamanio;

    public ListaCitas() {
        this.inicio = null;
        this.fin = null;
        this.tamanio = 0;
    }

    public boolean estaVacia() {
        return inicio == null;
    }

    public int getTamanio() {
        return tamanio;
    }

    // 1.A. Registrar una nueva cita al inicio
    public void insertarInicio(CitaMedica cita) {
        Nodo nuevo = new Nodo(cita);
        if (estaVacia()) {
            inicio = fin = nuevo;
        } else {
            nuevo.siguiente = inicio;
            inicio.anterior = nuevo;
            inicio = nuevo;
        }
        tamanio++;
    }

    // 1.B. Registrar una nueva cita al final
    public void insertarFinal(CitaMedica cita) {
        Nodo nuevo = new Nodo(cita);
        if (estaVacia()) {
            inicio = fin = nuevo;
        } else {
            fin.siguiente = nuevo;
            nuevo.anterior = fin;
            fin = nuevo;
        }
        tamanio++;
    }

    // 2. Insertar una cita en una posición determinada (base 1)
    public boolean insertarEnPosicion(CitaMedica cita, int posicion) {
        if (posicion < 1 || posicion > tamanio + 1) {
            return false;
        }
        if (posicion == 1) {
            insertarInicio(cita);
            return true;
        }
        if (posicion == tamanio + 1) {
            insertarFinal(cita);
            return true;
        }

        Nodo nuevo = new Nodo(cita);
        Nodo actual = inicio;
        for (int i = 1; i < posicion - 1; i++) {
            actual = actual.siguiente;
        }

        nuevo.siguiente = actual.siguiente;
        nuevo.anterior = actual;
        actual.siguiente.anterior = nuevo;
        actual.siguiente = nuevo;
        tamanio++;
        return true;
    }

    // 3. Buscar una cita mediante su código o DNI del paciente
    public Nodo buscarPorCodigoODni(String criterio) {
        Nodo actual = inicio;
        while (actual != null) {
            if (actual.dato.getCodigoCita().equalsIgnoreCase(criterio) ||
                actual.dato.getDniPaciente().equalsIgnoreCase(criterio)) {
                return actual;
            }
            actual = actual.siguiente;
        }
        return null;
    }

    // 4. Modificar la información de una cita médica (buscada por código)
    public boolean modificarCita(String codigo, CitaMedica nuevosDatos) {
        Nodo encontrado = buscarPorCodigoODni(codigo);
        if (encontrado != null) {
            encontrado.dato.setDniPaciente(nuevosDatos.getDniPaciente());
            encontrado.dato.setNombresApellidos(nuevosDatos.getNombresApellidos());
            encontrado.dato.setEspecialidad(nuevosDatos.getEspecialidad());
            encontrado.dato.setNombreMedico(nuevosDatos.getNombreMedico());
            encontrado.dato.setFechaAtencion(nuevosDatos.getFechaAtencion());
            encontrado.dato.setHoraAtencion(nuevosDatos.getHoraAtencion());
            encontrado.dato.setEstado(nuevosDatos.getEstado());
            return true;
        }
        return false;
    }

    // 5.A. Cancelar cita (cambia el estado a "Cancelada")
    public boolean cancelarCita(String codigo) {
        Nodo encontrado = buscarPorCodigoODni(codigo);
        if (encontrado != null) {
            encontrado.dato.setEstado("Cancelada");
            return true;
        }
        return false;
    }

    // 5.B. Eliminar físicamente el nodo de la lista por código
    public boolean eliminarCita(String codigo) {
        Nodo actual = buscarPorCodigoODni(codigo);
        if (actual == null) {
            return false;
        }

        if (inicio == fin) {
            inicio = fin = null;
        } else if (actual == inicio) {
            inicio = inicio.siguiente;
            inicio.anterior = null;
        } else if (actual == fin) {
            fin = fin.anterior;
            fin.siguiente = null;
        } else {
            actual.anterior.siguiente = actual.siguiente;
            actual.siguiente.anterior = actual.anterior;
        }
        tamanio--;
        return true;
    }

    // 6. Mostrar todas las citas desde la primera hasta la última
    public void mostrarAdelante() {
        if (estaVacia()) {
            System.out.println("No hay citas registradas.");
            return;
        }
        imprimirCabecera();
        Nodo actual = inicio;
        while (actual != null) {
            System.out.println(actual.dato.toString());
            actual = actual.siguiente;
        }
    }

    // 7. Mostrar todas las citas en orden inverso
    public void mostrarAtras() {
        if (estaVacia()) {
            System.out.println("No hay citas registradas.");
            return;
        }
        imprimirCabecera();
        Nodo actual = fin;
        while (actual != null) {
            System.out.println(actual.dato.toString());
            actual = actual.anterior;
        }
    }

    // 8. Ordenar las citas por fecha y hora de atención (Método Burbuja intercambiando datos)
    public void ordenarPorFechaYHora() {
        if (estaVacia() || inicio.siguiente == null) {
            return;
        }
        boolean huboCambio;
        do {
            huboCambio = false;
            Nodo actual = inicio;
            while (actual.siguiente != null) {
                String fechaHora1 = actual.dato.getFechaAtencion() + " " + actual.dato.getHoraAtencion();
                String fechaHora2 = actual.siguiente.dato.getFechaAtencion() + " " + actual.siguiente.dato.getHoraAtencion();

                if (fechaHora1.compareTo(fechaHora2) > 0) {
                    CitaMedica temp = actual.dato;
                    actual.dato = actual.siguiente.dato;
                    actual.siguiente.dato = temp;
                    huboCambio = true;
                }
                actual = actual.siguiente;
            }
        } while (huboCambio);
    }

    // 9. Buscar las citas correspondientes a un médico determinado
    public void buscarPorMedico(String nombreMedico) {
        if (estaVacia()) {
            System.out.println("No hay citas registradas.");
            return;
        }
        Nodo actual = inicio;
        boolean encontrado = false;
        imprimirCabecera();
        while (actual != null) {
            if (actual.dato.getNombreMedico().toLowerCase().contains(nombreMedico.toLowerCase())) {
                System.out.println(actual.dato.toString());
                encontrado = true;
            }
            actual = actual.siguiente;
        }
        if (!encontrado) {
            System.out.println("No se encontraron citas para el médico: " + nombreMedico);
        }
    }

    // 10. Contabilizar las citas registradas, atendidas y canceladas
    public void contabilizarEstados() {
        int registras = 0, atendidas = 0, canceladas = 0;
        Nodo actual = inicio;
        while (actual != null) {
            String est = actual.dato.getEstado().toLowerCase();
            if (est.equals("registrada")) {
                registras++;
            } else if (est.equals("atendida")) {
                atendidas++;
            } else if (est.equals("cancelada")) {
                canceladas++;
            }
            actual = actual.siguiente;
        }
        System.out.println("\n--- RESUMEN DE CITAS ---");
        System.out.println("Total general   : " + tamanio);
        System.out.println("Registradas     : " + registras);
        System.out.println("Atendidas       : " + atendidas);
        System.out.println("Canceladas      : " + canceladas);
    }

    private void imprimirCabecera() {
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("| %-8s | %-10s | %-22s | %-15s | %-18s | %-10s | %-6s | %-10s |\n",
                "CÓDIGO", "DNI", "PACIENTE", "ESPECIALIDAD", "MÉDICO", "FECHA", "HORA", "ESTADO");
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------");
    }
}