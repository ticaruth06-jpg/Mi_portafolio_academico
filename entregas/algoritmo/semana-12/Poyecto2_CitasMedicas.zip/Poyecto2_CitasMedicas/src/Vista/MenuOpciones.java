package Vista;

import DAO.ListaCitas;
import Modelo.CitaMedica;
import Modelo.Nodo;
import java.util.Scanner;

public class MenuOpciones {
    private ListaCitas lista;
    private Scanner sc;

    public MenuOpciones() {
        lista = new ListaCitas();
        sc = new Scanner(System.in);
        cargarDatosPrueba(); // Opcional: precarga 3 citas para probar rápido
    }

    private void cargarDatosPrueba() {
        lista.insertarFinal(new CitaMedica("C001", "71234567", "Juan Pérez", "Cardiología", "Dr. Gómez", "2026-11-20", "09:30", "Registrada"));
        lista.insertarFinal(new CitaMedica("C002", "72345678", "María López", "Pediatría", "Dra. Torres", "2026-11-18", "14:00", "Atendida"));
        lista.insertarFinal(new CitaMedica("C003", "73456789", "Carlos Ruiz", "Dermatología", "Dr. Gómez", "2026-11-19", "11:15", "Cancelada"));
    }

    public void mostrarMenu() {
        int opcion;
        do {
            System.out.println("\n=======================================================");
            System.out.println("   SISTEMA DE GESTIÓN DE CITAS MÉDICAS - CENTRO SALUD");
            System.out.println("=======================================================");
            System.out.println("1.  Registrar cita al INICIO");
            System.out.println("2.  Registrar cita al FINAL");
            System.out.println("3.  Insertar cita en una POSICIÓN determinada");
            System.out.println("4.  Buscar cita por CÓDIGO o DNI");
            System.out.println("5.  Modificar información de una cita");
            System.out.println("6.  Cancelar o eliminar una cita");
            System.out.println("7.  Mostrar citas (Primera -> Última)");
            System.out.println("8.  Mostrar citas en orden INVERSO (Última -> Primera)");
            System.out.println("9.  Ordenar citas por FECHA y HORA");
            System.out.println("10. Buscar citas por MÉDICO");
            System.out.println("11. Contabilizar citas (Registradas, Atendidas, Canceladas)");
            System.out.println("0.  Salir");
            System.out.print("Seleccione una opción: ");
            
            opcion = leerEntero();

            switch (opcion) {
                case 1:
                    lista.insertarInicio(leerDatosCita(true));
                    System.out.println("Cita registrada al inicio.");
                    break;
                case 2:
                    lista.insertarFinal(leerDatosCita(true));
                    System.out.println("Cita registrada al final.");
                    break;
                case 3:
                    System.out.print("Ingrese la posición (1 a " + (lista.getTamanio() + 1) + "): ");
                    int pos = leerEntero();
                    CitaMedica nueva = leerDatosCita(true);
                    if (lista.insertarEnPosicion(nueva, pos)) {
                        System.out.println("Cita insertada en la posición " + pos);
                    } else {
                        System.out.println("Posición inválida.");
                    }
                    break;
                case 4:
                    System.out.print("Ingrese Código de cita o DNI del paciente: ");
                    String crit = sc.nextLine();
                    Nodo enc = lista.buscarPorCodigoODni(crit);
                    if (enc != null) {
                        System.out.println("Cita encontrada:\n" + enc.dato);
                    } else {
                        System.out.println("No se encontró ninguna cita con ese criterio.");
                    }
                    break;
                case 5:
                    System.out.print("Ingrese el Código de la cita a modificar: ");
                    String codMod = sc.nextLine();
                    if (lista.buscarPorCodigoODni(codMod) != null) {
                        System.out.println("Ingrese los nuevos datos:");
                        CitaMedica datosNuevos = leerDatosCita(false);
                        datosNuevos.setCodigoCita(codMod);
                        lista.modificarCita(codMod, datosNuevos);
                        System.out.println("Cita actualizada correctamente.");
                    } else {
                        System.out.println("Código de cita no encontrado.");
                    }
                    break;
                case 6:
                    System.out.print("Ingrese el Código de la cita: ");
                    String codAccion = sc.nextLine();
                    System.out.print("¿Desea (1) Cambiar estado a Cancelada o (2) Eliminar registro?: ");
                    int subOp = leerEntero();
                    if (subOp == 1) {
                        System.out.println(lista.cancelarCita(codAccion) ? "Cita cancelada." : "Cita no encontrada.");
                    } else if (subOp == 2) {
                        System.out.println(lista.eliminarCita(codAccion) ? "Cita eliminada de la lista." : "Cita no encontrada.");
                    }
                    break;
                case 7:
                    lista.mostrarAdelante();
                    break;
                case 8:
                    lista.mostrarAtras();
                    break;
                case 9:
                    lista.ordenarPorFechaYHora();
                    System.out.println("Citas ordenadas cronológicamente:");
                    lista.mostrarAdelante();
                    break;
                case 10:
                    System.out.print("Ingrese nombre (o apellido) del médico: ");
                    String med = sc.nextLine();
                    lista.buscarPorMedico(med);
                    break;
                case 11:
                    lista.contabilizarEstados();
                    break;
                case 0:
                    System.out.println("Cerrando sistema...");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 0);
    }

    private CitaMedica leerDatosCita(boolean pedirCodigo) {
        String codigo = "";
        if (pedirCodigo) {
            System.out.print("Código de cita (ej. C004): ");
            codigo = sc.nextLine();
        }
        System.out.print("DNI del paciente: ");
        String dni = sc.nextLine();
        System.out.print("Nombres y apellidos: ");
        String nombres = sc.nextLine();
        System.out.print("Especialidad médica: ");
        String esp = sc.nextLine();
        System.out.print("Nombre del médico: ");
        String med = sc.nextLine();
        System.out.print("Fecha de atención (YYYY-MM-DD): ");
        String fecha = sc.nextLine();
        System.out.print("Hora de atención (HH:mm): ");
        String hora = sc.nextLine();
        System.out.print("Estado (Registrada / Atendida / Cancelada): ");
        String estado = sc.nextLine();

        return new CitaMedica(codigo, dni, nombres, esp, med, fecha, hora, estado);
    }

    private int leerEntero() {
        while (true) {
            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.print("Por favor, ingrese un número válido: ");
            }
        }
    }
}