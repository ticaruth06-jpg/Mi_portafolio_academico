package Vista;

public class Principal {
    public static void main(String[] args) {
        MenuOpciones menu = new MenuOpciones();
        menu.mostrarMenu();
    }
}