package vista;

import DAO.ClistaDoble;
import Modelo.Alumno;
import java.util.Scanner;

public class MenuOpciones {

    private final ClistaDoble lista;
    private final Scanner teclado;

    public MenuOpciones(ClistaDoble lista) {

        this.lista = lista;
        this.teclado = new Scanner(System.in);
    }

    // =====================================
    // LEER INFORMACION DEL ALUMNO
    // =====================================
    private Alumno leerAlumno() {

        System.out.print("Código: ");
        String codigo = teclado.nextLine();

        System.out.print("Nombre: ");
        String nombre = teclado.nextLine();

        System.out.print("Edad: ");
        int edad = Integer.parseInt(teclado.nextLine());

        System.out.print("Promedio: ");
        double promedio = Double.parseDouble(teclado.nextLine());

        return new Alumno(codigo, nombre, edad, promedio);
    }

    // =====================================
    // MOSTRAR MENU
    // =====================================
    public void mostrarMenu() {

        int opcion;

        do {

            System.out.println("\n================================");
            System.out.println(" SISTEMA DE GESTION DE ALUMNOS");
            System.out.println(" LISTA DOBLEMENTE ENLAZADA");
            System.out.println("================================");

            System.out.println("1.  Insertar alumno al inicio");
            System.out.println("2.  Insertar alumno al final");
            System.out.println("3.  Insertar alumno por posición");
            System.out.println("4.  Insertar después de un alumno");
            System.out.println("5.  Mostrar alumnos (izquierda a derecha)");
            System.out.println("6.  Mostrar alumnos (derecha a izquierda)");
            System.out.println("7.  Buscar alumno por código");
            System.out.println("8.  Buscar alumno por posición");
            System.out.println("9.  Eliminar alumno al inicio");
            System.out.println("10. Eliminar alumno al final");
            System.out.println("11. Eliminar alumno por posición");
            System.out.println("12. Eliminar alumno por código");
            System.out.println("13. Ordenar por promedio");
            System.out.println("14. Intercambiar alumnos");
            System.out.println("15. Modificar alumno");
            System.out.println("16. Mostrar tamaño de la lista");
            System.out.println("17. Verificar si la lista está vacía");
            System.out.println("0.  Salir");

            System.out.print("\nSeleccione una opción: ");

            try {

                opcion = Integer.parseInt(teclado.nextLine());

                ejecutarOpcion(opcion);

            } catch (NumberFormatException e) {

                System.out.println("Error: ingrese un número válido.");
                opcion = -1;

            } catch (IndexOutOfBoundsException e) {

                System.out.println("Error: posición fuera de rango.");
                opcion = -1;
            }

        } while (opcion != 0);

        System.out.println("Gracias por utilizar el sistema.");
    }

    // =====================================
    // EJECUTAR OPCIONES
    // =====================================
    private void ejecutarOpcion(int opcion) {

        switch (opcion) {

            case 1:
                System.out.println("\nREGISTRAR AL INICIO");
                lista.insertarInicio(leerAlumno());
                System.out.println("Alumno registrado correctamente.");
                break;

            case 2:
                System.out.println("\nREGISTRAR AL FINAL");
                lista.insertarFinal(leerAlumno());
                System.out.println("Alumno registrado correctamente.");
                break;

            case 3:
                System.out.print("Ingrese posición: ");
                int pos = Integer.parseInt(teclado.nextLine());

                System.out.println("Ingrese los datos del alumno:");
                lista.insertarPosicion(pos, leerAlumno());

                System.out.println("Alumno insertado correctamente.");
                break;

            case 4:
                System.out.print("Código del alumno de referencia: ");
                String codigoReferencia = teclado.nextLine();

                System.out.println("Datos del nuevo alumno:");
                Alumno nuevo = leerAlumno();

                if (lista.insertarDespuesDe(codigoReferencia, nuevo)) {
                    System.out.println("Alumno insertado correctamente.");
                } else {
                    System.out.println("No se encontró el alumno de referencia.");
                }
                break;

            case 5:
                System.out.println("\nRECORRIDO HACIA ADELANTE");
                lista.recorrerAdelante();
                break;

            case 6:
                System.out.println("\nRECORRIDO HACIA ATRÁS");
                lista.recorrerAtras();
                break;

            case 7:
                System.out.print("Ingrese código: ");
                String codigo = teclado.nextLine();

                Alumno encontrado = lista.buscarPorCodigo(codigo);

                if (encontrado != null) {
                    System.out.println(encontrado);
                } else {
                    System.out.println("Alumno no encontrado.");
                }
                break;

            case 8:
                System.out.print("Ingrese posición: ");
                int indice = Integer.parseInt(teclado.nextLine());

                System.out.println(lista.buscarPosicion(indice));
                break;

            case 9:
                Alumno eliminadoInicio = lista.eliminarInicio();

                if (eliminadoInicio != null) {
                    System.out.println("Eliminado: " + eliminadoInicio);
                } else {
                    System.out.println("La lista está vacía.");
                }
                break;

            case 10:
                Alumno eliminadoFinal = lista.eliminarFinal();

                if (eliminadoFinal != null) {
                    System.out.println("Eliminado: " + eliminadoFinal);
                } else {
                    System.out.println("La lista está vacía.");
                }
                break;

            case 11:
                System.out.print("Ingrese posición: ");
                int posicion = Integer.parseInt(teclado.nextLine());

                Alumno eliminadoPosicion
                        = lista.eliminarPosicion(posicion);

                System.out.println("Eliminado: " + eliminadoPosicion);
                break;

            case 12:
                System.out.print("Ingrese código del alumno: ");
                String codEliminar = teclado.nextLine();

                if (lista.eliminarPorCodigo(codEliminar)) {
                    System.out.println("Alumno eliminado correctamente.");
                } else {
                    System.out.println("Alumno no encontrado.");
                }
                break;

            case 13:
                lista.ordenarPorPromedio();

                System.out.println("Lista ordenada por promedio.");
                lista.recorrerAdelante();
                break;

            case 14:
                System.out.print("Primera posición: ");
                int p1 = Integer.parseInt(teclado.nextLine());

                System.out.print("Segunda posición: ");
                int p2 = Integer.parseInt(teclado.nextLine());

                lista.intercambiar(p1, p2);

                System.out.println("Intercambio realizado.");
                break;

            case 15:
                System.out.print("Código del alumno a modificar: ");
                String codModificar = teclado.nextLine();

                System.out.println("Ingrese los nuevos datos:");

                Alumno datos = leerAlumno();

                if (lista.modificarAlumno(codModificar, datos)) {
                    System.out.println("Alumno modificado correctamente.");
                } else {
                    System.out.println("Alumno no encontrado.");
                }
                break;

            case 16:
                System.out.println("Cantidad de alumnos: "
                        + lista.obtenerTamaño());
                break;

            case 17:
                if (lista.estaVacia()) {
                    System.out.println("La lista está vacía.");
                } else {
                    System.out.println("La lista contiene alumnos.");
                }
                break;

            case 0:
                break;

            default:
                System.out.println("Opción incorrecta.");
        }
    }
}
