package Vista;

import DAO.CListaSE;
import Modelo.Alumno;
import java.util.Scanner;

public class Principal {
    private static final Scanner teclado = new Scanner(System.in);
    private static final CListaSE lista = new CListaSE();

    public static void main(String[] args) {
        int opcion;
        do {
            MenuOpciones.mostrar();
            opcion = leerEntero();
            try {
                ejecutar(opcion);
            } catch (IllegalArgumentException ex) {
                System.out.println("AVISO: " + ex.getMessage());
            }
        } while (opcion != 0);
        // No se cierra System.in durante la ejecucion del menu.
    }

    private static void ejecutar(int opcion) {
        switch (opcion) {
            case 1:
                lista.insertarInicio(leerAlumno());
                System.out.println("Alumno insertado al inicio.");
                break;
            case 2:
                lista.insertarFinal(leerAlumno());
                System.out.println("Alumno insertado al final.");
                break;
            case 3:
                int posicionInsertar = pedirEntero("Posicion (desde 1): ");
                lista.insertarEnPosicion(leerAlumno(), posicionInsertar);
                System.out.println("Alumno insertado en posicion " + posicionInsertar);
                break;
            case 4:
                String codRefIns = pedirTexto("Codigo del alumno de referencia: ");
                Alumno refInsertar = lista.buscarPorCodigo(codRefIns);
                if (refInsertar == null) {
                    System.out.println("El codigo de referencia no existe.");
                    break;
                }
                lista.insertarPorReferencia(refInsertar, leerAlumno());
                System.out.println("Alumno insertado despues de " + codRefIns);
                break;
            case 5:
                mostrarEliminado(lista.eliminarInicio());
                break;
            case 6:
                mostrarEliminado(lista.eliminarFinal());
                break;
            case 7:
                mostrarEliminado(lista.eliminarEnPosicion(pedirEntero("Posicion (desde 1): ")));
                break;
            case 8:
                String codRefEliminar = pedirTexto("Codigo del alumno a eliminar: ");
                Alumno refEliminar = lista.buscarPorCodigo(codRefEliminar);
                mostrarEliminado(lista.eliminarPorReferencia(refEliminar));
                break;
            case 9:
                Alumno encontrado = lista.buscarPorCodigo(pedirTexto("Codigo a buscar: "));
                System.out.println(encontrado == null ? "Alumno no encontrado." : encontrado);
                break;
            case 10:
                System.out.println("\n" + lista.mostrarTodos());
                break;
            case 11:
                lista.ordenar(false);
                System.out.println("Ordenado por codigo (A-Z).\n" + lista.mostrarTodos());
                break;
            case 12:
                lista.ordenar(true);
                System.out.println("Ordenado por promedio (mayor a menor).\n" + lista.mostrarTodos());
                break;
            case 13:
                String codigo1 = pedirTexto("Codigo del primer alumno: ");
                String codigo2 = pedirTexto("Codigo del segundo alumno: ");
                System.out.println(lista.intercambiar(codigo1, codigo2)
                        ? "Alumnos intercambiados." : "Uno o ambos codigos no existen.");
                break;
            case 14:
                System.out.println("Cantidad de alumnos: " + lista.obtenerTamanio());
                break;
            case 15:
                String codigo = pedirTexto("Codigo del alumno a modificar: ");
                if (lista.buscarPorCodigo(codigo) == null) {
                    System.out.println("Alumno no encontrado.");
                    break;
                }
                String nombre = pedirTexto("Nuevo nombre: ");
                int edad = pedirEntero("Nueva edad: ");
                double promedio = pedirDecimal("Nuevo promedio (0 a 20): ");
                lista.modificar(codigo, nombre, edad, promedio);
                System.out.println("Alumno modificado. Se conserva su codigo.");
                break;
            case 16:
                System.out.println("La lista esta vacia: " + lista.estaVacia());
                break;
            case 0:
                System.out.println("Saliendo del sistema...");
                break;
            default:
                System.out.println("Opcion no valida.");
        }
    }

    private static Alumno leerAlumno() {
        String codigo = pedirTexto("Codigo: ");
        String nombre = pedirTexto("Nombre: ");
        int edad = pedirEntero("Edad: ");
        double promedio = pedirDecimal("Promedio (0 a 20): ");
        return new Alumno(codigo, nombre, edad, promedio);
    }

    private static void mostrarEliminado(Alumno alumno) {
        System.out.println(alumno == null ? "La lista esta vacia o no se encontro el alumno."
                : "Alumno eliminado: " + alumno);
    }

    private static String pedirTexto(String mensaje) {
        System.out.print(mensaje);
        return teclado.nextLine().trim();
    }

    private static int leerEntero() {
        String texto = teclado.nextLine().trim();
        try {
            return Integer.parseInt(texto);
        } catch (NumberFormatException ex) {
            System.out.println("Debe ingresar un numero entero.");
            return -1;
        }
    }

    private static int pedirEntero(String mensaje) {
        String texto = pedirTexto(mensaje);
        try {
            return Integer.parseInt(texto);
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Debe ingresar un numero entero.");
        }
    }

    private static double pedirDecimal(String mensaje) {
        String texto = pedirTexto(mensaje).replace(',', '.');
        try {
            return Double.parseDouble(texto);
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Debe ingresar un numero decimal valido.");
        }
    }
}
