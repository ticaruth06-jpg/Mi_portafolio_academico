package Vista;

public class MenuOpciones {
    public static void mostrar() {
        System.out.println("\n===================================================");
        System.out.println("       SISTEMA DE GESTION DE ALUMNOS");
        System.out.println("          LISTA SIMPLEMENTE ENLAZADA");
        System.out.println("===================================================");
        System.out.println("       INSERCION            ");
        System.out.println("  1. Insertar alumno al inicio");
        System.out.println("  2. Insertar alumno al final");
        System.out.println("  3. Insertar alumno en posicion X");
        System.out.println("  4. Insertar alumno por referencia (despues)");
        System.out.println("       ELIMINACION           ");
        System.out.println("  5. Eliminar alumno al inicio");
        System.out.println("  6. Eliminar alumno al final");
        System.out.println("  7. Eliminar alumno de posicion X");
        System.out.println("  8. Eliminar alumno por referencia / codigo");
        System.out.println(" ----------- ");
        System.out.println("  9. Buscar alumno por codigo");
        System.out.println(" 10. Mostrar todos los alumnos");
        System.out.println(" 11. Ordenar alumnos por codigo (ascendente)");
        System.out.println(" 12. Ordenar alumnos por promedio (descendente)");
        System.out.println(" 13. Intercambiar dos alumnos");
        System.out.println(" 14. Mostrar cantidad de alumnos");
        System.out.println(" 15. Modificar datos de un alumno");
        System.out.println(" 16. Verificar si la lista esta vacia");
        System.out.println("  0. Salir del sistema");
        System.out.println("===================================================");
        System.out.print("Seleccione una opcion: ");
    }
}
