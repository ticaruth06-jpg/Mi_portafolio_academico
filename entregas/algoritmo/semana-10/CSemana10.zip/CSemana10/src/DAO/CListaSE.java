package DAO;

import Modelo.Alumno;
import Modelo.CNodo;

public class CListaSE {
    private CNodo inicio;
    private int cantidad;

    public CListaSE() {
        inicio = null;
        cantidad = 0;
    }

    // 1. Insertar alumno al inicio
    public void insertarInicio(Alumno alumno) {
        validarAlumnoNuevo(alumno);
        CNodo nuevo = new CNodo(alumno);
        nuevo.setSiguiente(inicio);
        inicio = nuevo;
        cantidad++;
    }

    // 2. Insertar alumno al final
    public void insertarFinal(Alumno alumno) {
        validarAlumnoNuevo(alumno);
        CNodo nuevo = new CNodo(alumno);
        if (estaVacia()) {
            inicio = nuevo;
        } else {
            CNodo actual = inicio;
            while (actual.getSiguiente() != null) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(nuevo);
        }
        cantidad++;
    }

    // 3. Insertar alumno en posicion X
    public void insertarEnPosicion(Alumno alumno, int posicion) {
        if (posicion < 1 || posicion > cantidad + 1) {
            throw new IllegalArgumentException("Posicion valida: 1 a " + (cantidad + 1));
        }
        if (posicion == 1) {
            insertarInicio(alumno);
            return;
        }
        validarAlumnoNuevo(alumno);
        CNodo anterior = inicio;
        for (int i = 1; i < posicion - 1; i++) {
            anterior = anterior.getSiguiente();
        }
        CNodo nuevo = new CNodo(alumno);
        nuevo.setSiguiente(anterior.getSiguiente());
        anterior.setSiguiente(nuevo);
        cantidad++;
    }

    // 4. Insertar alumno por referencia (despues)
    public void insertarPorReferencia(Alumno referencia, Alumno alumno) {
        if (referencia == null) {
            throw new IllegalArgumentException("No existe el alumno de referencia.");
        }
        validarAlumnoNuevo(alumno);
        CNodo actual = inicio;
        while (actual != null && actual.getAlumno() != referencia) {
            actual = actual.getSiguiente();
        }
        if (actual == null) {
            throw new IllegalArgumentException("La referencia no pertenece a la lista.");
        }
        CNodo nuevo = new CNodo(alumno);
        nuevo.setSiguiente(actual.getSiguiente());
        actual.setSiguiente(nuevo);
        cantidad++;
    }

    // 5. Eliminar alumno al inicio
    public Alumno eliminarInicio() {
        if (estaVacia()) return null;
        Alumno eliminado = inicio.getAlumno();
        inicio = inicio.getSiguiente();
        cantidad--;
        return eliminado;
    }

    // 6. Eliminar alumno al final
    public Alumno eliminarFinal() {
        if (estaVacia()) return null;
        if (inicio.getSiguiente() == null) return eliminarInicio();
        CNodo anterior = inicio;
        while (anterior.getSiguiente().getSiguiente() != null) {
            anterior = anterior.getSiguiente();
        }
        Alumno eliminado = anterior.getSiguiente().getAlumno();
        anterior.setSiguiente(null);
        cantidad--;
        return eliminado;
    }

    // 7. Eliminar alumno de posicion X
    public Alumno eliminarEnPosicion(int posicion) {
        if (estaVacia()) return null;
        if (posicion < 1 || posicion > cantidad) {
            throw new IllegalArgumentException("Posicion valida: 1 a " + cantidad);
        }
        if (posicion == 1) return eliminarInicio();
        CNodo anterior = inicio;
        for (int i = 1; i < posicion - 1; i++) {
            anterior = anterior.getSiguiente();
        }
        CNodo eliminado = anterior.getSiguiente();
        anterior.setSiguiente(eliminado.getSiguiente());
        cantidad--;
        return eliminado.getAlumno();
    }

    // 8. Eliminar alumno por referencia / codigo
    public Alumno eliminarPorReferencia(Alumno referencia) {
        if (estaVacia() || referencia == null) return null;
        if (inicio.getAlumno() == referencia) return eliminarInicio();
        CNodo anterior = inicio;
        while (anterior.getSiguiente() != null) {
            if (anterior.getSiguiente().getAlumno() == referencia) {
                CNodo eliminado = anterior.getSiguiente();
                anterior.setSiguiente(eliminado.getSiguiente());
                cantidad--;
                return eliminado.getAlumno();
            }
            anterior = anterior.getSiguiente();
        }
        return null;
    }

    // 9. Buscar alumno por codigo
    public Alumno buscarPorCodigo(String codigo) {
        if (codigo == null) return null;
        CNodo actual = inicio;
        while (actual != null) {
            if (actual.getAlumno().getCodigo().equalsIgnoreCase(codigo.trim())) {
                return actual.getAlumno();
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    // 10. Mostrar todos los alumnos
    public String mostrarTodos() {
        if (estaVacia()) return "No hay alumnos registrados.";
        StringBuilder texto = new StringBuilder();
        CNodo actual = inicio;
        int posicion = 1;
        while (actual != null) {
            texto.append(posicion).append(". ").append(actual.getAlumno())
                    .append(System.lineSeparator());
            actual = actual.getSiguiente();
            posicion++;
        }
        return texto.toString();
    }

    // 11. Ordenar alumnos por codigo (ascendente)
    public void ordenarPorCodigo() {
        ordenar(false);
    }

    // 12. Ordenar alumnos por promedio (descendente)
    public void ordenarPorPromedio() {
        ordenar(true);
    }

    // Método auxiliar de ordenamiento compartido
    public void ordenar(boolean porPromedio) {
        for (int i = 0; i < cantidad - 1; i++) {
            CNodo actual = inicio;
            while (actual.getSiguiente() != null) {
                Alumno a = actual.getAlumno();
                Alumno b = actual.getSiguiente().getAlumno();
                boolean cambiar = porPromedio
                        ? a.getPromedio() < b.getPromedio()
                        : a.getCodigo().compareToIgnoreCase(b.getCodigo()) > 0;
                if (cambiar) {
                    actual.setAlumno(b);
                    actual.getSiguiente().setAlumno(a);
                }
                actual = actual.getSiguiente();
            }
        }
    }

    // 13. Intercambiar dos alumnos
    public boolean intercambiar(String codigo1, String codigo2) {
        CNodo primero = buscarNodo(codigo1);
        CNodo segundo = buscarNodo(codigo2);
        if (primero == null || segundo == null) return false;
        Alumno temporal = primero.getAlumno();
        primero.setAlumno(segundo.getAlumno());
        segundo.setAlumno(temporal);
        return true;
    }

    // 14. Mostrar cantidad de alumnos
    public int obtenerTamanio() {
        return cantidad;
    }

    // 15. Modificar datos de un alumno
    public boolean modificar(String codigo, String nombre, int edad, double promedio) {
        Alumno alumno = buscarPorCodigo(codigo);
        if (alumno == null) return false;
        // Validar todos los datos ANTES de modificar algún atributo.
        Alumno datosValidos = new Alumno(alumno.getCodigo(), nombre, edad, promedio);
        alumno.setNombre(datosValidos.getNombre());
        alumno.setEdad(datosValidos.getEdad());
        alumno.setPromedio(datosValidos.getPromedio());
        return true;
    }

    // 16. Verificar si la lista esta vacia
    public boolean estaVacia() {
        return inicio == null;
    }

    private CNodo buscarNodo(String codigo) {
        if (codigo == null) return null;
        CNodo actual = inicio;
        while (actual != null) {
            if (actual.getAlumno().getCodigo().equalsIgnoreCase(codigo.trim())) {
                return actual;
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    private void validarAlumnoNuevo(Alumno alumno) {
        if (alumno == null) {
            throw new IllegalArgumentException("El alumno no puede ser null.");
        }
        if (buscarPorCodigo(alumno.getCodigo()) != null) {
            throw new IllegalArgumentException("Ya existe un alumno con ese codigo.");
        }
    }
}