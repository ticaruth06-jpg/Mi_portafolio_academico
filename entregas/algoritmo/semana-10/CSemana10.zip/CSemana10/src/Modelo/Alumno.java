package Modelo;

public class Alumno {
    private final String codigo;
    private String nombre;
    private int edad;
    private double promedio;

    public Alumno(String codigo, String nombre, int edad, double promedio) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El codigo es obligatorio.");
        }
        this.codigo = codigo.trim().toUpperCase(java.util.Locale.ROOT);
        setNombre(nombre);
        setEdad(edad);
        setPromedio(promedio);
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public int getEdad() { return edad; }
    public double getPromedio() { return promedio; }

    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre es obligatorio.");
        }
        this.nombre = nombre.trim();
    }

    public void setEdad(int edad) {
        if (edad <= 0) {
            throw new IllegalArgumentException("La edad debe ser positiva.");
        }
        this.edad = edad;
    }

    public void setPromedio(double promedio) {
        if (!Double.isFinite(promedio) || promedio < 0 || promedio > 20) {
            throw new IllegalArgumentException("El promedio debe estar entre 0 y 20.");
        }
        this.promedio = promedio;
    }

    @Override
    public String toString() {
        return String.format(java.util.Locale.US,
                "Codigo: %s | Nombre: %s | Edad: %d | Promedio: %.2f",
                codigo, nombre, edad, promedio);
    }
}
