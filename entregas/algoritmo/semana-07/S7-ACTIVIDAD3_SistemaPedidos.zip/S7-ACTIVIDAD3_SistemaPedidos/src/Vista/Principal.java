package Vista;

import DAO.ColaPedidos;
import Modelo.Pedido;
import java.util.Scanner;

public class Principal {

    private static final Scanner teclado = new Scanner(System.in);
    private static final ColaPedidos gestorPedidos = new ColaPedidos();

    public static void main(String[] args) {
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opción: ");
            System.out.println();

            try {
                switch (opcion) {
                    case 1:
                        registrarPedido();
                        break;
                    case 2:
                        despacharPedido();
                        break;
                    case 3:
                        consultarSiguientePedido();
                        break;
                    case 4:
                        gestorPedidos.mostrarCola();
                        break;
                    case 5:
                        verificarColaVacia();
                        break;
                    case 6:
                        buscarPedido();
                        break;
                    case 7:
                        calcularMontoTotal();
                        break;
                    case 8:
                        cancelarPedidoEspecifico();
                        break;
                    case 0:
                        System.out.println("Saliendo del Sistema de Gestión de Pedidos...");
                        break;
                    default:
                        System.out.println("Opción no válida. Intente nuevamente.");
                }
            } catch (IllegalArgumentException | IllegalStateException e) {
                System.out.println("Error operativo: " + e.getMessage());
            }

            if (opcion != 0) {
                System.out.println("\nPresione ENTER para continuar...");
                teclado.nextLine();
            }
        } while (opcion != 0);

        teclado.close();
    }

    private static void mostrarMenu() {
        System.out.println("\n=============================================");
        System.out.println("   SISTEMA DE GESTION DE PEDIDOS DE COCINA   ");
        System.out.println("=============================================");
        System.out.println("1. Registrar / Encolar nuevo pedido");
        System.out.println("2. Despachar / Desencolar pedido (Frente)");
        System.out.println("3. Consultar siguiente pedido (Peek)");
        System.out.println("4. Mostrar cola de pedidos pendientes");
        System.out.println("5. Verificar si la cola está vacía");
        System.out.println("6. Buscar pedido por código o cliente");
        System.out.println("7. Calcular monto total acumulado en cola");
        System.out.println("8. Cancelar / Eliminar pedido específico");
        System.out.println("0. Salir");
        System.out.println("=============================================");
    }

    private static void registrarPedido() {
        System.out.println("--- REGISTRAR NUEVO PEDIDO ---");
        String codigo = leerTexto("Código de pedido: ");
        String cliente = leerTexto("Nombre del cliente: ");
        String platillo = leerTexto("Descripción del platillo: ");
        double monto = leerDecimal("Monto total (S/.): ");
        String tipo = leerTexto("Tipo de comida (Ej. Marina, Criolla, Italiana): ");
        String hora = leerTexto("Hora de registro (Ej. 14:30): ");

        Pedido nuevo = new Pedido(codigo, cliente, platillo, monto, tipo, hora);
        gestorPedidos.encolar(nuevo);
        System.out.println("¡Pedido registrado y encolado exitosamente!");
    }

    private static void despacharPedido() {
        Pedido atendido = gestorPedidos.desencolar();
        System.out.println("¡Pedido despachado con éxito!");
        System.out.println(atendido);
    }

    private static void consultarSiguientePedido() {
        Pedido siguiente = gestorPedidos.consultarSiguiente();
        System.out.println("Próximo pedido a preparar en cocina:");
        System.out.println(siguiente);
    }

    private static void verificarColaVacia() {
        if (gestorPedidos.estaVacia()) {
            System.out.println("La cola se encuentra vacía. No hay pedidos pendientes.");
        } else {
            System.out.println("La cola NO está vacía. Hay " + gestorPedidos.getTamanio() + " pedido(s) en espera.");
        }
    }

    private static void buscarPedido() {
        String criterio = leerTexto("Ingrese el código o nombre del cliente a buscar: ");
        Pedido encontrado = gestorPedidos.buscarPedido(criterio);
        if (encontrado != null) {
            System.out.println("¡Pedido encontrado!\n" + encontrado);
        } else {
            System.out.println("No se encontró ninguna coincidencia con los datos ingresados.");
        }
    }

    private static void calcularMontoTotal() {
        double total = gestorPedidos.calcularMontoTotalAcumulado();
        System.out.printf("Valor económico total de los pedidos en proceso: S/. %.2f\n", total);
    }

    private static void cancelarPedidoEspecifico() {
        String codigo = leerTexto("Ingrese el código exacto del pedido a cancelar: ");
        Pedido cancelado = gestorPedidos.cancelarPedidoPorCodigo(codigo);
        System.out.println("El pedido ha sido cancelado y retirado correctamente:");
        System.out.println(cancelado);
    }

    private static String leerTexto(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = teclado.nextLine().trim();
            if (!texto.isEmpty()) {
                return texto;
            }
            System.out.println("Este campo no puede estar vacío. Intente nuevamente.");
        }
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String entrada = teclado.nextLine().trim();
            try {
                return Integer.parseInt(entrada);
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingrese un número entero válido.");
            }
        }
    }

    private static double leerDecimal(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String entrada = teclado.nextLine().trim().replace(',', '.');
            try {
                double valor = Double.parseDouble(entrada);
                if (Double.isFinite(valor) && valor > 0) {
                    return valor;
                }
                System.out.println("Ingrese un valor numérico mayor a cero.");
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingrese un número decimal válido.");
            }
        }
    }
}