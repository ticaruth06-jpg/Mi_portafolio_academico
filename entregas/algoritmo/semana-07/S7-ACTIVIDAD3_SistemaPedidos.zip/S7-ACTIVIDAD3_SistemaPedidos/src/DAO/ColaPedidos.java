package DAO;

import Modelo.Nodo;
import Modelo.Pedido;

public class ColaPedidos {

    private Nodo frente;
    private Nodo fin;
    private int tamanio;

    public ColaPedidos() {
        this.frente = null;
        this.fin = null;
        this.tamanio = 0;
    }

    // 5. Verificar si la Cola está Vacía[cite: 10]
    public boolean estaVacia() {
        return frente == null;
    }

    public int getTamanio() {
        return tamanio;
    }

    // 1. Registrar / Encolar Pedido[cite: 10]
    public void encolar(Pedido pedido) {
        if (pedido == null) {
            throw new IllegalArgumentException("El pedido no puede ser nulo.");
        }
        Nodo nuevoNodo = new Nodo(pedido);
        if (estaVacia()) {
            frente = nuevoNodo;
        } else {
            fin.setSiguiente(nuevoNodo);
        }
        fin = nuevoNodo;
        tamanio++;
    }

    // 2. Despachar / Desencolar Pedido[cite: 10]
    public Pedido desencolar() {
        if (estaVacia()) {
            throw new IllegalStateException("Underflow: La cola de pedidos está vacía.");
        }
        Pedido pedidoAtendido = frente.getPedido();
        frente = frente.getSiguiente();
        tamanio--;
        if (frente == null) {
            fin = null;
        }
        return pedidoAtendido;
    }

    // 3. Consultar Siguiente Pedido (Peek)[cite: 10]
    public Pedido consultarSiguiente() {
        if (estaVacia()) {
            throw new IllegalStateException("La cola de pedidos está vacía.");
        }
        return frente.getPedido();
    }

    // 4. Mostrar Cola de Pedidos Pendientes[cite: 10]
    public void mostrarCola() {
        if (estaVacia()) {
            System.out.println("No hay pedidos pendientes en cocina.");
            return;
        }
        System.out.println("\n--- LISTA DE PEDIDOS PENDIENTES ---");
        Nodo actual = frente;
        int contador = 1;
        while (actual != null) {
            System.out.println(contador + ". " + actual.getPedido());
            actual = actual.getSiguiente();
            contador++;
        }
    }

    // 6. Buscar Pedido por Código o Cliente[cite: 10]
    public Pedido buscarPedido(String criterio) {
        if (estaVacia()) {
            throw new IllegalStateException("La cola está vacía.");
        }
        criterio = criterio.trim().toLowerCase();
        Nodo actual = frente;
        while (actual != null) {
            Pedido p = actual.getPedido();
            if (p.getCodigoPedido().toLowerCase().contains(criterio) ||
                p.getNombreCliente().toLowerCase().contains(criterio)) {
                return p;
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    // 7. Calcular Monto Total Acumulado en Cola[cite: 10]
    public double calcularMontoTotalAcumulado() {
        if (estaVacia()) {
            return 0.0;
        }
        double acumulado = 0.0;
        Nodo actual = frente;
        while (actual != null) {
            acumulado += actual.getPedido().getMontoTotal();
            actual = actual.getSiguiente();
        }
        return acumulado;
    }

    // 8. Cancelar / Eliminar Pedido Específico por Código[cite: 10]
    public Pedido cancelarPedidoPorCodigo(String codigo) {
        if (estaVacia()) {
            throw new IllegalStateException("La cola está vacía.");
        }
        codigo = codigo.trim();
        
        // Si el pedido a eliminar está exactamente en el frente
        if (frente.getPedido().getCodigoPedido().equalsIgnoreCase(codigo)) {
            return desencolar();
        }

        Nodo actual = frente;
        while (actual.getSiguiente() != null) {
            if (actual.getSiguiente().getPedido().getCodigoPedido().equalsIgnoreCase(codigo)) {
                Pedido eliminado = actual.getSiguiente().getPedido();
                actual.setSiguiente(actual.getSiguiente().getSiguiente());
                tamanio--;
                // Si eliminamos el último nodo, actualizamos el puntero 'fin'
                if (actual.getSiguiente() == null) {
                    fin = actual;
                }
                return eliminado;
            }
            actual = actual.getSiguiente();
        }

        throw new IllegalArgumentException("No se encontró ningún pedido con el código especificado.");
    }
}
