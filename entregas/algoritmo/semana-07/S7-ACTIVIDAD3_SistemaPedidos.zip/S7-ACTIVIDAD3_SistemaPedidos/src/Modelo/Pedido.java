package Modelo;

public class Pedido {

    private String codigoPedido;
    private String nombreCliente;
    private String descripcionPlatillo;
    private double montoTotal;
    private String tipoComida;
    private String horaRegistro;

    public Pedido() {
    }

    public Pedido(String codigoPedido, String nombreCliente, String descripcionPlatillo, 
                  double montoTotal, String tipoComida, String horaRegistro) {
        setCodigoPedido(codigoPedido);
        setNombreCliente(nombreCliente);
        setDescripcionPlatillo(descripcionPlatillo);
        setMontoTotal(montoTotal);
        setTipoComida(tipoComida);
        setHoraRegistro(horaRegistro);
    }

    public String getCodigoPedido() {
        return codigoPedido;
    }

    public void setCodigoPedido(String codigoPedido) {
        if (codigoPedido == null || codigoPedido.trim().isEmpty()) {
            throw new IllegalArgumentException("El código del pedido es obligatorio.");
        }
        this.codigoPedido = codigoPedido.trim();
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        if (nombreCliente == null || nombreCliente.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del cliente es obligatorio.");
        }
        this.nombreCliente = nombreCliente.trim();
    }

    public String getDescripcionPlatillo() {
        return descripcionPlatillo;
    }

    public void setDescripcionPlatillo(String descripcionPlatillo) {
        if (descripcionPlatillo == null || descripcionPlatillo.trim().isEmpty()) {
            throw new IllegalArgumentException("La descripción del platillo es obligatoria.");
        }
        this.descripcionPlatillo = descripcionPlatillo.trim();
    }

    public double getMontoTotal() {
        return montoTotal;
    }

    public void setMontoTotal(double montoTotal) {
        if (!Double.isFinite(montoTotal) || montoTotal <= 0) {
            throw new IllegalArgumentException("El monto total debe ser mayor que cero.");
        }
        this.montoTotal = montoTotal;
    }

    public String getTipoComida() {
        return tipoComida;
    }

    public void setTipoComida(String tipoComida) {
        if (tipoComida == null || tipoComida.trim().isEmpty()) {
            throw new IllegalArgumentException("El tipo de comida es obligatorio.");
        }
        this.tipoComida = tipoComida.trim();
    }

    public String getHoraRegistro() {
        return horaRegistro;
    }

    public void setHoraRegistro(String horaRegistro) {
        if (horaRegistro == null || horaRegistro.trim().isEmpty()) {
            throw new IllegalArgumentException("La hora de registro es obligatoria.");
        }
        this.horaRegistro = horaRegistro.trim();
    }

    @Override
    public String toString() {
        return "Código: " + codigoPedido 
                + " | Cliente: " + nombreCliente 
                + " | Platillo: " + descripcionPlatillo 
                + " | Tipo: " + tipoComida 
                + " | Monto: S/. " + String.format("%.2f", montoTotal) 
                + " | Hora: " + horaRegistro;
    }
}
