package dao;

import Modelo.Cliente;
import modelo.Nodo;

public class ColaAtencion {

    private Nodo frente;
    private Nodo fin;
    private int tamano;

    public ColaAtencion() {
        this.frente = null;
        this.fin = null;
        this.tamano = 0;
    }

    // 5. Verificar si la Cola está Vacía
    public boolean estaVacia() {
        return frente == null;
    }

    public int getTamano() {
        return tamano;
    }

    // 1. Generar / Encolar Ticket
    public void encolar(Cliente cliente) {
        Nodo nuevoNodo = new Nodo(cliente);
        if (estaVacia()) {
            frente = nuevoNodo;
        } else {
            fin.setSiguiente(nuevoNodo);
        }
        fin = nuevoNodo;
        tamano++;
        System.out.println("[Éxito] Ticket generado y encolado correctamente.");
    }

    // 2. Atender / Desencolar Cliente
    public Cliente desencolar() {
        if (estaVacia()) {
            System.out.println("[Advertencia] La cola de atención está vacía. No hay clientes por atender.");
            return null;
        }
        Cliente clienteAtendido = frente.getCliente();
        frente = frente.getSiguiente();
        if (frente == null) {
            fin = null; // Si la cola quedó vacía, actualizamos fin también
        }
        tamano--;
        return clienteAtendido;
    }

    // 3. Consultar Siguiente Turno (Peek)
    public Cliente consultarSiguiente() {
        if (estaVacia()) {
            return null;
        }
        return frente.getCliente();
    }

    // 4. Mostrar Cola de Espera Completa
    public void mostrarCola() {
        if (estaVacia()) {
            System.out.println("La cola de espera se encuentra vacía.");
            return;
        }
        System.out.println("\n--- COLA DE ESPERA ACTUAL (" + tamano + " clientes) ---");
        Nodo actual = frente;
        int posicion = 1;
        while (actual != null) {
            System.out.println(posicion + ". " + actual.getCliente());
            actual = actual.getSiguiente();
            posicion++;
        }
        System.out.println("--------------------------------------------------");
    }

    // 6. Buscar Cliente por Número de Ticket o DNI
    public Cliente buscarCliente(String criterio) {
        if (estaVacia()) {
            return null;
        }

        Nodo actual = frente;
        while (actual != null) {
            Cliente c = actual.getCliente();
            if (c.getNumeroTicket().equalsIgnoreCase(criterio) || c.getDni().equalsIgnoreCase(criterio)) {
                return c;
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    // 7. Filtrar Turnos por Tipo de Trámite
    public void filtrarPorTramite(String tipoTramite) {
        if (estaVacia()) {
            System.out.println("No hay clientes en la cola para filtrar.");
            return;
        }

        System.out.println("\n--- FILTRO DE CLIENTES POR TRÁMITE: [" + tipoTramite.toUpperCase() + "] ---");
        Nodo actual = frente;
        int encontrados = 0;
        while (actual != null) {
            Cliente c = actual.getCliente();
            if (c.getTipoTramite().toLowerCase().contains(tipoTramite.toLowerCase())) {
                System.out.println(c);
                encontrados++;
            }
            actual = actual.getSiguiente();
        }
        if (encontrados == 0) {
            System.out.println("No se encontraron clientes con ese tipo de trámite.");
        }
        System.out.println("---------------------------------------------------------");
    }

    // 8. Cancelar / Eliminar Turno Específico por Ticket
    public boolean eliminarPorTicket(String numeroTicket) {
        if (estaVacia()) {
            return false;
        }

        // Caso 1: El elemento a eliminar está en el frente
        if (frente.getCliente().getNumeroTicket().equalsIgnoreCase(numeroTicket)) {
            desencolar();
            return true;
        }

        // Caso 2: El elemento está en medio o al final
        Nodo actual = frente;
        Nodo anterior = null;

        while (actual != null && !actual.getCliente().getNumeroTicket().equalsIgnoreCase(numeroTicket)) {
            anterior = actual;
            actual = actual.getSiguiente();
        }

        if (actual == null) {
            return false; // No encontrado
        }

        // Desenlazar nodo
        anterior.setSiguiente(actual.getSiguiente());
        if (actual == fin) {
            fin = anterior; // Actualizar fin si era el último
        }
        tamano--;
        return true;
    }
}
