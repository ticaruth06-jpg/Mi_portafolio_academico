package vista;

import dao.ColaAtencion;
import Modelo.Cliente;

import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        ColaAtencion colaBanco = new ColaAtencion();
        int opcion = 0;

        do {
            System.out.println("\n=================================================");
            System.out.println("   SISTEMA DE GESTION DE TURNOS - BANCO DIGITAL");
            System.out.println("=================================================");
            System.out.println("1. Generar / Encolar Ticket");
            System.out.println("2. Atender / Desencolar Cliente");
            System.out.println("3. Consultar Siguiente Turno");
            System.out.println("4. Mostrar Cola de Espera Completa");
            System.out.println("5. Verificar si la Cola esta Vacia");
            System.out.println("6. Buscar Cliente por Ticket o DNI");
            System.out.println("7. Filtrar Turnos por Tipo de Tramite");
            System.out.println("8. Cancelar / Eliminar Turno Especifico");
            System.out.println("9. Salir");
            System.out.print("Seleccione una opcion: ");

            if (!teclado.hasNextInt()) {
                System.out.println("[Error] Ingrese un número válido.");
                teclado.next();
                continue;
            }
            opcion = teclado.nextInt();
            teclado.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese Numero de Ticket (ej. T-001): ");
                    String ticket = teclado.nextLine();
                    System.out.print("Ingrese DNI del cliente: ");
                    String dni = teclado.nextLine();
                    System.out.print("Ingrese Nombre completo: ");
                    String nombre = teclado.nextLine();
                    System.out.print("Ingrese Tipo de Tramite (Depósito, Retiro, Reclamo, etc.): ");
                    String tramite = teclado.nextLine();
                    System.out.print("Ingrese Prioridad (1: Normal, 2: Preferencial): ");
                    int prioridad = teclado.nextInt();
                    teclado.nextLine();
                    System.out.print("Ingrese Hora de llegada (ej. 10:15 AM): ");
                    String hora = teclado.nextLine();

                    Cliente nuevoCliente = new Cliente(ticket, dni, nombre, tramite, prioridad, hora);
                    colaBanco.encolar(nuevoCliente);
                    break;

                case 2:
                    Cliente atendido = colaBanco.desencolar();
                    if (atendido != null) {
                        System.out.println("\n[ATENCIÓN EN VENTANILLA] Pasando a cliente:");
                        System.out.println(atendido);
                    }
                    break;

                case 3:
                    Cliente siguiente = colaBanco.consultarSiguiente();
                    if (siguiente != null) {
                        System.out.println("\n[PRÓXIMO TURNO]: " + siguiente);
                    } else {
                        System.out.println("La cola está vacía. No hay turnos pendientes.");
                    }
                    break;

                case 4:
                    colaBanco.mostrarCola();
                    break;

                case 5:
                    if (colaBanco.estaVacia()) {
                        System.out.println("Estado: La cola SÍ está vacía.");
                    } else {
                        System.out.println("Estado: La cola NO está vacía. Hay " + colaBanco.getTamano() + " cliente(s) en espera.");
                    }
                    break;

                case 6:
                    System.out.print("Ingrese el Número de Ticket o DNI a buscar: ");
                    String criterio = teclado.nextLine();
                    Cliente encontrado = colaBanco.buscarCliente(criterio);
                    if (encontrado != null) {
                        System.out.println("\n[Cliente Encontrado]: " + encontrado);
                    } else {
                        System.out.println("[Resultado] No se encontró ningún registro con ese criterio.");
                    }
                    break;

                case 7:
                    System.out.print("Ingrese el tipo de trámite a filtrar: ");
                    String filtroTramite = teclado.nextLine();
                    colaBanco.filtrarPorTramite(filtroTramite);
                    break;

                case 8:
                    System.out.print("Ingrese el Número de Ticket del turno a cancelar: ");
                    String ticketEliminar = teclado.nextLine();
                    boolean eliminado = colaBanco.eliminarPorTicket(ticketEliminar);
                    if (eliminado) {
                        System.out.println("[Éxito] El turno " + ticketEliminar + " fue cancelado y retirado de la cola.");
                    } else {
                        System.out.println("[Error] No se encontró el ticket especificado en la cola.");
                    }
                    break;

                case 9:
                    System.out.println("Saliendo del sistema de gestión de turnos...");
                    break;

                default:
                    System.out.println("[Error] Opción inválida. Intente de nuevo.");
            }
        } while (opcion != 9);

        teclado.close();
    }
}
