package Vista;



import java.util.Scanner;
import DAO.ColaAlumno;
import Modelo.Alumno;

public class Principal {

    private static final Scanner teclado = new Scanner(System.in);
    private static ColaAlumno cola;

    public static void main(String[] args) {

        System.out.println("==================================");
        System.out.println(" SISTEMA DE GESTION DE ALUMNOS");
        System.out.println(" Estructura de datos: COLA FIFO");
        System.out.println("==================================");

        int capacidad = leerEntero("Ingrese la capacidad de la cola: ");
        cola = new ColaAlumno(capacidad);
        int opcion;

        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opcion: ");
            try {
                switch (opcion) {
                    case 1:
                        insertarAlumno();
                        break;

                    case 2:
                        eliminarAlumno();
                        break;

                    case 3:
                        consultarAlumno();
                        break;

                    case 4:
                        cola.mostrarTodos();
                        break;

                    case 5:
                        System.out.println(cola.estaVacia()
                                ? "La cola esta vacia."
                                : "La cola contiene alumnos.");
                        break;

                    case 6:
                        System.out.println(cola.estaLlena()
                                ? "La cola esta llena."
                                : "La cola tiene espacio disponible.");
                        break;

                    case 7:
                        System.out.println("Alumnos registrados: "
                                + cola.tamanio()
                                + " de " + cola.capacidad());
                        break;

                    case 8:
                        buscarAlumnoPorCodigo();
                        break;

                    case 9:
                        calcularPromedioGeneral();
                        break;

                    case 10:
                        filtrarAlumnosRendimiento();
                        break;

                    case 11:
                        cola.mostrarMayorYMenorPromedio();
                        break;

                    case 12:
                        cola.invertir();
                        System.out.println("La cola ha sido invertida exitosamente usando una Pila.");
                        break;

                    case 13:
                        eliminarAlumnoPorCodigo();
                        break;

                    case 0:
                        System.out.println("Fin del programa.");
                        break;

                    default:
                        System.out.println("Opcion no valida.");
                }

            } catch (IllegalArgumentException
                    | IllegalStateException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (opcion != 0);
        teclado.close();
    }

    private static void mostrarMenu() {
        System.out.println("\n========== MENU PRINCIPAL ==========");
        System.out.println("1. Insertar alumno");
        System.out.println("2. Eliminar alumno (frente)");
        System.out.println("3. Consultar alumno del frente");
        System.out.println("4. Mostrar todos los alumnos");
        System.out.println("5. Verificar si la cola esta vacia");
        System.out.println("6. Verificar si la cola esta llena");
        System.out.println("7. Mostrar cantidad de alumnos");
        System.out.println("8. Buscar alumno por codigo");
        System.out.println("9. Calcular promedio general del grupo");
        System.out.println("10. Filtrar alumnos por rendimiento academico");
        System.out.println("11. Obtener alumno con mayor y menor promedio");
        System.out.println("12. Invertir el orden de la cola");
        System.out.println("13. Eliminar alumno por codigo especifico");
        System.out.println("0. Salir");
        System.out.println("=====================================");
    }

    private static void insertarAlumno() {
        System.out.println("\n--- REGISTRAR ALUMNO ---");

        String codigo = leerTexto("Codigo: ");
        String nombre = leerTexto("Nombre completo: ");
        int edad = leerEntero("Edad: ");
        double promedio = leerDecimal("Promedio (0-20): ");

        Alumno alumno = new Alumno(codigo, nombre, edad, promedio);
        cola.insertar(alumno);

        System.out.println("Alumno registrado correctamente.");
    }

    private static void eliminarAlumno() {
        Alumno alumno = cola.eliminar();
        System.out.println("Alumno retirado de la cola:");
        System.out.println(alumno);
    }

    private static void consultarAlumno() {
        Alumno alumno = cola.consultar();
        System.out.println("Alumno ubicado en el frente:");
        System.out.println(alumno);
    }

    private static void buscarAlumnoPorCodigo() {
        String codigo = leerTexto("Ingrese el codigo a buscar: ");
        Alumno alumno = cola.buscarPorCodigo(codigo);
        if (alumno != null) {
            System.out.println("Alumno encontrado:\n" + alumno);
        } else {
            System.out.println("No se encontro ningun alumno con el codigo especificado.");
        }
    }

    private static void calcularPromedioGeneral() {
        double promedioGeneral = cola.calcularPromedioGeneral();
        System.out.printf("El promedio general del grupo es: %.2f\n", promedioGeneral);
    }

    private static void filtrarAlumnosRendimiento() {
        double umbral = leerDecimal("Ingrese el promedio umbral de corte (ej. 14.0): ");
        cola.mostrarFiltradosPorRendimiento(umbral);
    }

    private static void eliminarAlumnoPorCodigo() {
        String codigo = leerTexto("Ingrese el codigo del alumno a eliminar: ");
        Alumno alumno = cola.eliminarPorCodigo(codigo);
        System.out.println("Alumno eliminado correctamente:\n" + alumno);
    }

    private static String leerTexto(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = teclado.nextLine().trim();

            if (!texto.isEmpty()) {
                return texto;
            }

            System.out.println("El campo no puede estar vacio.");
        }
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String entrada = teclado.nextLine().trim();

            try {
                return Integer.parseInt(entrada);
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un numero entero valido.");
            }
        }
    }

    private static double leerDecimal(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String entrada = teclado.nextLine().trim().replace(',', '.');

            try {
                double valor = Double.parseDouble(entrada);

                if (Double.isFinite(valor)) {
                    return valor;
                }

                System.out.println("Ingrese un numero decimal finito.");

            } catch (NumberFormatException e) {
                System.out.println("Ingrese un numero decimal valido.");
            }
        }
    }
}