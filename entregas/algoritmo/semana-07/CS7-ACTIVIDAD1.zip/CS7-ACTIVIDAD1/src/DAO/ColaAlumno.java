package DAO;

import Modelo.Alumno;
import java.util.Stack;

public class ColaAlumno {

    private final Alumno[] alumnos;
    private int frente;
    private int finalCola;
    private int cantidad;

    public ColaAlumno(int capacidad) {
        if (capacidad <= 0) {
            throw new IllegalArgumentException("La capacidad debe ser mayor que cero.");
        }

        alumnos = new Alumno[capacidad];
        frente = 0;
        finalCola = -1;
        cantidad = 0;
    }

    // Verifica si la cola está vacía.
    public boolean estaVacia() {
        return cantidad == 0;
    }

    // Verifica si la cola está llena.
    public boolean estaLlena() {
        return cantidad == alumnos.length;
    }

    // Devuelve el número de alumnos.
    public int tamanio() {
        return cantidad;
    }

    // Devuelve la capacidad máxima.
    public int capacidad() {
        return alumnos.length;
    }

    // 1 Inserta un alumno al final.
    public void insertar(Alumno alumno) {
        if (alumno == null) {
            throw new IllegalArgumentException(
                    "El alumno no puede ser null.");
        }

        if (estaLlena()) {
            throw new IllegalStateException(
                    "Overflow: la cola está llena.");
        }

        finalCola = (finalCola + 1) % alumnos.length;
        alumnos[finalCola] = alumno;
        cantidad++;
    }

    // 2 Elimina y devuelve el alumno del frente.
    public Alumno eliminar() {
        if (estaVacia()) {
            throw new IllegalStateException(
                    "Underflow: la cola está vacía.");
        }

        Alumno alumno = alumnos[frente];
        alumnos[frente] = null;

        frente = (frente + 1) % alumnos.length;
        cantidad--;

        if (cantidad == 0) {
            frente = 0;
            finalCola = -1;
        }

        return alumno;
    }

    // 3 Consulta el alumno del frente sin eliminarlo.
    public Alumno consultar() {
        if (estaVacia()) {
            throw new IllegalStateException("La cola está vacía.");
        }

        return alumnos[frente];
    }

    // 4 Muestra todos los alumnos en orden FIFO.
    public void mostrarTodos() {
        if (estaVacia()) {
            System.out.println("No hay alumnos registrados.");
            return;
        }

        System.out.println("\n--- ALUMNOS EN LA COLA ---");

        for (int i = 0; i < cantidad; i++) {
            int indice = (frente + i) % alumnos.length;

            System.out.println(
                    (i + 1) + ". " + alumnos[indice]);
        }
    }

    // --- OPERACIONES Y CONSULTAS AVANZADAS ---

    // 8. Buscar alumno por código sin alterar el orden original
    public Alumno buscarPorCodigo(String codigo) {
        if (estaVacia()) {
            throw new IllegalStateException("La cola está vacía.");
        }
        codigo = codigo.trim();
        for (int i = 0; i < cantidad; i++) {
            int indice = (frente + i) % alumnos.length;
            if (alumnos[indice].getCodigo().equalsIgnoreCase(codigo)) {
                return alumnos[indice];
            }
        }
        return null;
    }

    // 9. Calcular promedio general del grupo
    public double calcularPromedioGeneral() {
        if (estaVacia()) {
            throw new IllegalStateException("La cola está vacía, no hay promedios que calcular.");
        }
        double suma = 0;
        for (int i = 0; i < cantidad; i++) {
            int indice = (frente + i) % alumnos.length;
            suma += alumnos[indice].getPromedio();
        }
        return suma / cantidad;
    }

    // 10. Filtrar alumnos por rendimiento académico (>= umbral)
    public void mostrarFiltradosPorRendimiento(double umbral) {
        if (estaVacia()) {
            System.out.println("No hay alumnos registrados.");
            return;
        }
        boolean encontrado = false;
        System.out.println("\n--- ALUMNOS CON PROMEDIO >= " + umbral + " ---");
        int contador = 1;
        for (int i = 0; i < cantidad; i++) {
            int indice = (frente + i) % alumnos.length;
            if (alumnos[indice].getPromedio() >= umbral) {
                System.out.println(contador + ". " + alumnos[indice]);
                contador++;
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontraron alumnos que superen el umbral indicado.");
        }
    }

    // 11. Obtener alumno con mayor y menor promedio
    public void mostrarMayorYMenorPromedio() {
        if (estaVacia()) {
            throw new IllegalStateException("La cola está vacía.");
        }
        Alumno mayor = alumnos[frente];
        Alumno menor = alumnos[frente];

        for (int i = 1; i < cantidad; i++) {
            int indice = (frente + i) % alumnos.length;
            Alumno actual = alumnos[indice];
            if (actual.getPromedio() > mayor.getPromedio()) {
                mayor = actual;
            }
            if (actual.getPromedio() < menor.getPromedio()) {
                menor = actual;
            }
        }

        System.out.println("\n--- ESTADÍSTICAS DE PROMEDIOS ---");
        System.out.println("Alumno con MAYOR promedio:\n  " + mayor);
        System.out.println("Alumno con MENOR promedio:\n  " + menor);
    }

    // 12. Invertir el orden de la cola usando una Pila auxiliar (LIFO)
    public void invertir() {
        if (estaVacia()) {
            throw new IllegalStateException("La cola está vacía.");
        }
        Stack<Alumno> pilaAuxiliar = new Stack<>();
        
        while (!estaVacia()) {
            pilaAuxiliar.push(this.eliminar());
        }
        
        while (!pilaAuxiliar.isEmpty()) {
            this.insertar(pilaAuxiliar.pop());
        }
    }

    // 13. Eliminar alumno por código específico reorganizando el arreglo
    public Alumno eliminarPorCodigo(String codigo) {
        if (estaVacia()) {
            throw new IllegalStateException("La cola está vacía.");
        }
        codigo = codigo.trim();
        int posRelativa = -1;

        for (int i = 0; i < cantidad; i++) {
            int indice = (frente + i) % alumnos.length;
            if (alumnos[indice].getCodigo().equalsIgnoreCase(codigo)) {
                posRelativa = i;
                break;
            }
        }

        if (posRelativa == -1) {
            throw new IllegalArgumentException("No se encontró ningún alumno con el código especificado.");
        }

        Alumno alumnoEliminado = alumnos[(frente + posRelativa) % alumnos.length];

        // Desplazar elementos para rellenar el espacio libre
        for (int i = posRelativa; i < cantidad - 1; i++) {
            int actual = (frente + i) % alumnos.length;
            int siguiente = (frente + i + 1) % alumnos.length;
            alumnos[actual] = alumnos[siguiente];
        }

        int ultimoIndice = (frente + cantidad - 1) % alumnos.length;
        alumnos[ultimoIndice] = null;
        cantidad--;

        if (cantidad == 0) {
            frente = 0;
            finalCola = -1;
        } else {
            finalCola = (finalCola - 1 + alumnos.length) % alumnos.length;
        }

        return alumnoEliminado;
    }
}