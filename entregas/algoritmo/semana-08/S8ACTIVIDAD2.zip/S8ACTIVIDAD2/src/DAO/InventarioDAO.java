package DAO;

import Modelo.Producto;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class InventarioDAO {
    private List<Producto> productos = new ArrayList<>();

    // // Método: registrarProducto (Requerimiento 1)
    public void registrarProducto(String codigo, String descripcion, double precio, int cantidad) {
        if (codigo == null || codigo.isBlank()) {
            throw new IllegalArgumentException("El código del producto no puede estar vacío.");
        }
        if (precio < 0 || cantidad < 0) {
            throw new IllegalArgumentException("El precio y la cantidad no pueden ser negativos.");
        }
        productos.add(new Producto(codigo.trim(), descripcion, precio, cantidad));
        Collections.sort(productos); // Mantiene la lista ordenada para la búsqueda binaria
    }

    // // Método: obtenerProductos (Requerimiento 2)
    public List<Producto> obtenerProductos() {
        return productos;
    }

    // // Método 3: buscarBinarioRecursivo (Requerimiento 3)
    public Producto buscarBinarioRecursivo(String codigoBuscado) {
        if (productos.isEmpty()) {
            return null;
        }
        return busquedaBinariaHelper(codigoBuscado.trim(), 0, productos.size() - 1);
    }

    private Producto busquedaBinariaHelper(String codigo, int inicio, int fin) {
        if (inicio > fin) {
            return null; // Caso base: Elemento no encontrado
        }

        int medio = inicio + (fin - inicio) / 2;
        Producto actual = productos.get(medio);
        int comparacion = actual.getCodigo().compareToIgnoreCase(codigo);

        if (comparacion == 0) {
            return actual; // Caso base: Encontrado
        } else if (comparacion > 0) {
            return busquedaBinariaHelper(codigo, inicio, medio - 1); // Llamada recursiva izquierda
        } else {
            return busquedaBinariaHelper(codigo, medio + 1, fin); // Llamada recursiva derecha
        }
    }

    // // Método 4: calcularValorTotalRecursivo (Requerimiento 4)
    public double calcularValorTotalRecursivo() {
        if (productos.isEmpty()) {
            return 0.0;
        }
        return valorTotalHelper(0);
    }

    private double valorTotalHelper(int indice) {
        if (indice >= productos.size()) {
            return 0.0; // Caso base: fin de la lista
        }
        Producto p = productos.get(indice);
        double valorActual = p.getPrecio() * p.getCantidad();
        return valorActual + valorTotalHelper(indice + 1); // Llamada recursiva
    }

    // // Método 5: calcularTotalUnidades (Requerimiento 5)
    public int calcularTotalUnidades() {
        int totalUnidades = 0;
        for (Producto p : productos) {
            totalUnidades += p.getCantidad();
        }
        return totalUnidades;
    }

    // // Método 7 : obtenerProductosSinExistencias (Requerimiento 6)
    public List<Producto> obtenerProductosSinExistencias() {
        List<Producto> sinExistencias = new ArrayList<>();
        for (Producto p : productos) {
            if (p.getCantidad() == 0) {
                sinExistencias.add(p);
            }
        }
        return sinExistencias;
    }

    // // Método: obtenerBajoInventario (Requerimiento 7)
    public List<Producto> obtenerBajoInventario(int umbral) {
        List<Producto> bajoInventario = new ArrayList<>();
        for (Producto p : productos) {
            if (p.getCantidad() > 0 && p.getCantidad() <= umbral) {
                bajoInventario.add(p);
            }
        }
        return bajoInventario;
    }
}