package Vista;

import DAO.InventarioDAO;
import Modelo.Producto;
import java.util.List;
import java.util.Scanner;

public class Principal {

    // Método 1 para mostrar los productos registrados (de la primera imagen)
    public static void mostrarProductosRegistrados(InventarioDAO DAO) {
        List<Producto> productos = DAO.obtenerProductos();
        if (productos.isEmpty()) {
            System.out.println("⚠️ No hay productos registrados.");
            return;
        }

        System.out.println("\n--- LISTADO DE PRODUCTOS (ORDENADOS) ---");
        for (Producto p : productos) {
            System.out.println("Código: " + p.getCodigo() +
                    " | Desc: " + p.getDescripcion() +
                    " | Precio: $" + p.getPrecio() +
                    " | Stock: " + p.getCantidad());
        }
    }

    // Método 6 recursivo para identificar productos sin existencias (de la última imagen)
    public static void identificarProductosSinExistencias(InventarioDAO DAO, int indice) {
        List<Producto> productos = DAO.obtenerProductos();
        if (indice >= productos.size()) {
            return; 
        }

        Producto p = productos.get(indice);

        if (p.getCantidad() == 0) {
            System.out.println("Código: " + p.getCodigo() +
                    " | Desc: " + p.getDescripcion() +
                    " | Precio: $" + p.getPrecio() +
                    " | (Sin existencias)");
        }

        identificarProductosSinExistencias(DAO, indice + 1); // Llamada recursiva[cite: 2]
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        InventarioDAO DAO = new InventarioDAO();
        int opcion;

        do {
            System.out.println("\n==================================================");
            System.out.println("   SISTEMA DE BÚSQUEDA Y ANÁLISIS DE INVENTARIO");
            System.out.println("==================================================");
            System.out.println("1. Registrar producto");
            System.out.println("2. Mostrar productos registrados");
            System.out.println("3. Buscar producto por código (Búsqueda Binaria Recursiva)");
            System.out.println("4. Calcular valor total del inventario (Recursivo)");
            System.out.println("5. Determinar cantidad total de unidades disponibles");
            System.out.println("6. Identificar productos sin existencias (Stock = 0)");
            System.out.println("7. Generar reporte de productos con bajo inventario");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("⚠️ Ingrese un número válido.");
                opcion = -1;
                continue;
            }

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese código del producto: ");
                    String codigo = scanner.nextLine();
                    System.out.print("Ingrese descripción: ");
                    String descripcion = scanner.nextLine();
                    System.out.print("Ingrese precio unitario: ");
                    double precio = Double.parseDouble(scanner.nextLine());
                    System.out.print("Ingrese cantidad disponible: ");
                    int cantidad = Integer.parseInt(scanner.nextLine());

                    try {
                        DAO.registrarProducto(codigo, descripcion, precio, cantidad);
                        System.out.println("✅ Producto registrado exitosamente.");
                    } catch (Exception e) {
                        System.out.println("❌ Error: " + e.getMessage());
                    }
                    break;

                case 2:
                    mostrarProductosRegistrados(DAO);
                    break;

                case 3:
                    System.out.print("Ingrese el código del producto a buscar: ");
                    String buscado = scanner.nextLine();
                    Producto encontrado = DAO.buscarBinarioRecursivo(buscado);
                    if (encontrado != null) {
                        System.out.println("✅ ¡Producto encontrado!");
                        System.out.println("   -> Descripción: " + encontrado.getDescripcion());
                        System.out.println("   -> Precio: $" + encontrado.getPrecio());
                        System.out.println("   -> Stock: " + encontrado.getCantidad());
                    } else {
                        System.out.println("❌ Producto no encontrado en el inventario.");
                    }
                    break;

                case 4:
                    double valorTotal = DAO.calcularValorTotalRecursivo();
                    System.out.println("\n💰 Valor total del inventario (Cálculo recursivo): $" + String.format("%.2f", valorTotal));
                    break;

                case 5:
                    int totalUnidades = DAO.calcularTotalUnidades();
                    System.out.println("\n📦 Cantidad total de unidades en stock: " + totalUnidades);
                    break;

                case 6:
                    System.out.println("\n⚠️ PRODUCTOS SIN STOCK (0 unidades):");
                    identificarProductosSinExistencias(DAO, 0);
                    break;

                case 7:
                    System.out.print("Ingrese el umbral de stock bajo (ej. 5): ");
                    int umbral = Integer.parseInt(scanner.nextLine());
                    List<Producto> bajoStock = DAO.obtenerBajoInventario(umbral);
                    if (bajoStock.isEmpty()) {
                        System.out.println("👍 No hay productos bajo el umbral especificado.");
                    } else {
                        System.out.println("\n📉 REPORTE DE BAJO INVENTARIO (Stock <= " + umbral + "):");
                        for (Producto p : bajoStock) {
                            System.out.println(" - " + p.getCodigo() + " | " + p.getDescripcion() + " | Stock actual: " + p.getCantidad());
                        }
                    }
                    break;

                case 0:
                    System.out.println("👋 Saliendo del sistema de inventario...");
                    break;

                default:
                    System.out.println("⚠️ Opción no válida.");
            }
        } while (opcion != 0);

        scanner.close();
    }
}