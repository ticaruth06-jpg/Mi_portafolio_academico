package Modelo;

public class Producto implements Comparable<Producto> {
    private String codigo;
    private String descripcion;
    private double precio;
    private int cantidad;

    // // Método: Constructor de Producto
    public Producto(String codigo, String descripcion, double precio, int cantidad) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    // // Métodos Getter
    public String getCodigo() { return codigo; }
    public String getDescripcion() { return descripcion; }
    public double getPrecio() { return precio; }
    public int getCantidad() { return cantidad; }

    @Override
    public int compareTo(Producto otro) {
        return this.codigo.compareToIgnoreCase(otro.codigo);
    }
}