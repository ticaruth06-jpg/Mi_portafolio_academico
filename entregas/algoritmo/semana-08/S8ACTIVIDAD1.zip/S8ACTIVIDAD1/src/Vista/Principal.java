package Vista;

import DAO.GestorArchivos_1;
import Modelo.ArchivoInfo;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Capa de Vista que implementa la interfaz de interacción por consola para el usuario.
 */
public class Principal {

    // // Método: main (Punto de entrada de la aplicación)
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GestorArchivos_1  DAO = new GestorArchivos_1();
        List<ArchivoInfo> listaArchivos = new ArrayList<>();
        boolean cargado = false;

        int opcion;
        do {
            System.out.println("\n==================================================");
            System.out.println("   SISTEMA DE GESTIÓN Y ANÁLISIS DE ARCHIVOS");
            System.out.println("==================================================");
            System.out.println("1. Seleccionar directorio raíz y analizar");
            System.out.println("2. Listar archivos y carpetas");
            System.out.println("3. Contabilizar total de archivos encontrados");
            System.out.println("4. Calcular tamaño total de archivos accesibles");
            System.out.println("5. Buscar archivos por nombre o extensión");
            System.out.println("6. Generar reporte por tipo/extensión");
            System.out.println("7. Mostrar estructura jerárquica completa");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            
            try {
                opcion = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("⚠️ Por favor, ingrese un número válido.");
                opcion = -1;
                continue;
            }

            switch (opcion) {
                case 1:
                    // // Método: seleccionarDirectorioYAnalizar
                    System.out.print("Ingrese la ruta absoluta del directorio a analizar: ");
                    String rutaStr = scanner.nextLine();
                    File directorioRaiz = new File(rutaStr);
                    
                    listaArchivos.clear();
                    try {
                        DAO.explorarDirectorioRecursivo(directorioRaiz, listaArchivos);
                        cargado = true;
                        System.out.println("✅ Directorio analizado con éxito. Elementos detectados.");
                    } catch (Exception e) {
                        System.out.println("❌ Error: " + e.getMessage());
                    }
                    break;

                case 2:
                    // // Método2: listarArchivosEnConsola
                    if (!cargado) {
                        System.out.println("⚠️ Primero debe analizar un directorio en la opción 1.");
                        break;
                    }
                    System.out.println("\n--- LISTADO DE ARCHIVOS Y CARPETAS ---");
                    for (ArchivoInfo arch : listaArchivos) {
                        System.out.println("- " + arch.getNombre() + " (" + arch.getTipo() + ")");
                    }
                    break;

                case 3:
                    // // Método3: contabilizarArchivos
                    if (!cargado) {
                        System.out.println("⚠️ Primero debe analizar un directorio en la opción 1.");
                        break;
                    }
                    long totalCarpetas = listaArchivos.stream().filter(a -> a.getTipo().equals("Carpeta")).count();
                    long totalArchivos = listaArchivos.size() - totalCarpetas;
                    System.out.println("\n📊 Total de carpetas: " + totalCarpetas);
                    System.out.println("📊 Total de archivos: " + totalArchivos);
                    System.out.println("📊 Elementos totales en la lista: " + listaArchivos.size());
                    break;

                case 4:
                    // // Método: calcularTamanoTotalConsola
                    if (!cargado) {
                        System.out.println("⚠️ Primero debe analizar un directorio en la opción 1.");
                        break;
                    }
                    long bytesTotales = DAO.calcularTamanoTotal(listaArchivos);
                    double mbTotales = (double) bytesTotales / (1024 * 1024);
                    System.out.println("\n💾 Tamaño total de archivos accesibles: " + bytesTotales + " bytes (" + String.format("%.2f", mbTotales) + " MB)");
                    break;

                case 5:
                    // // Método: buscarArchivosConsola
                    if (!cargado) {
                        System.out.println("⚠️ Primero debe analizar un directorio en la opción 1.");
                        break;
                    }
                    System.out.print("Ingrese el nombre o extensión a buscar (ej. pdf, factura): ");
                    String criterio = scanner.nextLine();
                    List<ArchivoInfo> resultados = DAO.buscarPorNombreOExtension(listaArchivos, criterio);
                    System.out.println("\n🔍 Resultados encontrados (" + resultados.size() + "):");
                    for (ArchivoInfo res : resultados) {
                        System.out.println(" -> " + res.getRuta());
                    }
                    break;

                case 6:
                    // // Método: generarReporteTiposConsola
                    if (!cargado) {
                        System.out.println("⚠️ Primero debe analizar un directorio en la opción 1.");
                        break;
                    }
                    Map<String, Integer> reporte = DAO.generarReportePorTipo(listaArchivos);
                    System.out.println("\n📋 REPORTE DE CANTIDAD DE ARCHIVOS POR TIPO:");
                    for (Map.Entry<String, Integer> entry : reporte.entrySet()) {
                        System.out.println(" • " + entry.getKey().toUpperCase() + ": " + entry.getValue() + " archivo(s)");
                    }
                    break;

                case 7:
                    // // Método: mostrarJerarquiaConsola
                    if (!cargado) {
                        System.out.println("⚠️ Primero debe analizar un directorio en la opción 1.");
                        break;
                    }
                    System.out.println("\n📂 ESTRUCTURA JERÁRQUICA DE DIRECTORIOS:");
                   DAO.mostrarEstructuraJerarquica(listaArchivos);
                    break;

                case 0:
                    System.out.println("👋 Saliendo del sistema...");
                    break;

                default:
                    System.out.println("⚠️ Opción inválida.");
            }
        } while (opcion != 0);

        scanner.close();
    }
}