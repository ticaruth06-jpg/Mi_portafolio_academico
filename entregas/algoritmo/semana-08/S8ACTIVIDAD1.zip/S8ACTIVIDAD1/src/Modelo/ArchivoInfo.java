package Modelo;

/**
 * Clase Modelo que representa la información individual de un archivo o carpeta.
 */
public class ArchivoInfo {

    public static String extraerExtension(String name) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private String nombre;
    private String ruta;
    private long tamanoBytes;
    private String tipo; // Extensión del archivo o "Carpeta"

    // // Método: Constructor de la clase ArchivoInfo
    public ArchivoInfo(String nombre, String ruta, long tamanoBytes, String tipo) {
        this.nombre = nombre;
        this.ruta = ruta;
        this.tamanoBytes = tamanoBytes;
        this.tipo = tipo;
    }

    // // Método: getNombre
    public String getNombre() {
        return nombre;
    }

    // // Método: getRuta
    public String getRuta() {
        return ruta;
    }

    // // Método: getTamanoBytes
    public long getTamanoBytes() {
        return tamanoBytes;
    }

    // // Método: getTipo
    public String getTipo() {
        return tipo;
    }

    // // Método: getTamanoMegabytes
    public double getTamanoMegabytes() {
        return (double) tamanoBytes / (1024 * 1024);
    }
}