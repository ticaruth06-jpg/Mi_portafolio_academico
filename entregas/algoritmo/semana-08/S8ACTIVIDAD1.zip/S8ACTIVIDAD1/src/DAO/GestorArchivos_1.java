package DAO;

import Modelo.ArchivoInfo;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Capa DAO (Data Access Object) que encapsula la lógica de negocio, 
 * el recorrido recursivo y las operaciones sobre los archivos.
 */
public class GestorArchivos_1 {

    // // Método1: explorarDirectorioRecursivo (Requerimientos 1, 2 y 3)
    public void explorarDirectorioRecursivo(File directorio, List<ArchivoInfo> listaAcumulada) {
        if (directorio == null || !directorio.exists()) {
            throw new IllegalArgumentException("El directorio especificado no existe o es inválido.");
        }
        
        File[] archivos = directorio.listFiles();
        if (archivos != null) {
            for (File archivo : archivos) {
                if (archivo.isDirectory()) {
                    listaAcumulada.add(new ArchivoInfo(archivo.getName(), archivo.getAbsolutePath(), 0, "Carpeta"));
                    explorarDirectorioRecursivo(archivo, listaAcumulada); // Llamada recursiva
                } else {
                    String extension = obtenerExtension(archivo.getName());
                    listaAcumulada.add(new ArchivoInfo(archivo.getName(), archivo.getAbsolutePath(), archivo.length(), extension));
                }
            }
        }
    }

    // // Método4: calcularTamanoTotal (Requerimiento 4)
    public long calcularTamanoTotal(List<ArchivoInfo> archivos) {
        long totalBytes = 0;
        for (ArchivoInfo arch : archivos) {
            if (!arch.getTipo().equals("Carpeta")) {
                totalBytes += arch.getTamanoBytes();
            }
        }
        return totalBytes;
    }

    // // Método: buscarPorNombreOExtension (Requerimiento 5)
    public List<ArchivoInfo> buscarPorNombreOExtension(List<ArchivoInfo> archivos, String criterio) {
        List<ArchivoInfo> resultados = new ArrayList<>();
        String criterioLower = criterio.toLowerCase();
        for (ArchivoInfo arch : archivos) {
            if (arch.getNombre().toLowerCase().contains(criterioLower) || arch.getTipo().toLowerCase().contains(criterioLower)) {
                resultados.add(arch);
            }
        }
        return resultados;
    }

    // // Método6: generarReportePorTipo (Requerimiento 6)
    public Map<String, Integer> generarReportePorTipo(List<ArchivoInfo> archivos) {
        Map<String, Integer> reporte = new HashMap<>();
        for (ArchivoInfo arch : archivos) {
            String tipo = arch.getTipo();
            reporte.put(tipo, reporte.getOrDefault(tipo, 0) + 1);
        }
        return reporte;
    }

    // // Método7: mostrarEstructuraJerarquica (Requerimiento 7)
    public void mostrarEstructuraJerarquica(List<ArchivoInfo> archivos) {
        for (ArchivoInfo arch : archivos) {
            String sangria = arch.getTipo().equals("Carpeta") ? "📁 [CARPETA] " : " 📄 [ARCHIVO] ";
            System.out.println(sangria + arch.getRuta() + " (" + String.format("%.2f", arch.getTamanoMegabytes()) + " MB)");
        }
    }

    // // Método auxiliar: obtenerExtension
    private String obtenerExtension(String nombreArchivo) {
        int ultimoPunto = nombreArchivo.lastIndexOf('.');
        if (ultimoPunto > 0 && ultimoPunto < nombreArchivo.length() - 1) {
            return nombreArchivo.substring(ultimoPunto + 1).toLowerCase();
        }
        return "desconocido";
    }
}