package DAO;

import modelo.Expediente;
import modelo.NodoArbol;
import java.util.ArrayList;
import java.util.List;

public class ExpedienteDAO {
    private NodoArbol raiz;

    // 1 Método registrar  
    public void registrar(String codigo, String nombreEstudiante, String estado) {
        if (codigo == null || codigo.isBlank()) {
            throw new IllegalArgumentException("El código del expediente no puede estar vacío.");
        }
        Expediente nuevoExpediente = new Expediente(codigo.trim(), nombreEstudiante, estado);
        raiz = insertarRecursivo(raiz, nuevoExpediente);
    }
    //2. Método insertar 
    private NodoArbol insertarRecursivo(NodoArbol actual, Expediente expediente) {
        if (actual == null) {
            return new NodoArbol(expediente); // Caso base
        }

        int comparacion = expediente.getCodigo().compareToIgnoreCase(actual.getExpediente().getCodigo());
        if (comparacion < 0) {
            actual.setIzquierdo(insertarRecursivo(actual.getIzquierdo(), expediente));
        } else if (comparacion > 0) {
            actual.setDerecho(insertarRecursivo(actual.getDerecho(), expediente));
        } else {
            throw new IllegalArgumentException("El código de expediente ya existe en el árbol.");
        }
        return actual;
    }

    // 3. Buscar expediente por código
    public Expediente buscar(String codigo) {
        if (codigo == null || codigo.isBlank()) return null;
        return buscarRecursivo(raiz, codigo.trim());
    }

    private Expediente buscarRecursivo(NodoArbol actual, String codigo) {
        if (actual == null) {
            return null; // Caso base: no encontrado
        }
        int comparacion = codigo.compareToIgnoreCase(actual.getExpediente().getCodigo());
        if (comparacion == 0) {
            return actual.getExpediente(); // Encontrado
        }
        return comparacion < 0 ? buscarRecursivo(actual.getIzquierdo(), codigo) 
                               : buscarRecursivo(actual.getDerecho(), codigo);
    }

    // 4. Mostrar expedientes en orden ascendente (Recorrido Inorden)
    public List<Expediente> obtenerEnOrdenAscendente() {
        List<Expediente> lista = new ArrayList<>();
        inordenRecursivo(raiz, lista);
        return lista;
    }

    private void inordenRecursivo(NodoArbol actual, List<Expediente> lista) {
        if (actual != null) {
            inordenRecursivo(actual.getIzquierdo(), lista);
            lista.add(actual.getExpediente());
            inordenRecursivo(actual.getDerecho(), lista);
        }
    }

    // 5. Calcular la cantidad total de expedientes
    public int contarTotal() {
        return contarRecursivo(raiz);
    }

    private int contarRecursivo(NodoArbol actual) {
        if (actual == null) return 0;
        return 1 + contarRecursivo(actual.getIzquierdo()) + contarRecursivo(actual.getDerecho());
    }

    // 6. Determinar la altura del árbol binario
    public int calcularAltura() {
        return alturaRecursiva(raiz);
    }

    private int alturaRecursiva(NodoArbol actual) {
        if (actual == null) return -1; // Árbol vacío tiene altura -1
        int alturaIzq = alturaRecursiva(actual.getIzquierdo());
        int alturaDer = alturaRecursiva(actual.getDerecho());
        return Math.max(alturaIzq, alturaDer) + 1;
    }

    // 7. Identificar expedientes por criterio de búsqueda
    public List<Expediente> buscarPorCriterio(String criterio) {
        List<Expediente> resultados = new ArrayList<>();
        if (criterio == null || criterio.isBlank()) return resultados;
        buscarCriterioRecursivo(raiz, criterio.trim().toLowerCase(), resultados);
        return resultados;
    }

    private void buscarCriterioRecursivo(NodoArbol actual, String criterio, List<Expediente> resultados) {
        if (actual != null) {
            buscarCriterioRecursivo(actual.getIzquierdo(), criterio, resultados);
            Expediente exp = actual.getExpediente();
            if (exp.getEstado().toLowerCase().contains(criterio) || 
                exp.getNombreEstudiante().toLowerCase().contains(criterio) ||
                exp.getCodigo().toLowerCase().contains(criterio)) {
                resultados.add(exp);
            }
            buscarCriterioRecursivo(actual.getDerecho(), criterio, resultados);
        }
    }
}