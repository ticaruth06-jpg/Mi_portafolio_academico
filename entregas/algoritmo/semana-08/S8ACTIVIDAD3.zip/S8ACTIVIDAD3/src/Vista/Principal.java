package vista;

import DAO.ExpedienteDAO;
import modelo.Expediente;
import java.util.List;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ExpedienteDAO dao = new ExpedienteDAO();
        int opcion;

        do {
            System.out.println("\n==================================================");
            System.out.println("   SISTEMA DE GESTIÓN DE EXPEDIENTES ACADÉMICOS");
            System.out.println("==================================================");
            System.out.println("1. Registrar expediente en el Árbol Binario");
            System.out.println("2. Mostrar expedientes en orden ascendente (Inorden)");
            System.out.println("3. Buscar expediente por código");
            System.out.println("4. Calcular cantidad total de expedientes");
            System.out.println("5. Determinar la altura del árbol binario");
            System.out.println("6. Identificar expedientes que cumplen criterio de búsqueda");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("⚠️ Ingrese un número válido.");
                opcion = -1;
                continue;
            }

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese código del expediente: ");
                    String codigo = scanner.nextLine();
                    System.out.print("Ingrese nombre del estudiante: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Ingrese estado (ej. Matriculado, Aprobado): ");
                    String estado = scanner.nextLine();

                    try {
                        dao.registrar(codigo, nombre, estado);
                        System.out.println("✅ Expediente registrado e insertado en el Árbol con éxito.");
                    } catch (Exception e) {
                        System.out.println("❌ Error: " + e.getMessage());
                    }
                    break;

                case 2:
                    List<Expediente> ascendente = dao.obtenerEnOrdenAscendente();
                    if (ascendente.isEmpty()) {
                        System.out.println("⚠️ No hay expedientes registrados.");
                    } else {
                        System.out.println("\n--- LISTADO DE EXPEDIENTES (ORDEN ASCENDENTE) ---");
                        for (Expediente e : ascendente) {
                            System.out.println(e);
                        }
                    }
                    break;

                case 3:
                    System.out.print("Ingrese el código del expediente a buscar: ");
                    String buscado = scanner.nextLine();
                    Expediente encontrado = dao.buscar(buscado);
                    if (encontrado != null) {
                        System.out.println("✅ ¡Expediente encontrado!");
                        System.out.println("   -> " + encontrado);
                    } else {
                        System.out.println("❌ Expediente no encontrado.");
                    }
                    break;

                case 4:
                    System.out.println("\n📊 Cantidad total de expedientes en el árbol: " + dao.contarTotal());
                    break;

                case 5:
                    System.out.println("\n🌲 Altura actual del Árbol Binario de Búsqueda: " + dao.calcularAltura());
                    break;

                case 6:
                    System.out.print("Ingrese criterio de búsqueda (estado, nombre o código parcial): ");
                    String criterio = scanner.nextLine();
                    List<Expediente> filtrados = dao.buscarPorCriterio(criterio);
                    if (filtrados.isEmpty()) {
                        System.out.println("⚠️ No se encontraron coincidencias.");
                    } else {
                        System.out.println("\n🔍 RESULTADOS ENCONTRADOS (" + filtrados.size() + "):");
                        for (Expediente e : filtrados) {
                            System.out.println("   -> " + e);
                        }
                    }
                    break;

                case 0:
                    System.out.println("👋 Saliendo del sistema de gestión académica...");
                    break;

                default:
                    System.out.println("⚠️ Opción inválida.");
            }
        } while (opcion != 0);

        scanner.close();
    }
}