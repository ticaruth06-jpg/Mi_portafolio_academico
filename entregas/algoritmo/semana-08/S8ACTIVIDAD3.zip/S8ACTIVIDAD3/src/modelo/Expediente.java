package modelo;

public class Expediente {
    private String codigo;
    private String nombreEstudiante;
    private String estado; // Ej: "Matriculado", "Pendiente", "Aprobado"

    public Expediente(String codigo, String nombreEstudiante, String estado) {
        this.codigo = codigo;
        this.nombreEstudiante = nombreEstudiante;
        this.estado = estado;
    }

    public String getCodigo() { return codigo; }
    public String getNombreEstudiante() { return nombreEstudiante; }
    public String getEstado() { return estado; }
}