package DAO;

import Modelo.ComponenteModelo;
import Modelo.ProductoModelo;
import java.util.ArrayList;

public class CostosProductosDAO {
    private ArrayList<ProductoModelo> listaProductos;

    public CostosProductosDAO() {
        this.listaProductos = new ArrayList<>();
    }

    // Método de búsqueda basado netamente en recorrer el ArrayList
    public ProductoModelo buscarProductoPorCodigo(String codigo) {
        for (ProductoModelo p : listaProductos) {
            if (p.getCodigo().equalsIgnoreCase(codigo)) {
                return p;
            }
        }
        return null;
    }

    // ==========================================
    // RF01: Registrar productos con códigos únicos
    // ==========================================
    public boolean registrarProductoUnico(String codigo) {
        return buscarProductoPorCodigo(codigo) == null;
    }

    // ==========================================
    // RF02: Registrar el costo unitario de cada componente
    // ==========================================
    public void registrarCostoUnitario(ProductoModelo producto, double costo) {
        producto.setCostoUnitario(costo);
        System.out.println("✔ Costo unitario actualizado correctamente (RF02).");
    }

    // Registro completo (RF01, RF02, RF09)
    public boolean ejecutarRegistroCompleto(String codigo, String nombre, double costoUnitario) {
        if (!validarValorNoNegativo(costoUnitario)) {
            System.out.println("❌ Error: El costo unitario no puede ser negativo (RF09).");
            return false;
        }

        if (!registrarProductoUnico(codigo)) {
            System.out.println("❌ Error: El código '" + codigo + "' ya está registrado (RF01).");
            return false;
        }

        ProductoModelo nuevo = new ProductoModelo(codigo, nombre, costoUnitario);
        listaProductos.add(nuevo);
        System.out.println("✔ Producto registrado exitosamente.");
        return true;
    }

    // ==========================================
    // RF03: Definir productos compuestos
    // ==========================================
    public boolean definirProductoCompuesto(ProductoModelo padre, ProductoModelo hijo) {
        return padre != null && hijo != null;
    }

    // ==========================================
    // RF04, RF08, RF09: Registrar cantidad, validar ciclos y no negativos
    // ==========================================
    public boolean registrarCantidadRequerida(String codigoPadre, String codigoHijo, int cantidad) {
        if (!validarValorNoNegativo(cantidad) || cantidad <= 0) {
            System.out.println("❌ Error: La cantidad requerida debe ser mayor a 0 (RF09).");
            return false;
        }

        ProductoModelo padre = buscarProductoPorCodigo(codigoPadre);
        ProductoModelo hijo = buscarProductoPorCodigo(codigoHijo);

        if (padre == null || hijo == null) {
            System.out.println("❌ Error: No se encontró el producto padre o el componente hijo.");
            return false;
        }

        // RF08: Detección de ciclos mediante ArrayList de visitados
        if (detectarCiclosEstructura(hijo, padre, new ArrayList<>())) {
            System.out.println("❌ Error: Se detectó un ciclo en la estructura. Operación cancelada (RF08).");
            return false;
        }

        padre.agregarSubComponente(hijo, cantidad);
        System.out.println("✔ Cantidad y subcomponente registrados exitosamente (RF03, RF04).");
        return true;
    }

    // ==========================================
    // RF05: Calcular recursivamente el costo total
    // ==========================================
    public double calcularCostoTotalRecursivo(ProductoModelo producto) {
        if (producto.getSubComponentes().isEmpty()) {
            return producto.getCostoUnitario();
        }
        double costoTotalAcumulado = 0;
        for (ComponenteModelo comp : producto.getSubComponentes()) {
            costoTotalAcumulado += calcularCostoTotalRecursivo(comp.getProducto()) * comp.getCantidad();
        }
        return costoTotalAcumulado;
    }

    // ==========================================
    // RF06: Mostrar desglose de costos por nivel
    // ==========================================
    public void mostrarDesglosePorNiveles(ProductoModelo producto, String identacion) {
        System.out.println(identacion + "📦 [" + producto.getCodigo() + "] " + producto.getNombre() + " - Base: $" + producto.getCostoUnitario());
        for (ComponenteModelo comp : producto.getSubComponentes()) {
            System.out.println(identacion + "   ↳ Cantidad requerida: " + comp.getCantidad());
            mostrarDesglosePorNiveles(comp.getProducto(), identacion + "      ");
        }
    }

    // ==========================================
    // RF07: Identificar componentes compartidos (Usando solo ArrayLists)
    // ==========================================
    public void identificarComponentesCompartidos() {
        System.out.println("\n--- REPORTE DE COMPONENTES COMPARTIDOS (RF07) ---");
        boolean hayCompartidos = false;

        // Lista para llevar el registro de códigos ya evaluados y evitar duplicar reportes
        ArrayList<String> codigosEvaluados = new ArrayList<>();

        for (ProductoModelo candidato : listaProductos) {
            String codCandidato = candidato.getCodigo();
            
            if (codigosEvaluados.contains(codCandidato.toLowerCase())) {
                continue;
            }
            codigosEvaluados.add(codCandidato.toLowerCase());

            int contadorUso = 0;
            ArrayList<String> contenedores = new ArrayList<>();

            for (ProductoModelo p : listaProductos) {
                for (ComponenteModelo comp : p.getSubComponentes()) {
                    if (comp.getProducto().getCodigo().equalsIgnoreCase(codCandidato)) {
                        contadorUso++;
                        if (!contenedores.contains(p.getNombre())) {
                            contenedores.add(p.getNombre());
                        }
                    }
                }
            }

            if (contadorUso > 1) {
                hayCompartidos = true;
                System.out.println("• El componente [" + candidato.getNombre() + "] es compartido en: " + contenedores);
            }
        }

        if (!hayCompartidos) {
            System.out.println("No existen componentes compartidos actualmente.");
        }
    }

    // ==========================================
    // RF08: Detectar ciclos (Algoritmo recursivo con ArrayList de visitados)
    // ==========================================
    public boolean detectarCiclosEstructura(ProductoModelo actual, ProductoModelo objetivo, ArrayList<String> visitados) {
        if (actual.getCodigo().equalsIgnoreCase(objetivo.getCodigo())) {
            return true;
        }
        visitados.add(actual.getCodigo());
        for (ComponenteModelo comp : actual.getSubComponentes()) {
            ProductoModelo hijo = comp.getProducto();
            if (!visitados.contains(hijo.getCodigo().toLowerCase())) {
                if (detectarCiclosEstructura(hijo, objetivo, visitados)) {
                    return true;
                }
            }
        }
        visitados.remove(actual.getCodigo().toLowerCase());
        return false;
    }

    // ==========================================
    // RF09: Validar costos y cantidades no negativos
    // ==========================================
    public boolean validarValorNoNegativo(double valor) {
        return valor >= 0;
    }

    // ==========================================
    // RF10: Generar reporte de costo estimado
    // ==========================================
    public void generarReporteCostoEstimado() {
        System.out.println("\n==============================================");
        System.out.println("     REPORTE ESTIMADO DE FABRICACIÓN (RF10)   ");
        System.out.println("==============================================");
        if(listaProductos.isEmpty()) {
            System.out.println("No hay productos registrados en el sistema.");
            return;
        }
        for (ProductoModelo p : listaProductos) {
            double costoFinal = calcularCostoTotalRecursivo(p);
            System.out.println("• Producto: " + p.getNombre() + " (" + p.getCodigo() + ") -> Costo Total: $" + costoFinal);
        }
    }

    public ArrayList<ProductoModelo> getListaProductos() {
        return listaProductos;
    }
}