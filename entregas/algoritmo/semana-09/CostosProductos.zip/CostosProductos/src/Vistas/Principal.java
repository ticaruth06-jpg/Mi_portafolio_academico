package Vistas;

public class Principal {
    public static void main(String[] args) {
        CostosProductosVista vista = new CostosProductosVista();
        vista.iniciarMenu();
    }
}