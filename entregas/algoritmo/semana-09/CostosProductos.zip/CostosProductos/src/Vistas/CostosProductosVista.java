package Vistas;

import DAO.CostosProductosDAO;
import Modelo.ProductoModelo;
import java.util.Scanner;

public class CostosProductosVista {
    private CostosProductosDAO dao;
    private Scanner scanner;

    public CostosProductosVista() {
        this.dao = new CostosProductosDAO();
        this.scanner = new Scanner(System.in);
    }

    public void iniciarMenu() {
        int opcion;
        do {
            System.out.println("\n==================================================================");
            System.out.println("          SISTEMA DE COSTOS - MENÚ DE REQUERIMIENTOS              ");
            System.out.println("==================================================================");
            System.out.println("1.  [RF01] Registrar productos y componentes mediante códigos únicos.");
            System.out.println("2.  [RF02] Registrar el costo unitario de cada componente.");
            System.out.println("3.  [RF03] Definir productos compuestos por otros productos o componentes.");
            System.out.println("4.  [RF04] Registrar la cantidad requerida de cada componente.");
            System.out.println("5.  [RF05] Calcular recursivamente el costo total de un producto compuesto.");
            System.out.println("6.  [RF06] Mostrar el desglose de costos por nivel de componentes.");
            System.out.println("7.  [RF07] Identificar componentes compartidos entre distintos productos.");
            System.out.println("8.  [RF08] Detectar ciclos en la estructura de composición.");
            System.out.println("9.  [RF09] Validar que los costos y las cantidades sean valores no negativos.");
            System.out.println("10. [RF10] Generar un reporte del costo estimado de fabricación.");
            System.out.println("11. Salir del sistema.");
            System.out.print("Elija una opción (1-11): ");
            
            while (!scanner.hasNextInt()) {
                System.out.println("❌ Por favor ingrese un número válido.");
                scanner.next();
                System.out.print("Elija una opción (1-11): ");
            }
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    System.out.println("\n--- [RF01] REGISTRAR PRODUCTO/COMPONENTE ---");
                    System.out.print("Ingrese Código único: ");
                    String cod1 = scanner.nextLine();
                    System.out.print("Ingrese Nombre: ");
                    String nom1 = scanner.nextLine();
                    System.out.print("Ingrese Costo Unitario Base ($): ");
                    double costo1 = scanner.nextDouble();
                    dao.ejecutarRegistroCompleto(cod1, nom1, costo1);
                    break;
                    
                case 2:
                    System.out.println("\n--- [RF02] REGISTRAR / MODIFICAR COSTO UNITARIO ---");
                    System.out.print("Ingrese el código del componente: ");
                    String codC = scanner.nextLine();
                    ProductoModelo pC = dao.buscarProductoPorCodigo(codC);
                    if(pC != null) {
                        System.out.print("Ingrese el nuevo costo unitario: ");
                        double nuevoCosto = scanner.nextDouble();
                        dao.registrarCostoUnitario(pC, nuevoCosto);
                    } else {
                        System.out.println("❌ Componente no encontrado.");
                    }
                    break;
                    
                case 3:
                    System.out.println("\n--- [RF03] DEFINIR PRODUCTO COMPUESTO ---");
                    System.out.print("Ingrese Código del Producto Padre: ");
                    String padreRF3 = scanner.nextLine();
                    System.out.print("Ingrese Código del Componente Hijo: ");
                    String hijoRF3 = scanner.nextLine();
                    ProductoModelo pPadre = dao.buscarProductoPorCodigo(padreRF3);
                    ProductoModelo pHijo = dao.buscarProductoPorCodigo(hijoRF3);
                    if(dao.definirProductoCompuesto(pPadre, pHijo)) {
                        System.out.println("✔ Relación de producto compuesto definida correctamente (RF03).");
                    } else {
                        System.out.println("❌ Error: No se pudo definir la relación (Verifique que ambos existan).");
                    }
                    break;
                    
                case 4:
                    System.out.println("\n--- [RF04] REGISTRAR CANTIDAD REQUERIDA ---");
                    System.out.print("Ingrese Código del Producto Padre: ");
                    String pPadre4 = scanner.nextLine();
                    System.out.print("Ingrese Código del Subcomponente Hijo: ");
                    String pHijo4 = scanner.nextLine();
                    System.out.print("Ingrese la Cantidad requerida: ");
                    int cant4 = scanner.nextInt();
                    dao.registrarCantidadRequerida(pPadre4, pHijo4, cant4);
                    break;
                    
                case 5:
                    System.out.println("\n--- [RF05] CÁLCULO RECURSIVO DEL COSTO TOTAL ---");
                    System.out.print("Ingrese el código del producto compuesto a calcular: ");
                    String codRF5 = scanner.nextLine();
                    ProductoModelo prodRF5 = dao.buscarProductoPorCodigo(codRF5);
                    if (prodRF5 != null) {
                        double total = dao.calcularCostoTotalRecursivo(prodRF5);
                        System.out.println("💰 Costo Total de Fabricación (RF05): $" + total);
                    } else {
                        System.out.println("❌ Producto no encontrado.");
                    }
                    break;
                    
                case 6:
                    System.out.println("\n--- [RF06] DESGLOSE DE COSTOS POR NIVEL ---");
                    System.out.print("Ingrese el código del producto a desglosar: ");
                    String codRF6 = scanner.nextLine();
                    ProductoModelo prodRF6 = dao.buscarProductoPorCodigo(codRF6);
                    if (prodRF6 != null) {
                        dao.mostrarDesglosePorNiveles(prodRF6, "");
                    } else {
                        System.out.println("❌ Producto no encontrado.");
                    }
                    break;
                    
                case 7:
                    dao.identificarComponentesCompartidos(); // [RF07]
                    break;
                    
                case 8:
                    System.out.println("\n--- [RF08] DETECCIÓN DE CICLOS EN LA ESTRUCTURA ---");
                    System.out.println("ℹ Nota: El sistema valida automáticamente y previene ciclos mediante recursividad cada vez que asocias un componente (Opción 4).");
                    break;
                    
                case 9:
                    System.out.println("\n--- [RF09] VALIDACIÓN DE VALORES NO NEGATIVOS ---");
                    System.out.println("ℹ Nota: El sistema valida automáticamente que los costos y cantidades sean >= 0 mediante excepciones y filtros (Opciones 1 y 4).");
                    break;
                    
                case 10:
                    dao.generarReporteCostoEstimado(); // [RF10]
                    break;
                    
                case 11:
                    System.out.println("Saliendo del sistema...");
                    break;
                    
                default:
                    System.out.println("❌ Opción inválida, elija un número entre 1 y 11.");
            }
        } while (opcion != 11);
    }
}