package Modelo;

import java.util.ArrayList;

public class ProductoModelo {
    private String codigo;
    private String nombre;
    private double costoUnitario; 
    private ArrayList<ComponenteModelo> subComponentes; 

    public ProductoModelo(String codigo, String nombre, double costoUnitario) {
        this.codigo = codigo;
        this.nombre = nombre;
        setCostoUnitario(costoUnitario);
        this.subComponentes = new ArrayList<>();
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public double getCostoUnitario() { return costoUnitario; }
    
    // RF09: Validar que el costo no sea negativo
    public void setCostoUnitario(double costoUnitario) { 
        if(costoUnitario < 0) {
            throw new IllegalArgumentException("El costo no puede ser negativo (RF09)");
        }
        this.costoUnitario = costoUnitario; 
    }

    public ArrayList<ComponenteModelo> getSubComponentes() { return subComponentes; }

    public void agregarSubComponente(ProductoModelo productoHijo, int cantidad) {
        subComponentes.add(new ComponenteModelo(productoHijo, cantidad));
    }
}