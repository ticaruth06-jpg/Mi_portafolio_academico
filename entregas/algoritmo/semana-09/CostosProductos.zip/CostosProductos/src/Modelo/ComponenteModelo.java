package Modelo;

public class ComponenteModelo {
    private ProductoModelo producto;
    private int cantidad;

    public ComponenteModelo(ProductoModelo producto, int cantidad) {
        this.producto = producto;
        setCantidad(cantidad);
    }

    public ProductoModelo getProducto() { return producto; }
    public void setProducto(ProductoModelo producto) { this.producto = producto; }

    public int getCantidad() { return cantidad; }
    
    // RF09: Validar que la cantidad requerida sea positiva (> 0)
    public void setCantidad(int cantidad) { 
        if(cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor a 0 (RF09)");
        }
        this.cantidad = cantidad; 
    }
}