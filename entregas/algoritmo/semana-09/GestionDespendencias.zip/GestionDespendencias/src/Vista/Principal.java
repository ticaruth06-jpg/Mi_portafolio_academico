package Vista;

public class Principal {
    public static void main(String[] args) {
        DependenciasVista vista = new DependenciasVista();
        vista.iniciarMenu();
    }
}