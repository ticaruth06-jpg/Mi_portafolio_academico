package Vista;

import DAO.DependenciasDAO;
import java.util.Scanner;

public class DependenciasVista {
    private DependenciasDAO dao;
    private Scanner scanner;

    public DependenciasVista() {
        this.dao = new DependenciasDAO();
        this.scanner = new Scanner(System.in);
    }

    public void iniciarMenu() {
        int opcion;
        do {
            System.out.println("\n==================================================================");
            System.out.println("   SISTEMA DE ANÁLISIS DE DEPENDENCIAS DE TAREAS (PROYECTO 02)   ");
            System.out.println("==================================================================");
            System.out.println("1.  [RF01] Registrar tarea (Código único, Descripción, Estado).");
            System.out.println("2.  [RF02] Registrar dependencias entre dos tareas existentes.");
            System.out.println("3.  [RF03] Consultar las dependencias directas de una tarea.");
            System.out.println("4.  [RF04] Mostrar recursivamente todas las dependencias indirectas.");
            System.out.println("5.  [RF05] Determinar la profundidad máxima de la cadena.");
            System.out.println("6.  [RF06] Detectar ciclos en el grafo de dependencias.");
            System.out.println("7.  [RF07] Identificar las tareas bloqueadas por prerrequisitos.");
            System.out.println("8.  [RF08] Generar un reporte de tareas pendientes, completadas y bloqueadas.");
            System.out.println("9.  Salir ");
            System.out.print("Elija una opción (1-9): ");

            while (!scanner.hasNextInt()) {
                System.out.println("❌ Por favor ingrese un número válido.");
                scanner.next();
                System.out.print("Elija una opción (1-9): ");
            }
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    System.out.println("\n--- [RF01] REGISTRAR TAREA ---");
                    System.out.print("Ingrese Código único: ");
                    String cod = scanner.nextLine();
                    System.out.print("Ingrese Descripción: ");
                    String desc = scanner.nextLine();
                    System.out.print("Ingrese Estado (PENDIENTE / COMPLETADA): ");
                    String estado = scanner.nextLine().toUpperCase();
                    dao.registrarTarea(cod, desc, estado);
                    break;

                case 2:
                    System.out.println("\n--- [RF02] REGISTRAR DEPENDENCIA ---");
                    System.out.print("Ingrese Código de la Tarea principal: ");
                    String tPrin = scanner.nextLine();
                    System.out.print("Ingrese Código de la Tarea Prerrequisito (de la que depende): ");
                    String tPrereq = scanner.nextLine();
                    dao.registrarDependencia(tPrin, tPrereq);
                    break;

                case 3:
                    System.out.println("\n--- [RF03] CONSULTAR DEPENDENCIAS DIRECTAS ---");
                    System.out.print("Ingrese el código de la tarea: ");
                    String cDir = scanner.nextLine();
                    dao.consultarDependenciasDirectas(cDir);
                    break;

                case 4:
                    System.out.println("\n--- [RF04] MOSTRAR DEPENDENCIAS INDIRECTAS ---");
                    System.out.print("Ingrese el código de la tarea: ");
                    String cIndir = scanner.nextLine();
                    dao.mostrarDependenciasIndirectas(cIndir);
                    break;

                case 5:
                    System.out.println("\n--- [RF05] PROFUNDIDAD MÁXIMA DE DEPENDENCIAS ---");
                    System.out.print("Ingrese el código de la tarea: ");
                    String cProf = scanner.nextLine();
                    int prof = dao.determinarProfundidadMaxima(cProf);
                    System.out.println("✔ La profundidad máxima de la cadena de dependencias para [" + cProf + "] es: " + prof);
                    break;

                case 6:
                    dao.detectarCiclosGlobales(); // [RF06]
                    break;

                case 7:
                    dao.identificarTareasBloqueadas(); // [RF07]
                    break;

                case 8:
                    dao.generarReporteGeneral(); // [RF08]
                    break;

                case 9:
                    System.out.println("Saliendo de la aplicación...");
                    break;

                default:
                    System.out.println("❌ Opción inválida.");
            }
        } while (opcion != 9);
    }
}