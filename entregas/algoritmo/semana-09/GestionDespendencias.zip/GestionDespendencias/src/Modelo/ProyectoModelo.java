package Modelo;

import java.util.ArrayList;

public class ProyectoModelo {
    private ArrayList<TareaModelo> listaTareas;

    public ProyectoModelo() {
        this.listaTareas = new ArrayList<>();
    }

    public ArrayList<TareaModelo> getListaTareas() {
        return listaTareas;
    }

    public void agregarTarea(TareaModelo tarea) {
        listaTareas.add(tarea);
    }
}