package Modelo;

import java.util.ArrayList;

public class TareaModelo {
    private String codigo;
    private String descripcion;
    private String estado; // "PENDIENTE" o "COMPLETADA"
    private ArrayList<TareaModelo> dependenciasDirectas; // Tareas de las cuales depende directamente

    public TareaModelo(String codigo, String descripcion, String estado) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.estado = estado;
        this.dependenciasDirectas = new ArrayList<>();
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public ArrayList<TareaModelo> getDependenciasDirectas() { return dependenciasDirectas; }

    public void agregarDependenciaDirecta(TareaModelo tarea) {
        if (!dependenciasDirectas.contains(tarea)) {
            dependenciasDirectas.add(tarea);
        }
    }
}