package DAO;

import Modelo.ProyectoModelo;
import Modelo.TareaModelo;
import java.util.ArrayList;

public class DependenciasDAO {
    private ProyectoModelo proyecto;

    public DependenciasDAO() {
        this.proyecto = new ProyectoModelo();
    }

    public TareaModelo buscarTareaPorCodigo(String codigo) {
        for (TareaModelo t : proyecto.getListaTareas()) {
            if (t.getCodigo().equalsIgnoreCase(codigo)) {
                return t;
            }
        }
        return null;
    }

    // =========================================================================
    // RF01: Registrar tareas mediante un código único, descripción y estado.
    // =========================================================================
    public boolean registrarTarea(String codigo, String descripcion, String estado) {
        if (buscarTareaPorCodigo(codigo) != null) {
            System.out.println("❌ Error: Ya existe una tarea con el código " + codigo + " (RF01).");
            return false;
        }
        TareaModelo nuevaTarea = new TareaModelo(codigo, descripcion, estado);
        proyecto.agregarTarea(nuevaTarea);
        System.out.println("✔ Tarea registrada exitosamente (RF01).");
        return true;
    }

    // =========================================================================
    // RF02: Registrar dependencias entre dos tareas existentes.
    // =========================================================================
    public boolean registrarDependencia(String codigoTarea, String codigoPrerrequisito) {
        TareaModelo tarea = buscarTareaPorCodigo(codigoTarea);
        TareaModelo prerrequisito = buscarTareaPorCodigo(codigoPrerrequisito);

        if (tarea == null || prerrequisito == null) {
            System.out.println("❌ Error: Una o ambas tareas no existen en el sistema (RF02).");
            return false;
        }

        if (tarea.getCodigo().equalsIgnoreCase(prerrequisito.getCodigo())) {
            System.out.println("❌ Error: Una tarea no puede depender de sí misma.");
            return false;
        }

        // Validación preventiva de ciclos (RF06)
        if (detectarCicloAlAgregar(prerrequisito, tarea)) {
            System.out.println("❌ Error: No se puede registrar la dependencia porque genera un ciclo (RF06).");
            return false;
        }

        tarea.agregarDependenciaDirecta(prerrequisito);
        System.out.println("✔ Dependencia registrada correctamente: [" + tarea.getCodigo() + "] depende de [" + prerrequisito.getCodigo() + "] (RF02).");
        return true;
    }

    // =========================================================================
    // RF03: Consultar las dependencias directas de una tarea.
    // =========================================================================
    public void consultarDependenciasDirectas(String codigo) {
        TareaModelo tarea = buscarTareaPorCodigo(codigo);
        if (tarea == null) {
            System.out.println("❌ Tarea no encontrada.");
            return;
        }

        System.out.println("\n--- [RF03] Dependencias directas de la tarea [" + tarea.getCodigo() + "] ---");
        if (tarea.getDependenciasDirectas().isEmpty()) {
            System.out.println("La tarea no tiene dependencias directas.");
        } else {
            for (TareaModelo dep : tarea.getDependenciasDirectas()) {
                System.out.println("  ↳ [" + dep.getCodigo() + "] " + dep.getDescripcion() + " (Estado: " + dep.getEstado() + ")");
            }
        }
    }

    // =========================================================================
    // RF04: Mostrar recursivamente todas las dependencias indirectas de una tarea.
    // =========================================================================
    public void mostrarDependenciasIndirectas(String codigo) {
        TareaModelo tarea = buscarTareaPorCodigo(codigo);
        if (tarea == null) {
            System.out.println("❌ Tarea no encontrada.");
            return;
        }

        System.out.println("\n--- [RF04] Dependencias (Directas e Indirectas) de [" + tarea.getCodigo() + "] ---");
        ArrayList<String> visitadas = new ArrayList<>();
        recorrerDependenciasRecursivo(tarea, visitadas);
        if (visitadas.isEmpty()) {
            System.out.println("No hay dependencias registradas.");
        }
    }

    private void recorrerDependenciasRecursivo(TareaModelo actual, ArrayList<String> visitadas) {
        for (TareaModelo dep : actual.getDependenciasDirectas()) {
            if (!visitadas.contains(dep.getCodigo())) {
                visitadas.add(dep.getCodigo());
                System.out.println("  ↳ Requiere a: [" + dep.getCodigo() + "] " + dep.getDescripcion());
                recorrerDependenciasRecursivo(dep, visitadas);
            }
        }
    }

    // =========================================================================
    // RF05: Determinar la profundidad máxima de la cadena de dependencias.
    // =========================================================================
    public int determinarProfundidadMaxima(String codigo) {
        TareaModelo tarea = buscarTareaPorCodigo(codigo);
        if (tarea == null) return 0;
        return calcularProfundidadRecursiva(tarea, new ArrayList<>());
    }

    private int calcularProfundidadRecursiva(TareaModelo tarea, ArrayList<String> caminoActual) {
        if (tarea.getDependenciasDirectas().isEmpty()) {
            return 0;
        }
        int maxProfundidad = 0;
        for (TareaModelo dep : tarea.getDependenciasDirectas()) {
            if (!caminoActual.contains(dep.getCodigo())) {
                caminoActual.add(dep.getCodigo());
                int prof = 1 + calcularProfundidadRecursiva(dep, caminoActual);
                if (prof > maxProfundidad) {
                    maxProfundidad = prof;
                }
                caminoActual.remove(dep.getCodigo());
            }
        }
        return maxProfundidad;
    }

    // =========================================================================
    // RF06: Detectar ciclos en el grafo de dependencias.
    // =========================================================================
    public void detectarCiclosGlobales() {
        System.out.println("\n--- [RF06] Análisis de ciclos en el grafo de dependencias ---");
        boolean hayCiclo = false;
        for (TareaModelo t : proyecto.getListaTareas()) {
            ArrayList<String> visitadosGlobal = new ArrayList<>();
            ArrayList<String> recursionStack = new ArrayList<>();
            if (verificarCicloDFS(t, visitadosGlobal, recursionStack)) {
                System.out.println("⚠️ ¡Ciclo detectado involucrando a la tarea [" + t.getCodigo() + "]!");
                hayCiclo = true;
                break;
            }
        }
        if (!hayCiclo) {
            System.out.println("✔ No se detectaron ciclos en el grafo de dependencias. La planificación es válida.");
        }
    }

    private boolean verificarCicloDFS(TareaModelo actual, ArrayList<String> visitados, ArrayList<String> recursionStack) {
        if (recursionStack.contains(actual.getCodigo())) {
            return true;
        }
        if (visitados.contains(actual.getCodigo())) {
            return false;
        }

        visitados.add(actual.getCodigo());
        recursionStack.add(actual.getCodigo());

        for (TareaModelo dep : actual.getDependenciasDirectas()) {
            if (verificarCicloDFS(dep, visitados, recursionStack)) {
                return true;
            }
        }

        recursionStack.remove(actual.getCodigo());
        return false;
    }

    private boolean detectarCicloAlAgregar(TareaModelo inicio, TareaModelo objetivo) {
        ArrayList<String> visitados = new ArrayList<>();
        return buscarCaminoDFS(inicio, objetivo, visitados);
    }

    private boolean buscarCaminoDFS(TareaModelo actual, TareaModelo objetivo, ArrayList<String> visitados) {
        if (actual.getCodigo().equalsIgnoreCase(objetivo.getCodigo())) {
            return true;
        }
        visitados.add(actual.getCodigo());
        for (TareaModelo dep : actual.getDependenciasDirectas()) {
            if (!visitados.contains(dep.getCodigo())) {
                if (buscarCaminoDFS(dep, objetivo, visitados)) {
                    return true;
                }
            }
        }
        return false;
    }

    // =========================================================================
    // RF07: Identificar las tareas bloqueadas por prerrequisitos pendientes.
    // =========================================================================
    public void identificarTareasBloqueadas() {
        System.out.println("\n--- [RF07] Tareas Bloqueadas por Prerrequisitos Pendientes ---");
        boolean encontrado = false;

        for (TareaModelo t : proyecto.getListaTareas()) {
            if (t.getEstado().equalsIgnoreCase("PENDIENTE")) {
                boolean bloqueada = false;
                ArrayList<String> prerrequisitosPendientes = new ArrayList<>();
                for (TareaModelo dep : t.getDependenciasDirectas()) {
                    if (dep.getEstado().equalsIgnoreCase("PENDIENTE")) {
                        bloqueada = true;
                        prerrequisitosPendientes.add(dep.getCodigo());
                    }
                }
                if (bloqueada) {
                    encontrado = true;
                    System.out.println("• Tarea Bloqueada: [" + t.getCodigo() + "] " + t.getDescripcion() + " (Esperando por: " + prerrequisitosPendientes + ")");
                }
            }
        }
        if (!encontrado) {
            System.out.println("No hay tareas bloqueadas actualmente.");
        }
    }

    // =========================================================================
    // RF08: Generar un reporte de tareas pendientes, completadas y bloqueadas.
    // =========================================================================
    public void generarReporteGeneral() {
        System.out.println("\n==================================================");
        System.out.println("  [RF08] REPORTE GENERAL DE ESTADO DE TAREAS      ");
        System.out.println("==================================================");

        ArrayList<TareaModelo> pendientes = new ArrayList<>();
        ArrayList<TareaModelo> completadas = new ArrayList<>();
        ArrayList<TareaModelo> bloqueadas = new ArrayList<>();

        for (TareaModelo t : proyecto.getListaTareas()) {
            if (t.getEstado().equalsIgnoreCase("COMPLETADA")) {
                completadas.add(t);
            } else {
                boolean bloqueada = false;
                for (TareaModelo dep : t.getDependenciasDirectas()) {
                    if (dep.getEstado().equalsIgnoreCase("PENDIENTE")) {
                        bloqueada = true;
                        break;
                    }
                }
                if (bloqueada) {
                    bloqueadas.add(t);
                } else {
                    pendientes.add(t);
                }
            }
        }

        System.out.println("\n--- TAREAS COMPLETADAS (" + completadas.size() + ") ---");
        for (TareaModelo t : completadas) {
            System.out.println("  ✓ [" + t.getCodigo() + "] " + t.getDescripcion());
        }

        System.out.println("\n--- TAREAS PENDIENTES / DISPONIBLES (" + pendientes.size() + ") ---");
        for (TareaModelo t : pendientes) {
            System.out.println("  ⏳ [" + t.getCodigo() + "] " + t.getDescripcion());
        }

        System.out.println("\n--- TAREAS BLOQUEADAS (" + bloqueadas.size() + ") ---");
        for (TareaModelo t : bloqueadas) {
            System.out.println("  🔒 [" + t.getCodigo() + "] " + t.getDescripcion());
        }
    }

    public ProyectoModelo getProyecto() {
        return proyecto;
    }
}