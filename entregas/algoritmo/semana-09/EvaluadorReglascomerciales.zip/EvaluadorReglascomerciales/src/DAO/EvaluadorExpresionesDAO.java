package DAO;

import Modelo.ExpresionModelo;

public class EvaluadorExpresionesDAO {
    private String texto;
    private int pos;
    private int ch;

    // RF10: Validar las expresiones antes de incorporarlas a un proceso comercial
    public void evaluar(ExpresionModelo modelo) {
        if (modelo.getExpresionOriginal() == null || modelo.getExpresionOriginal().trim().isEmpty()) {
            modelo.setEsValida(false);
            modelo.setMensajeError("La expresión está vacía.");
            return;
        }

        this.texto = modelo.getExpresionOriginal();
        this.pos = -1;
        
        try {
            siguienteChar();
            double res = expresion();
            if (pos < texto.length()) {
                throw new RuntimeException("Carácter no esperado: '" + (char) ch + "'");
            }
            // RF05: Calcular y mostrar el resultado de la expresión
            modelo.setResultado(res);
            modelo.setEsValida(true);
        } catch (ArithmeticException e) {
            modelo.setEsValida(false);
            modelo.setMensajeError("Error de cálculo: " + e.getMessage());
        } catch (RuntimeException e) {
            // RF06: Detectar paréntesis sin cerrar y expresiones mal formadas
            modelo.setEsValida(false);
            modelo.setMensajeError("Error sintáctico: " + e.getMessage());
        }
    }

    private void siguienteChar() {
        ch = (++pos < texto.length()) ? texto.charAt(pos) : -1;
    }

    // RF02: Reconocer números y los operadores +, -, * y /
    private boolean consumir(int charAEncontrar) {
        while (ch == ' ') siguienteChar();
        if (ch == charAEncontrar) {
            siguienteChar();
            return true;
        }
        return false;
    }

    // RF04: Respetar la precedencia de operadores y los paréntesis (Suma y resta)
    private double expresion() {
        double x = termino();
        for (;;) {
            if (consumir('+')) x += termino();
            else if (consumir('-')) x -= termino();
            else return x;
        }
    }

    // RF07: Detectar la división por cero
    private double termino() {
        double x = factor();
        for (;;) {
            if (consumir('*')) x *= factor();
            else if (consumir('/')) {
                double divisor = factor();
                if (divisor == 0) {
                    throw new ArithmeticException("División por cero detectada.");
                }
                x /= divisor;
            } else return x;
        }
    }

    // RF03: Procesar expresiones con paréntesis anidados
    private double factor() {
        if (consumir('+')) return factor();
        if (consumir('-')) return -factor();

        double x;
        int inicioPos = this.pos;

        if (consumir('(')) {
            x = expresion();
            if (!consumir(')')) {
                throw new RuntimeException("Falta paréntesis de cierre ')'");
            }
        } else if ((ch >= '0' && ch <= '9') || ch == '.') {
            while ((ch >= '0' && ch <= '9') || ch == '.') siguienteChar();
            try {
                x = Double.parseDouble(texto.substring(inicioPos, this.pos));
            } catch (NumberFormatException e) {
                throw new RuntimeException("Número inválido o formato ambiguo");
            }
        } else if (ch == -1) {
            throw new RuntimeException("Expresión incompleta");
        } else {
            throw new RuntimeException("Carácter o símbolo no válido: '" + (char) ch + "'");
        }

        return x;
    }
}