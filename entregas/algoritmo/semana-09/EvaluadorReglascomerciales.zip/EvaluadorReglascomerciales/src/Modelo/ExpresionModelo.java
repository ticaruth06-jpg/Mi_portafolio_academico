package Modelo;

public class ExpresionModelo {
    private String expresionOriginal;
    private double resultado;
    private boolean esValida;
    private String mensajeError;

    public ExpresionModelo(String expresionOriginal) {
        this.expresionOriginal = expresionOriginal;
        this.esValida = true;
        this.mensajeError = "";
    }

    public String getExpresionOriginal() {
        return expresionOriginal;
    }

    public void setExpresionOriginal(String expresionOriginal) {
        this.expresionOriginal = expresionOriginal;
    }

    public double getResultado() {
        return resultado;
    }

    public void setResultado(double resultado) {
        this.resultado = resultado;
    }

    public boolean isEsValida() {
        return esValida;
    }

    public void setEsValida(boolean esValida) {
        this.esValida = esValida;
    }

    public String getMensajeError() {
        return mensajeError;
    }

    public void setMensajeError(String mensajeError) {
        this.mensajeError = mensajeError;
    }
}