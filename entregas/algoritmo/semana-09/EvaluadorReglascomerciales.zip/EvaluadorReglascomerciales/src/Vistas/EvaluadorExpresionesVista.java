package Vistas;

import DAO.EvaluadorExpresionesDAO;
import Modelo.ExpresionModelo;
import java.util.Scanner;

public class EvaluadorExpresionesVista {
    private final Scanner scanner;
    private final EvaluadorExpresionesDAO dao;

    public EvaluadorExpresionesVista() {
        this.scanner = new Scanner(System.in);
        this.dao = new EvaluadorExpresionesDAO();
    }

    // RF09: Permitir ejecutar varias evaluaciones en una sesión
    public void iniciar() {
        System.out.println("======================================================");
        System.out.println("EVALUADOR DE REGLAS COMERCIALES Y FORMULAS COMERCIALES");
        System.out.println("======================================================");
        
        boolean continuar = true;
        while (continuar) {
            // RF01: Permitir ingresar una expresión matemática
            System.out.print("\nIngrese la expresión matemática a (ej. (100 - 15) * (1 + 0.18)) (o 'salir' para finalizar): ");
            String entrada = scanner.nextLine();

            if (entrada.equalsIgnoreCase("salir")) {
                continuar = false;
                System.out.println("\nEjecución finalizada.");
                break;
            }

            ExpresionModelo modelo = new ExpresionModelo(entrada);
            dao.evaluar(modelo);

            mostrarResultado(modelo);
        }
    }

    // RF08: Mostrar la expresión original y su resultado
    private void mostrarResultado(ExpresionModelo modelo) {
        System.out.println("-------------------------------------------------");
        System.out.println("Expresión ingresada: " + modelo.getExpresionOriginal());
        if (modelo.isEsValida()) {
            System.out.println("Estado            : VÁLIDA");
            System.out.println("Resultado         : " + modelo.getResultado());
        } else {
            System.out.println("Estado            : INVÁLIDA / ERROR");
            System.out.println("Detalle del error : " + modelo.getMensajeError());
        }
        System.out.println("-------------------------------------------------");
    }
}