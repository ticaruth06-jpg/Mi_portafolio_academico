package Vista;

import dao.PilaAlumno;
import Modelo.Alumno;
import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Ingrese la capacidad maxima de la pila de alumnos: ");
        int capacidad = teclado.nextInt();

        PilaAlumno pila = new PilaAlumno(capacidad);
        int opcion = 0;

        do {
            System.out.println("\n========================================");
            System.out.println("   SISTEMA DE GESTION DE ALUMNOS (PILA)   ");
            System.out.println("========================================");
            System.out.println("1. Insertar Alumno (insertarPila)");
            System.out.println("2. Mostrar Alumnos (mostrarPila)");
            System.out.println("3. Eliminar Alumno del Tope (eliminaDatos)");
            System.out.println("4. Vaciar toda la Pila (eliminaPila)");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opcion: ");

            if (teclado.hasNextInt()) {
                opcion = teclado.nextInt();
                teclado.nextLine(); // Limpiar buffer de entrada
            } else {
                System.out.println("⚠️ Por favor, ingrese un número válido.");
                teclado.next();
                continue;
            }

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese Código: ");
                    String codigo = teclado.nextLine();
                    System.out.print("Ingrese Nombre: ");
                    String nombre = teclado.nextLine();
                    System.out.print("Ingrese Edad: ");
                    int edad = teclado.nextInt();
                    System.out.print("Ingrese Promedio: ");
                    double promedio = teclado.nextDouble();

                    Alumno nuevoAlumno = new Alumno(codigo, nombre, edad, promedio);
                    pila.insertarPila(nuevoAlumno);
                    break;

                case 2:
                    pila.mostrarPila();
                    break;

                case 3:
                    pila.eliminaDatos();
                    break;

                case 4:
                    pila.eliminaPila();
                    break;

                case 5:
                    System.out.println("Saliendo del sistema...");
                    break;

                default:
                    System.out.println("❌ Opción inválida. Intente de nuevo.");
            }
        } while (opcion != 5);

        teclado.close();
    }
}
