package dao;

import Modelo.Alumno;

public class PilaAlumno {

    private int capacidad;
    private Alumno[] arregloPila;
    private int tope; // Índice que indica la cima de la pila

    // Constructor
    public PilaAlumno(int capacidad) {
        this.capacidad = capacidad;
        this.arregloPila = new Alumno[capacidad];
        this.tope = -1; // -1 indica que la pila está vacía
    }

    // Método auxiliar: Verificar si está llena
    public boolean estaLlena() {
        return tope == capacidad - 1;
    }

    // Método auxiliar: Verificar si está vacía
    public boolean estaVacia() {
        return tope == -1;
    }

    // a) insertarPila() [Push]
    public boolean insertarPila(Alumno alumno) {
        if (estaLlena()) {
            System.out.println("❌ Error: Desbordamiento (Stack Overflow). La pila está llena.");
            return false;
        }
        tope++;
        arregloPila[tope] = alumno;
        System.out.println("✅ Alumno insertado correctamente en el tope.");
        return true;
    }

    // b) mostrarPila()
    public void mostrarPila() {
        if (estaVacia()) {
            System.out.println("⚠️ La pila de alumnos está vacía.");
            return;
        }
        System.out.println("\n--- CONTENIDO DE LA PILA DE ALUMNOS (Cima a Base) ---");
        for (int i = tope; i >= 0; i--) {
            if (i == tope) {
                System.out.println("-> [CIMA] " + arregloPila[i]);
            } else {
                System.out.println("   [     ] " + arregloPila[i]);
            }
        }
        System.out.println("--------------------------------------------------");
    }

    // c) eliminaDatos() [Pop]
    public Alumno eliminaDatos() {
        if (estaVacia()) {
            System.out.println("❌ Error: Subdesbordamiento (Stack Underflow). No hay alumnos para eliminar.");
            return null;
        }
        Alumno alumnoEliminado = arregloPila[tope];
        arregloPila[tope] = null; // Limpiar la referencia
        tope--;
        System.out.println("🗑️ Alumno eliminado del tope con éxito: " + alumnoEliminado.getNombre());
        return alumnoEliminado;
    }

    // d) eliminaPila()
    public void eliminaPila() {
        if (estaVacia()) {
            System.out.println("⚠️ La pila ya se encuentra vacía.");
            return;
        }
        // Liberar referencias del arreglo y reiniciar el tope
        for (int i = 0; i <= tope; i++) {
            arregloPila[i] = null;
        }
        tope = -1;
        System.out.println("🧹 La pila de alumnos ha sido vaciada por completo.");
    }
}
