package pe.edu.sistema.service;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import pe.edu.sistema.dao.UsuarioDAO;
import pe.edu.sistema.model.Usuario;

/**
 * Servicio de cuentas (tabla Usuario de SQL Server, vía UsuarioDAO).
 * El administrador (admin) se crea con el script CompuTechDB.sql; cualquier
 * persona que se registre recibe siempre el rol USUARIO.
 */
public class UsuarioService {

    private static final UsuarioService INSTANCIA = new UsuarioService();

    private final UsuarioDAO dao = new UsuarioDAO();

    private UsuarioService() { }

    public static UsuarioService getInstance() { return INSTANCIA; }

    /** Devuelve el usuario si las credenciales son correctas; si no, null. */
    public synchronized Usuario autenticar(String login, String clave) {
        if (login == null || clave == null) return null;
        Usuario u = buscar(login);
        return (u != null && coincide(clave, u.getClaveHash())) ? u : null;
    }

    public synchronized Usuario buscar(String login) {
        if (login == null || login.trim().isEmpty()) return null;
        return dao.buscar(login);
    }

    /** Valida los datos de un registro. Devuelve la lista de errores (vacía si es válido). */
    public List<String> validarRegistro(String nombre, String login, String correo,
                                        String clave, String clave2) {
        List<String> errores = new ArrayList<>();
        if (nombre == null || nombre.trim().length() < 3) {
            errores.add("Ingrese su nombre completo (mínimo 3 caracteres).");
        }
        if (login == null || !login.trim().matches("[A-Za-z0-9_.]{4,20}")) {
            errores.add("El usuario debe tener de 4 a 20 caracteres (letras, números, punto o guion bajo).");
        } else if (buscar(login) != null) {
            errores.add("El usuario \"" + login.trim() + "\" ya está en uso. Elija otro.");
        }
        if (correo == null || !correo.trim().matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {
            errores.add("Ingrese un correo electrónico válido.");
        }
        if (clave == null || clave.length() < 6) {
            errores.add("La contraseña debe tener al menos 6 caracteres.");
        } else if (!clave.equals(clave2)) {
            errores.add("Las contraseñas no coinciden.");
        }
        return errores;
    }

    /** Crea una cuenta nueva. SIEMPRE con rol USUARIO (nunca administrador). */
    public synchronized Usuario registrar(String nombre, String login, String correo, String clave) {
        Usuario u = new Usuario(login.trim(), cifrar(clave), nombre.trim(), correo.trim(), Usuario.USUARIO);
        dao.insertar(u);
        return u;
    }

    // ------------------------------------------------------ cifrado de contraseñas

    /** Cifra la contraseña con PBKDF2 + sal aleatoria. Formato: sal:hash (Base64). */
    private static String cifrar(String clave) {
        byte[] sal = new byte[16];
        new SecureRandom().nextBytes(sal);
        return Base64.getEncoder().encodeToString(sal) + ":" + Base64.getEncoder().encodeToString(pbkdf2(clave, sal));
    }

    private static boolean coincide(String clave, String guardado) {
        String[] partes = guardado.split(":");
        byte[] sal = Base64.getDecoder().decode(partes[0]);
        byte[] esperado = Base64.getDecoder().decode(partes[1]);
        return java.security.MessageDigest.isEqual(esperado, pbkdf2(clave, sal));
    }

    private static byte[] pbkdf2(String clave, byte[] sal) {
        try {
            PBEKeySpec spec = new PBEKeySpec(clave.toCharArray(), sal, 65536, 256);
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo cifrar la contraseña", e);
        }
    }
}
