package pe.edu.sistema.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import pe.edu.sistema.model.Usuario;
import pe.edu.sistema.util.Conexion;

/** Acceso a datos de la tabla Usuario (SQL Server). */
public class UsuarioDAO {

    public Usuario buscar(String login) {
        String sql = "SELECT login, clave_hash, nombre, correo, rol FROM dbo.Usuario WHERE login = ?";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, login.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Usuario(rs.getString("login"), rs.getString("clave_hash"),
                            rs.getString("nombre"), rs.getString("correo"), rs.getString("rol"));
                }
            }
            return null;
        } catch (SQLException e) {
            throw new IllegalStateException("Error de base de datos: " + e.getMessage(), e);
        }
    }

    public void insertar(Usuario u) {
        String sql = "INSERT INTO dbo.Usuario (login, clave_hash, nombre, correo, rol) VALUES (?,?,?,?,?)";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, u.getLogin());
            ps.setString(2, u.getClaveHash());
            ps.setString(3, u.getNombre());
            ps.setString(4, u.getCorreo());
            ps.setString(5, u.getRol());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Error de base de datos: " + e.getMessage(), e);
        }
    }
}
