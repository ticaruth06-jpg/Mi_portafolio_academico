package pe.edu.sistema.model;

/** Modelo: usuario del sistema con rol ADMIN, ALMACENERO o USUARIO (cliente). La contraseña se guarda cifrada (hash). */
public class Usuario {

    public static final String ADMIN = "ADMIN";
    public static final String ALMACENERO = "ALMACENERO";
    public static final String USUARIO = "USUARIO";

    private final String login;
    private final String claveHash;
    private final String nombre;
    private final String correo;
    private final String rol;

    public Usuario(String login, String claveHash, String nombre, String correo, String rol) {
        this.login = login;
        this.claveHash = claveHash;
        this.nombre = nombre;
        this.correo = correo;
        this.rol = rol;
    }

    public String getLogin() { return login; }
    public String getClaveHash() { return claveHash; }
    public String getNombre() { return nombre; }
    public String getCorreo() { return correo; }
    public String getRol() { return rol; }
    public boolean isAdmin() { return ADMIN.equals(rol); }
    /** Almacenero: solo actualiza el stock y el estado de los productos. */
    public boolean isAlmacenero() { return ALMACENERO.equals(rol); }
    /** Cliente de la tienda (puede usar el carrito). */
    public boolean isCliente() { return USUARIO.equals(rol); }
    /** Personal interno (ADMIN o ALMACENERO): puede ver el inventario y el resumen. */
    public boolean isPersonal() { return isAdmin() || isAlmacenero(); }
}
