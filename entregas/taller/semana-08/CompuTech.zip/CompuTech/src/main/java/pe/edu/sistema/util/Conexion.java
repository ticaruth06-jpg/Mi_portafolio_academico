package pe.edu.sistema.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Conexión de la aplicación con la base de datos SQL Server (CompuTechDB).
 * Lee los datos de conexión de /db.properties (carpeta src/main/resources).
 */
public final class Conexion {

    private static final Properties CFG = new Properties();

    static {
        try (InputStream in = Conexion.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (in != null) CFG.load(in);
        } catch (IOException e) {
            // se usan los valores por defecto
        }
    }

    private Conexion() { }

    private static String url() {
        String host = CFG.getProperty("db.host", "localhost");
        String puerto = CFG.getProperty("db.port", "1433");
        String bd = CFG.getProperty("db.name", "CompuTechDB");
        // Si el host incluye instancia (localhost\SQLEXPRESS) no se indica puerto
        String servidor = host.contains("\\") ? host : host + ":" + puerto;
        return "jdbc:sqlserver://" + servidor + ";databaseName=" + bd
                + ";encrypt=true;trustServerCertificate=true;loginTimeout=8";
    }

    /** Abre una conexión nueva. Quien la llame debe cerrarla (try-with-resources). */
    public static Connection getConexion() throws SQLException {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("Falta el driver JDBC de SQL Server (mssql-jdbc).", e);
        }
        return DriverManager.getConnection(url(),
                CFG.getProperty("db.user", "sa"),
                CFG.getProperty("db.password", "123"));
    }
}
