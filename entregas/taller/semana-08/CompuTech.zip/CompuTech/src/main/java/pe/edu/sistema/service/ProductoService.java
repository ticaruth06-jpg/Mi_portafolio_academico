package pe.edu.sistema.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import pe.edu.sistema.dao.ProductoDAO;
import pe.edu.sistema.model.Producto;

/**
 * Servicio de productos. Los datos se guardan en SQL Server (tabla Producto)
 * a través de ProductoDAO. Es un singleton compartido por todos los servlets.
 */
public class ProductoService {

    public static final List<String> CATEGORIAS = Arrays.asList(
            "Laptops", "Computadoras", "Monitores", "Periféricos",
            "Componentes", "Almacenamiento", "Redes", "Audio");

    public static final List<String> ESTADOS = Arrays.asList(
            "Disponible", "Agotado");

    private static final ProductoService INSTANCIA = new ProductoService();

    private final ProductoDAO dao = new ProductoDAO();

    private ProductoService() { }

    public static ProductoService getInstance() { return INSTANCIA; }

    // ---------------------------------------------------------------- consultas

    public List<Producto> listar() { return dao.listar(); }

    public Producto buscarPorCodigo(String codigo) {
        if (codigo == null) return null;
        return dao.buscarPorCodigo(codigo);
    }

    /** Busca por "codigo", "nombre", "categoria" o "todos". */
    public List<Producto> buscar(String criterio, String texto) {
        return dao.buscar(criterio, texto);
    }

    // ------------------------------------------------------------- validaciones

    /**
     * Valida un producto. Devuelve la lista de errores (vacía si es válido).
     * @param esNuevo true al registrar (se comprueba que el código no esté duplicado)
     */
    public List<String> validar(Producto p, boolean esNuevo) {
        List<String> errores = new ArrayList<>();
        if (p.getCodigo() == null || p.getCodigo().trim().isEmpty()) {
            errores.add("El código es obligatorio.");
        } else if (esNuevo && buscarPorCodigo(p.getCodigo()) != null) {
            errores.add("El código " + p.getCodigo().trim().toUpperCase() + " ya existe: no se permiten códigos duplicados.");
        }
        if (p.getNombre() == null || p.getNombre().trim().isEmpty()) {
            errores.add("El nombre es obligatorio.");
        }
        if (p.getCategoria() == null || p.getCategoria().trim().isEmpty()) {
            errores.add("La categoría es obligatoria.");
        }
        if (p.getPrecio() <= 0) {
            errores.add("El precio debe ser mayor que cero.");
        }
        if (p.getStock() < 0) {
            errores.add("El stock debe ser mayor o igual a cero.");
        }
        return errores;
    }

    // --------------------------------------------------------------------- CRUD

    public void registrar(Producto p) {
        normalizar(p);
        dao.insertar(p);
    }

    public void actualizar(Producto nuevo) {
        Producto actual = buscarPorCodigo(nuevo.getCodigo());
        if (actual != null && (nuevo.getImagen() == null || nuevo.getImagen().isEmpty())) {
            nuevo.setImagen(actual.getImagen());
        }
        normalizar(nuevo);
        dao.actualizar(nuevo);
    }

    /** Cambia solo stock y estado. Con stock 0 el estado queda siempre en Agotado. */
    public void actualizarStock(String codigo, int stock, String estado) {
        String est = (stock == 0 || "Agotado".equalsIgnoreCase(estado)) ? "Agotado" : "Disponible";
        dao.actualizarStock(codigo, stock, est);
    }

    public boolean eliminar(String codigo) {
        return codigo != null && dao.eliminar(codigo);
    }

    /** Ajusta código, estado e imagen por defecto antes de guardar. */
    private void normalizar(Producto p) {
        p.setCodigo(p.getCodigo().trim().toUpperCase());
        p.setNombre(p.getNombre().trim());
        // Se respeta el estado elegido en el formulario (Disponible | Agotado).
        // Única regla automática: con stock 0 el producto siempre queda Agotado.
        if (p.getStock() == 0 || "Agotado".equalsIgnoreCase(p.getEstado())) {
            p.setEstado("Agotado");
        } else {
            p.setEstado("Disponible");
        }
        if (p.getImagen() == null || p.getImagen().isEmpty()) {
            p.setImagen(imagenPorCategoria(p.getCategoria()));
        }
        if (p.getMarca() == null) p.setMarca("");
        if (p.getDescripcion() == null) p.setDescripcion("");
    }

    private String imagenPorCategoria(String categoria) {
        switch (categoria) {
            case "Laptops":        return "laptop.svg";
            case "Computadoras":   return "pc.svg";
            case "Monitores":      return "monitor.svg";
            case "Componentes":    return "gpu.svg";
            case "Almacenamiento": return "ssd.svg";
            case "Redes":          return "router.svg";
            case "Audio":          return "auriculares.svg";
            default:               return "mouse.svg";
        }
    }

    // ----------------------------------------------------------------- reportes

    public List<Producto> disponibles() { return dao.disponibles(); }

    public int totalProductos() { return dao.listar().size(); }
    public int totalDisponibles() { return disponibles().size(); }
    public int totalAgotados() { return totalProductos() - totalDisponibles(); }

    public double valorTotalInventario() {
        double total = 0;
        for (Producto p : dao.listar()) total += p.getValorInventario();
        return total;
    }

    public int stockTotal() {
        int total = 0;
        for (Producto p : dao.listar()) total += p.getStock();
        return total;
    }
}
