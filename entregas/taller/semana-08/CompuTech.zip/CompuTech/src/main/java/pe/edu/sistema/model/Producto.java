package pe.edu.sistema.model;

/** Modelo: representa un producto de CompuTech. */
public class Producto {

    private String codigo;
    private String nombre;
    private String marca;
    private String categoria;
    private double precio;
    private int stock;
    private String estado;      // Disponible | Agotado
    private String descripcion;
    private String imagen;      // nombre del archivo en /img

    public Producto() { }

    public Producto(String codigo, String nombre, String marca, String categoria,
                    double precio, int stock, String estado,
                    String descripcion, String imagen) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.marca = marca;
        this.categoria = categoria;
        this.precio = precio;
        this.stock = stock;
        this.estado = estado;
        this.descripcion = descripcion;
        this.imagen = imagen;
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getMarca() { return marca; }
    public void setMarca(String marca) { this.marca = marca; }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public String getImagen() { return imagen; }
    public void setImagen(String imagen) { this.imagen = imagen; }

    /** true si se puede vender: estado Disponible y con stock. */
    public boolean isDisponible() { return "Disponible".equals(estado) && stock > 0; }

    /** Valor del producto en inventario (precio x stock). */
    public double getValorInventario() { return precio * stock; }
}
