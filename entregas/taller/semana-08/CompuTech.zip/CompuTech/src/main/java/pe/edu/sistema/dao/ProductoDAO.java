package pe.edu.sistema.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import pe.edu.sistema.model.Producto;
import pe.edu.sistema.util.Conexion;

/** Acceso a datos de la tabla Producto (SQL Server). */
public class ProductoDAO {

    private static final String SELECT =
            "SELECT p.codigo, p.nombre, COALESCE(m.nombre, '') AS marca, c.nombre AS categoria, p.precio, p.stock, "
          + "p.estado, p.descripcion, p.imagen "
          + "FROM dbo.Producto p INNER JOIN dbo.Categoria c ON c.id_categoria = p.id_categoria "
          + "LEFT JOIN dbo.Marca m ON m.id_marca = p.id_marca ";

    private Producto mapear(ResultSet rs) throws SQLException {
        return new Producto(rs.getString("codigo"), rs.getString("nombre"), rs.getString("marca"),
                rs.getString("categoria"), rs.getDouble("precio"), rs.getInt("stock"),
                rs.getString("estado"), rs.getString("descripcion"), rs.getString("imagen"));
    }

    private List<Producto> consultar(String sqlResto, String... params) {
        List<Producto> lista = new ArrayList<>();
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(SELECT + sqlResto)) {
            for (int i = 0; i < params.length; i++) ps.setString(i + 1, params[i]);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) lista.add(mapear(rs));
            }
            return lista;
        } catch (SQLException e) {
            throw new IllegalStateException("Error de base de datos: " + e.getMessage(), e);
        }
    }

    public List<Producto> listar() { return consultar("ORDER BY p.codigo"); }

    public List<Producto> disponibles() { return consultar("WHERE p.stock > 0 AND p.estado = 'Disponible' ORDER BY p.codigo"); }

    public Producto buscarPorCodigo(String codigo) {
        List<Producto> l = consultar("WHERE p.codigo = ?", codigo.trim());
        return l.isEmpty() ? null : l.get(0);
    }

    /** criterio: codigo | nombre | categoria | todos */
    public List<Producto> buscar(String criterio, String texto) {
        String like = "%" + (texto == null ? "" : texto.trim()) + "%";
        switch (criterio == null ? "todos" : criterio) {
            case "codigo":    return consultar("WHERE p.codigo LIKE ? ORDER BY p.codigo", like);
            case "nombre":    return consultar("WHERE p.nombre LIKE ? ORDER BY p.codigo", like);
            case "categoria": return consultar("WHERE c.nombre LIKE ? ORDER BY p.codigo", like);
            default:          return consultar("WHERE p.codigo LIKE ? OR p.nombre LIKE ? OR c.nombre LIKE ? "
                                             + "ORDER BY p.codigo", like, like, like);
        }
    }

    /** Crea la marca en la tabla Marca si todavía no existe (marca vacía = sin marca). */
    private static final String ASEGURAR_MARCA =
            "IF ? <> '' AND NOT EXISTS (SELECT 1 FROM dbo.Marca WHERE nombre = ?) "
          + "INSERT INTO dbo.Marca (nombre) VALUES (?); ";

    private static String marcaDe(Producto p) {
        return p.getMarca() == null ? "" : p.getMarca().trim();
    }

    public void insertar(Producto p) {
        String sql = ASEGURAR_MARCA
                   + "INSERT INTO dbo.Producto (codigo, nombre, id_marca, id_categoria, precio, stock, estado, descripcion, imagen) "
                   + "VALUES (?,?,(SELECT id_marca FROM dbo.Marca WHERE nombre = ?),"
                   + "(SELECT id_categoria FROM dbo.Categoria WHERE nombre = ?),?,?,?,?,?)";
        String marca = marcaDe(p);
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, marca);
            ps.setString(2, marca);
            ps.setString(3, marca);
            ps.setString(4, p.getCodigo());
            ps.setString(5, p.getNombre());
            ps.setString(6, marca);
            ps.setString(7, p.getCategoria());
            ps.setBigDecimal(8, java.math.BigDecimal.valueOf(p.getPrecio()));
            ps.setInt(9, p.getStock());
            ps.setString(10, p.getEstado());
            ps.setString(11, p.getDescripcion());
            ps.setString(12, p.getImagen());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Error de base de datos: " + e.getMessage(), e);
        }
    }

    public void actualizar(Producto p) {
        String sql = ASEGURAR_MARCA
                   + "UPDATE dbo.Producto SET nombre=?, "
                   + "id_marca=(SELECT id_marca FROM dbo.Marca WHERE nombre = ?), "
                   + "id_categoria=(SELECT id_categoria FROM dbo.Categoria WHERE nombre = ?), "
                   + "precio=?, stock=?, estado=?, descripcion=?, imagen=? WHERE codigo=?";
        String marca = marcaDe(p);
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, marca);
            ps.setString(2, marca);
            ps.setString(3, marca);
            ps.setString(4, p.getNombre());
            ps.setString(5, marca);
            ps.setString(6, p.getCategoria());
            ps.setBigDecimal(7, java.math.BigDecimal.valueOf(p.getPrecio()));
            ps.setInt(8, p.getStock());
            ps.setString(9, p.getEstado());
            ps.setString(10, p.getDescripcion());
            ps.setString(11, p.getImagen());
            ps.setString(12, p.getCodigo());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Error de base de datos: " + e.getMessage(), e);
        }
    }

    /** Actualiza solo el stock y el estado (usado por el ALMACENERO). */
    public void actualizarStock(String codigo, int stock, String estado) {
        String sql = "UPDATE dbo.Producto SET stock=?, estado=? WHERE codigo=?";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, stock);
            ps.setString(2, estado);
            ps.setString(3, codigo.trim().toUpperCase());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Error de base de datos: " + e.getMessage(), e);
        }
    }

    public boolean eliminar(String codigo) {
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement("DELETE FROM dbo.Producto WHERE codigo = ?")) {
            ps.setString(1, codigo.trim());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new IllegalStateException("Error de base de datos: " + e.getMessage(), e);
        }
    }
}
