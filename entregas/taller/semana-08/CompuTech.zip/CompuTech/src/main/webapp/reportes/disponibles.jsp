<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="paginaTitulo" value="Productos disponibles" scope="request"/>
<c:set var="activo" value="reportes" scope="request"/>
<jsp:include page="/includes/header.jsp"/>

<div class="page-title">
    <div><div class="crumbs"><a href="${ctx}/inicio">Inicio</a> / Reportes / Productos disponibles</div>
        <h1>Productos disponibles</h1>
        <p>Solo se muestran los productos con stock mayor que cero (${productos.size()}).</p></div>
    <c:if test="${sessionScope.usuario.personal}"><a class="btn ghost" href="${ctx}/reportes?tipo=resumen">Ver resumen →</a></c:if>
</div>

<div class="tbl-wrap"><table>
    <thead><tr><th>Código</th><th>Producto</th><th>Categoría</th><th class="num">Precio (S/)</th><th class="num">Stock</th><th>Estado</th></tr></thead>
    <tbody>
    <c:forEach var="p" items="${productos}">
        <tr>
            <td class="code">${p.codigo}</td>
            <td><div class="thumb"><img src="${ctx}/img/productos/${p.codigo}.jpg" onerror="this.onerror=null;this.src='${ctx}/img/${p.imagen}'" alt=""><div><b>${p.nombre}</b><small>${p.marca}</small></div></div></td>
            <td>${p.categoria}</td>
            <td class="num"><fmt:formatNumber value="${p.precio}" pattern="#,##0.00"/></td>
            <td class="num">${p.stock}</td>
            <td><span class="badge b-ok">${p.estado}</span></td>
        </tr>
    </c:forEach>
    </tbody>
</table></div>

<jsp:include page="/includes/footer.jsp"/>
