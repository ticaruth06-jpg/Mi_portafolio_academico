<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="paginaTitulo" value="Información" scope="request"/>
<c:set var="activo" value="info" scope="request"/>
<jsp:include page="/includes/header.jsp"/>

<div class="page-title">
    <div><div class="crumbs"><a href="${ctx}/inicio">Inicio</a> / Información</div>
        <h1>Información</h1>
        <p>Todo sobre CompuTech y sobre cómo funciona esta página web.</p></div>
</div>

<div class="chips">
    <a class="chip" href="#empresa">La empresa</a><a class="chip" href="#sistema">El sistema</a>
    <a class="chip" href="#modulos">Módulos</a><a class="chip" href="#roles">Roles</a>
    <a class="chip" href="#uso">Cómo se usa</a><a class="chip" href="#reglas">Validaciones</a>
    <a class="chip" href="#tecnologia">Tecnología</a><a class="chip" href="#academico">Datos académicos</a>
</div>

<section class="card empresa" id="empresa">
    <img class="logo-big" src="${ctx}/img/logo.png" alt="Logo de CompuTech" style="width:100%;max-width:460px;height:auto;border-radius:24px">
    <div>
        <span class="tag">● Nuestra empresa</span>
        <h2>CompuTech · Tecnología que impulsa tu mundo</h2>
        <p>CompuTech es una tienda especializada en venta de computadoras, laptops, componentes, monitores y periféricos. Acompañamos a estudiantes, profesionales y gamers de Huancayo y todo el Perú con asesoría técnica, garantía y los mejores precios.</p>
        <p><b>Misión:</b> ofrecer tecnología confiable y accesible, con atención cercana y soporte especializado.<br>
           <b>Visión:</b> ser la tienda de tecnología de referencia en la región central del Perú.</p>
        <div class="valores">
            <div><b>Garantía oficial</b><span>En todos nuestros equipos</span></div>
            <div><b>Soporte técnico</b><span>Instalación y mantenimiento</span></div>
            <div><b>Envíos al Perú</b><span>Rápidos y asegurados</span></div>
        </div>
    </div>
</section>

<div class="section-h" id="sistema"><h2>¿Qué es esta página web?</h2></div>
<div class="card">
    <p style="color:#b6c1e3">Es el <b>Sistema Web de Gestión de Productos</b> de CompuTech. Permite <b>registrar, consultar, actualizar y eliminar</b> los productos de la tienda mediante una interfaz web y obtener reportes del inventario. Los productos se guardan <b>temporalmente en memoria</b> (colección <b>ArrayList</b>), por lo que no se utiliza base de datos: al reiniciar el servidor, el inventario vuelve a sus datos iniciales.</p>
    <p style="color:#b6c1e3;margin-top:.8rem">Cada producto tiene: <b>código, nombre, categoría, precio, stock, estado</b> (Disponible o Agotado), además de marca, descripción y foto.</p>
</div>

<div class="section-h" id="modulos"><h2>Módulos del sistema</h2></div>
<div class="team">
    <div class="card"><b>1. Inicio</b><p style="color:var(--mut)">Muestra el nombre del sistema, su descripción, la fecha actual, el usuario conectado, la cantidad de productos registrados, accesos rápidos y productos destacados.</p></div>
    <div class="card"><b>2. Productos</b><p style="color:var(--mut)">Registrar, listar, buscar (por código, nombre o categoría), editar y eliminar con confirmación. Los clientes ven un catálogo con fotos y el detalle de cada producto.</p></div>
    <div class="card"><b>3. Reportes</b><p style="color:var(--mut)"><b>Productos disponibles</b> (estado Disponible y stock mayor que cero) y <b>Resumen de productos</b>: total, disponibles, agotados, valor del inventario y stock total.</p></div>
    <div class="card"><b>4. Información</b><p style="color:var(--mut)">Esta pantalla: datos de la empresa y del proyecto, y la explicación del funcionamiento del sitio.</p></div>
    <div class="card"><b>5. Cuenta</b><p style="color:var(--mut)">Inicio de sesión, creación de cuenta para nuevos clientes y cierre de sesión.</p></div>
</div>

<div class="section-h" id="roles"><h2>Roles y permisos</h2></div>
<div class="tbl-wrap"><table style="min-width:0">
    <thead><tr><th>Acción</th><th>Administrador</th><th>Usuario (cliente)</th></tr></thead>
    <tbody>
        <tr><td>Ver catálogo, detalle y buscar productos</td><td>Sí</td><td>Sí</td></tr>
        <tr><td>Ver reporte de productos disponibles</td><td>Sí</td><td>Sí</td></tr>
        <tr><td>Registrar, editar y eliminar productos (con foto)</td><td>Sí</td><td>No</td></tr>
        <tr><td>Ver el resumen del inventario y su valor</td><td>Sí</td><td>No</td></tr>
        <tr><td>Cómo obtiene su cuenta</td><td>Cuenta única de la tienda</td><td>Se registra desde “Crear mi cuenta”</td></tr>
    </tbody>
</table></div>

<div class="section-h" id="uso"><h2>Cómo se usa</h2></div>
<div class="layout-2">
    <div class="card">
        <h3>Cliente</h3>
        <ol style="color:#b6c1e3;margin:.8rem 0 0 1.2rem;line-height:1.9">
            <li>Entra a “Crear mi cuenta” y completa el formulario.</li>
            <li>Explora el <b>Catálogo</b> y filtra por categoría.</li>
            <li>Usa <b>Buscar producto</b> por código, nombre o categoría.</li>
            <li>Abre <b>Ver detalle</b> para conocer precio, stock y descripción.</li>
            <li>Consulta <b>Productos disponibles</b> en Reportes.</li>
        </ol>
    </div>
    <div class="card">
        <h3>Administrador</h3>
        <ol style="color:#b6c1e3;margin:.8rem 0 0 1.2rem;line-height:1.9">
            <li>Inicia sesión con la cuenta de administración.</li>
            <li><b>Registrar producto</b>: completa el formulario y sube su foto.</li>
            <li><b>Listar productos</b>: usa Editar o Eliminar (pide confirmación).</li>
            <li>Revisa el <b>Resumen</b> para ver stock y valor del inventario.</li>
            <li>Cierra sesión al terminar.</li>
        </ol>
    </div>
</div>

<div class="section-h" id="reglas"><h2>Validaciones y seguridad</h2></div>
<div class="layout-2">
    <div class="card">
        <h3>Al registrar un producto</h3>
        <ul style="color:#b6c1e3;margin:.8rem 0 0 1.2rem;line-height:1.9">
            <li>Código obligatorio y <b>no duplicado</b>.</li>
            <li>Nombre y categoría obligatorios.</li>
            <li>Precio <b>mayor que cero</b>.</li>
            <li>Stock <b>mayor o igual a cero</b> (con stock 0 el estado pasa automáticamente a Agotado; también puedes marcar Agotado manualmente).</li>
            <li>Se valida en el navegador (JavaScript) y de nuevo en el servidor.</li>
        </ul>
    </div>
    <div class="card">
        <h3>Seguridad de las cuentas</h3>
        <ul style="color:#b6c1e3;margin:.8rem 0 0 1.2rem;line-height:1.9">
            <li>Las contraseñas se guardan <b>cifradas</b> (PBKDF2 con sal).</li>
            <li>Un filtro exige iniciar sesión para ver cualquier página.</li>
            <li>Las acciones de administración se bloquean a los clientes. El <b>almacenero</b> solo puede actualizar el stock y el estado de los productos.</li>
            <li>Todo cliente que se registra recibe siempre el rol Usuario.</li>
        </ul>
    </div>
</div>

<div class="section-h" id="tecnologia"><h2>Tecnología y arquitectura MVC</h2></div>
<div class="card">
    <div class="tech"><span>Java 17+</span><span>JSP</span><span>Servlets</span><span>JSTL</span><span>Maven</span><span>Apache Tomcat 11</span><span>CSS3</span><span>JavaScript</span><span>ArrayList en memoria</span></div>
    <div class="team" style="margin-top:1.2rem">
        <div class="card"><b>Modelo</b><p style="color:var(--mut)">Producto y Usuario, y los servicios ProductoService y UsuarioService con la lógica de negocio.</p></div>
        <div class="card"><b>Vista</b><p style="color:var(--mut)">Páginas JSP (header, menú y pie reutilizables), estilos CSS3 y validaciones en JavaScript.</p></div>
        <div class="card"><b>Controlador</b><p style="color:var(--mut)">ProductoServlet, ReporteServlet, InicioServlet, LoginServlet y RegistroServlet.</p></div>
    </div>
</div>

<div class="section-h" id="academico"><h2>Datos académicos</h2></div>
<div class="card">
    <div class="spec">
        <span>Universidad</span><b>Universidad Peruana Los Andes</b>
        <span>Facultad</span><b>Ingeniería</b>
        <span>Escuela</span><b>Ingeniería de Sistemas y Computación</b>
        <span>Curso</span><b>Desarrollo de Aplicaciones I</b>
        <span>Docente</span><b>Mg. Ing. Raúl Fernández Bejarano</b>
        <span>Actividad</span><b>N° 04 · Implementación de Arquitectura MVC</b>
        <span>Proyecto</span><b>Sistema Web de Gestión de Productos · CompuTech · v1.0.0 · 2026</b>
    </div>
</div>

<jsp:include page="/includes/footer.jsp"/>
