<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<c:set var="paginaTitulo" value="Mi carrito" scope="request"/>
<c:set var="activo" value="carrito" scope="request"/>
<jsp:include page="/includes/header.jsp"/>

<div class="page-title">
    <div><div class="crumbs"><a href="${ctx}/inicio">Inicio</a> / Carrito</div>
        <h1>Mi carrito</h1>
        <p>Revisa tus productos y envía tu pedido por WhatsApp.</p></div>
</div>

<c:if test="${not empty sessionScope.flashCarrito}">
    <div class="msg ok">${sessionScope.flashCarrito}</div>
    <c:remove var="flashCarrito" scope="session"/>
</c:if>

<c:choose>
<c:when test="${empty items}">
    <div class="msg info">Tu carrito está vacío.</div>
    <a class="btn" href="${ctx}/productos?accion=catalogo">Ir al catálogo</a>
</c:when>
<c:otherwise>
<div class="card">
<table class="tabla">
    <thead><tr><th>Código</th><th>Producto</th><th>Precio</th><th>Cant.</th><th>Subtotal</th><th></th></tr></thead>
    <tbody>
    <c:forEach var="it" items="${items}">
        <tr class="fila-carrito" data-nombre="${fn:escapeXml(it.producto.nombre)}" data-cant="${it.cantidad}" data-precio="${it.producto.precio}">
            <td>${it.producto.codigo}</td>
            <td>${it.producto.nombre}</td>
            <td>S/ <fmt:formatNumber value="${it.producto.precio}" pattern="#,##0.00"/></td>
            <td>${it.cantidad}</td>
            <td>S/ <fmt:formatNumber value="${it.subtotal}" pattern="#,##0.00"/></td>
            <td><form method="post" action="${ctx}/carrito" style="margin:0">
                <input type="hidden" name="accion" value="quitar">
                <input type="hidden" name="codigo" value="${it.producto.codigo}">
                <button class="btn sm danger" type="submit">Quitar</button></form></td>
        </tr>
    </c:forEach>
    </tbody>
</table>
<h2 style="text-align:right;margin:1rem 0">Total: S/ <fmt:formatNumber value="${total}" pattern="#,##0.00"/></h2>
<div class="form-actions">
    <a class="btn ghost" href="${ctx}/productos?accion=catalogo">← Seguir comprando</a>
    <form method="post" action="${ctx}/carrito" style="margin:0">
        <input type="hidden" name="accion" value="vaciar"><button class="btn ghost" type="submit">Vaciar carrito</button></form>
    <button class="btn wsp" type="button" onclick="pedirCarritoWsp()">Pedir por WhatsApp</button>
</div>
</div>
</c:otherwise>
</c:choose>

<jsp:include page="/includes/footer.jsp"/>
