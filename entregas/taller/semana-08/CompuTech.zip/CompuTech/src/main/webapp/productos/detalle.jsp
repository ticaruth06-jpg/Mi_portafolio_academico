<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<c:set var="paginaTitulo" value="${producto.nombre}" scope="request"/>
<c:set var="activo" value="productos" scope="request"/>
<jsp:include page="/includes/header.jsp"/>

<div class="crumbs"><a href="${ctx}/inicio">Inicio</a> / <a href="${ctx}/productos?accion=catalogo">Catálogo</a> / ${producto.codigo}</div>
<div class="detail">
    <div class="big"><img src="${ctx}/img/productos/${producto.codigo}.jpg" onerror="this.onerror=null;this.src='${ctx}/img/${producto.imagen}'" alt="${producto.nombre}"></div>
    <div>
        <span class="tag">${producto.categoria}</span>
        <h1>${producto.nombre}</h1>
        <span class="badge ${producto.estado == 'Disponible' ? 'b-ok' : (producto.estado == 'Agotado' ? 'b-bad' : 'b-bad')}">${producto.estado}</span>
        <div class="price">S/ <fmt:formatNumber value="${producto.precio}" pattern="#,##0.00"/></div>
        <p style="color:#b6c1e3">${producto.descripcion}</p>
        <div class="spec">
            <span>Código</span><b class="code">${producto.codigo}</b>
            <span>Marca</span><b>${producto.marca}</b>
            <span>Categoría</span><b>${producto.categoria}</b>
            <span>Stock</span><b>${producto.stock} unidades</b>
        </div>
        <c:if test="${sessionScope.usuario.cliente}">
            <div class="buy-box">
                <form method="post" action="${ctx}/carrito" style="margin:0">
                    <input type="hidden" name="accion" value="agregar">
                    <input type="hidden" name="codigo" value="${producto.codigo}">
                    <button class="btn cart" type="submit" ${producto.disponible ? '' : 'disabled'}><svg class="ico"><use href="#i-box"/></svg> Añadir al carrito</button>
                </form>
                <button class="btn wsp" type="button" ${producto.disponible ? '' : 'disabled'}
                        data-nombre="${fn:escapeXml(producto.nombre)}" data-codigo="${producto.codigo}" data-precio="${producto.precio}"
                        onclick="comprarWsp(this)">Comprar por WhatsApp</button>
                <c:if test="${!producto.disponible}"><small style="color:var(--mut)">Producto agotado por el momento.</small></c:if>
            </div>
        </c:if>
        <div class="form-actions">
            <a class="btn ghost" href="${ctx}/productos?accion=catalogo">← Volver al catálogo</a>
            <c:if test="${sessionScope.usuario.almacenero}">
                <a class="btn" href="${ctx}/productos?accion=stock&codigo=${producto.codigo}"><svg class="ico"><use href="#i-edit"/></svg> Actualizar stock</a>
            </c:if>
            <c:if test="${sessionScope.usuario.admin}">
                <a class="btn" href="${ctx}/productos?accion=editar&codigo=${producto.codigo}"><svg class="ico"><use href="#i-edit"/></svg> Editar</a>
            </c:if>
        </div>
    </div>
</div>

<jsp:include page="/includes/footer.jsp"/>
