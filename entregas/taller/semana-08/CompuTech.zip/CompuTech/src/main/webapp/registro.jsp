<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Crear cuenta · CompuTech</title>
    <link rel="icon" type="image/png" href="${ctx}/img/logo-icon.png">
    <link rel="stylesheet" href="${ctx}/css/estilos.css?v=5">
</head>
<body class="login">
<div class="login-wrap">
    <section class="login-art art-registro">
        <div>
            <span class="tag">● Únete a CompuTech</span>
            <h2>Crea tu cuenta y explora todo nuestro catálogo.</h2>
            <p>Regístrate gratis para ver productos, buscar por categoría y consultar la disponibilidad en tiempo real.</p>
        </div>
    </section>
    <section class="login-form">
        <form class="login-box" method="post" action="${ctx}/registro" onsubmit="return validarRegistro(this)" novalidate>
            <a class="logo" href="${ctx}/login"><img class="logo-img" src="${ctx}/img/logo-icon.png" alt="CompuTech" width="44" height="44" style="width:44px;height:44px;border-radius:12px;flex:none"><span>Compu<b>Tech</b></span></a>
            <h1>Crear cuenta</h1>
            <p>Completa tus datos para registrarte como cliente.</p>

            <c:if test="${not empty errores}">
                <div class="msg err"><strong>No se pudo crear la cuenta:</strong>
                    <ul><c:forEach var="e" items="${errores}"><li>${e}</li></c:forEach></ul></div>
            </c:if>
            <div class="msg err" id="erroresJs" style="display:none"></div>

            <div class="field"><label for="nombre">NOMBRE COMPLETO</label>
                <input type="text" id="nombre" name="nombre" value="${nombre}" placeholder="Ej.: María Quispe Rojas"></div>
            <div class="field"><label for="login">USUARIO</label>
                <input type="text" id="login" name="login" value="${login}" placeholder="maria.quispe"></div>
            <div class="field"><label for="correo">CORREO ELECTRÓNICO</label>
                <input type="text" id="correo" name="correo" value="${correo}" placeholder="maria@correo.com"></div>
            <div class="field"><label for="clave">CONTRASEÑA</label>
                <div class="pwd"><input type="password" id="clave" name="clave" placeholder="Mínimo 6 caracteres"><button type="button" class="eye" onclick="verClave('clave',this)">Ver</button></div></div>
            <div class="field"><label for="clave2">CONFIRMAR CONTRASEÑA</label>
                <div class="pwd"><input type="password" id="clave2" name="clave2" placeholder="Repite tu contraseña"><button type="button" class="eye" onclick="verClave('clave2',this)">Ver</button></div></div>
            <button class="btn" type="submit">Crear cuenta y entrar</button>
            <p style="text-align:center;margin-top:1.2rem;color:var(--mut)">¿Ya tienes cuenta? <a href="${ctx}/login"><b>Iniciar sesión</b></a></p>
        </form>
    </section>
</div>
<script src="${ctx}/js/validaciones.js?v=5"></script>
</body>
</html>
