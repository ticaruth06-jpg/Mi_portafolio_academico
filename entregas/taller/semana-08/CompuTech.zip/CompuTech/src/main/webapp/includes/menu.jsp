<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="esAdmin" value="${sessionScope.usuario.admin}"/>
<c:set var="esAlmacen" value="${sessionScope.usuario.almacenero}"/>
<c:set var="esCliente" value="${sessionScope.usuario.cliente}"/>
<ul class="menu" id="menuPrincipal">
    <li><a class="nav ${activo == 'inicio' ? 'act' : ''}" href="${ctx}/inicio">Inicio</a></li>

    <li>
        <span class="nav ${activo == 'productos' ? 'act' : ''}">Productos ▾</span>
        <div class="sub">
            <c:if test="${esAdmin}">
                <a href="${ctx}/productos?accion=nuevo">Registrar producto</a>
                <a href="${ctx}/productos?accion=listar">Listar productos</a>
                <a href="${ctx}/productos?accion=buscar">Buscar producto</a>
                <a href="${ctx}/productos?accion=listar&modo=editar">Editar producto</a>
                <a href="${ctx}/productos?accion=listar&modo=eliminar">Eliminar producto</a>
            </c:if>
            <c:if test="${esAlmacen}">
                <a href="${ctx}/productos?accion=listar">Listar productos</a>
                <a href="${ctx}/productos?accion=buscar">Buscar producto</a>
                <a href="${ctx}/productos?accion=listar&modo=stock">Actualizar stock</a>
            </c:if>
            <c:if test="${esCliente}">
                <a href="${ctx}/productos?accion=catalogo">Catálogo de productos</a>
                <a href="${ctx}/productos?accion=buscar">Buscar producto</a>
            </c:if>
        </div>
    </li>

    <li>
        <span class="nav ${activo == 'reportes' ? 'act' : ''}">Reportes ▾</span>
        <div class="sub">
            <a href="${ctx}/reportes?tipo=disponibles">Productos disponibles</a>
            <c:if test="${esAdmin || esAlmacen}">
                <a href="${ctx}/reportes?tipo=resumen">Resumen de productos</a>
            </c:if>
        </div>
    </li>

    <c:if test="${esCliente}">
        <li><a class="nav ${activo == 'carrito' ? 'act' : ''}" href="${ctx}/carrito">Carrito (${empty sessionScope.carrito ? 0 : sessionScope.carrito.size()})</a></li>
    </c:if>
    <li><a class="nav ${activo == 'info' ? 'act' : ''}" href="${ctx}/informacion.jsp">Información</a></li>
    <li><a class="btn-out" href="${ctx}/logout">Cerrar sesión</a></li>
</ul>
