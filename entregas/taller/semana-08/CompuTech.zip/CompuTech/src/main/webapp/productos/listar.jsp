<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="paginaTitulo" value="Listar productos" scope="request"/>
<c:set var="activo" value="productos" scope="request"/>
<jsp:include page="/includes/header.jsp"/>

<div class="page-title">
    <div><div class="crumbs"><a href="${ctx}/inicio">Inicio</a> / Productos / Listar</div>
        <h1>Listado de productos</h1>
        <p>${productos.size()} productos registrados.</p></div>
    <c:if test="${sessionScope.usuario.admin}">
        <a class="btn" href="${ctx}/productos?accion=nuevo"><svg class="ico"><use href="#i-plus"/></svg> Registrar producto</a>
    </c:if>
</div>

<c:if test="${not empty sessionScope.flash}">
    <div class="msg ok">${sessionScope.flash}</div>
    <c:remove var="flash" scope="session"/>
</c:if>
<c:if test="${modo == 'editar'}"><div class="msg info">Seleccione el producto que desea <b>editar</b> con el botón <b>Editar</b>.</div></c:if>
<c:if test="${modo == 'stock'}"><div class="msg info">Seleccione el producto y pulse <b>Actualizar stock</b> para cambiar su stock o estado.</div></c:if>
<c:if test="${modo == 'eliminar'}"><div class="msg info">Seleccione el producto que desea <b>eliminar</b>. Se le pedirá confirmación.</div></c:if>

<div class="tbl-wrap">
<table>
    <thead><tr>
        <th>Código</th><th>Producto</th><th>Categoría</th><th class="num">Precio (S/)</th>
        <th class="num">Stock</th><th>Estado</th><th class="num">Acciones</th>
    </tr></thead>
    <tbody>
    <c:forEach var="p" items="${productos}">
        <tr>
            <td class="code">${p.codigo}</td>
            <td><div class="thumb"><img src="${ctx}/img/productos/${p.codigo}.jpg" onerror="this.onerror=null;this.src='${ctx}/img/${p.imagen}'" alt=""><div><b>${p.nombre}</b><small>${p.marca}</small></div></div></td>
            <td>${p.categoria}</td>
            <td class="num"><fmt:formatNumber value="${p.precio}" pattern="#,##0.00"/></td>
            <td class="num">${p.stock}</td>
            <td><span class="badge ${p.estado == 'Disponible' ? 'b-ok' : (p.estado == 'Agotado' ? 'b-bad' : 'b-bad')}">${p.estado}</span></td>
            <td><div class="acts-cell">
                <c:choose>
                    <c:when test="${sessionScope.usuario.admin}">
                        <a class="btn sm ghost" href="${ctx}/productos?accion=editar&codigo=${p.codigo}"><svg class="ico"><use href="#i-edit"/></svg> Editar</a>
                        <button class="btn sm danger" type="button"
                                onclick="return confirmarEliminar('${p.codigo}', '${p.nombre}')"><svg class="ico"><use href="#i-trash"/></svg> Eliminar</button>
                    </c:when>
                    <c:when test="${sessionScope.usuario.almacenero}">
                        <a class="btn sm" href="${ctx}/productos?accion=stock&codigo=${p.codigo}"><svg class="ico"><use href="#i-edit"/></svg> Actualizar stock</a>
                    </c:when>
                    <c:otherwise><a class="btn sm ghost" href="${ctx}/productos?accion=detalle&codigo=${p.codigo}">Ver</a></c:otherwise>
                </c:choose>
            </div></td>
        </tr>
    </c:forEach>
    </tbody>
</table>
</div>

<%-- Modal de confirmación para eliminar --%>
<div class="modal-bg" id="modalEliminar">
    <form class="modal" method="post" action="${ctx}/productos">
        <div class="warn"><svg><use href="#i-warn"/></svg></div>
        <h3>¿Eliminar este producto?</h3>
        <p><b id="modalNombre"></b><br>Esta acción no se puede deshacer.</p>
        <input type="hidden" name="accion" value="eliminar">
        <input type="hidden" name="codigo" id="modalCodigo">
        <div class="row">
            <button type="button" class="btn ghost" onclick="cerrarModal()">Cancelar</button>
            <button type="submit" class="btn danger">Sí, eliminar</button>
        </div>
    </form>
</div>

<jsp:include page="/includes/footer.jsp"/>
