<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="paginaTitulo" value="Buscar producto" scope="request"/>
<c:set var="activo" value="productos" scope="request"/>
<jsp:include page="/includes/header.jsp"/>

<div class="page-title">
    <div><div class="crumbs"><a href="${ctx}/inicio">Inicio</a> / Productos / Buscar</div>
        <h1>Buscar producto</h1>
        <p>Encuentra productos por código, nombre o categoría.</p></div>
</div>

<form class="card" method="get" action="${ctx}/productos">
    <input type="hidden" name="accion" value="buscar">
    <div class="searchbar">
        <select name="criterio">
            <option value="todos"     ${criterio == 'todos' ? 'selected' : ''}>Todos los campos</option>
            <option value="codigo"    ${criterio == 'codigo' ? 'selected' : ''}>Código</option>
            <option value="nombre"    ${criterio == 'nombre' ? 'selected' : ''}>Nombre</option>
            <option value="categoria" ${criterio == 'categoria' ? 'selected' : ''}>Categoría</option>
        </select>
        <input type="text" name="texto" value="${texto}" placeholder="Ej.: laptop, P004, Monitores…">
        <button class="btn" type="submit"><svg class="ico"><use href="#i-search"/></svg> Buscar</button>
    </div>
</form>

<c:if test="${resultados != null}">
    <div class="section-h"><h2>Resultados (${resultados.size()})</h2></div>
    <c:if test="${empty resultados}"><div class="msg info">No se encontraron productos para “${texto}”.</div></c:if>
    <c:if test="${not empty resultados}">
    <div class="tbl-wrap"><table>
        <thead><tr><th>Código</th><th>Producto</th><th>Categoría</th><th class="num">Precio (S/)</th><th class="num">Stock</th><th>Estado</th><th class="num">Acciones</th></tr></thead>
        <tbody>
        <c:forEach var="p" items="${resultados}">
            <tr>
                <td class="code">${p.codigo}</td>
                <td><div class="thumb"><img src="${ctx}/img/productos/${p.codigo}.jpg" onerror="this.onerror=null;this.src='${ctx}/img/${p.imagen}'" alt=""><div><b>${p.nombre}</b><small>${p.marca}</small></div></div></td>
                <td>${p.categoria}</td>
                <td class="num"><fmt:formatNumber value="${p.precio}" pattern="#,##0.00"/></td>
                <td class="num">${p.stock}</td>
                <td><span class="badge ${p.estado == 'Disponible' ? 'b-ok' : (p.estado == 'Agotado' ? 'b-bad' : 'b-bad')}">${p.estado}</span></td>
                <td><div class="acts-cell">
                    <a class="btn sm ghost" href="${ctx}/productos?accion=detalle&codigo=${p.codigo}">Ver</a>
                    <c:if test="${sessionScope.usuario.admin}">
                        <a class="btn sm ghost" href="${ctx}/productos?accion=editar&codigo=${p.codigo}">Editar</a>
                    </c:if>
                    <c:if test="${sessionScope.usuario.almacenero}">
                        <a class="btn sm ghost" href="${ctx}/productos?accion=stock&codigo=${p.codigo}">Stock</a>
                    </c:if>
                </div></td>
            </tr>
        </c:forEach>
        </tbody>
    </table></div>
    </c:if>
</c:if>

<jsp:include page="/includes/footer.jsp"/>
