<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="paginaTitulo" value="Actualizar stock" scope="request"/>
<c:set var="activo" value="productos" scope="request"/>
<jsp:include page="/includes/header.jsp"/>

<div class="page-title">
    <div><div class="crumbs"><a href="${ctx}/inicio">Inicio</a> / Productos / Actualizar stock</div>
        <h1>Actualizar stock</h1>
        <p>Como almacenero solo puedes cambiar el <b>stock</b> y el <b>estado</b> del producto.</p></div>
</div>

<c:if test="${not empty errores}">
    <div class="msg err"><strong>No se pudo guardar:</strong>
        <ul><c:forEach var="e" items="${errores}"><li>${e}</li></c:forEach></ul></div>
</c:if>

<div class="layout-2">
<form class="card" method="post" action="${ctx}/productos">
    <input type="hidden" name="accion" value="actualizarStock">
    <input type="hidden" name="codigo" value="${producto.codigo}">
    <div class="form-grid">
        <div><label>CÓDIGO</label><input type="text" value="${producto.codigo}" readonly></div>
        <div><label>PRODUCTO</label><input type="text" value="${producto.nombre}" readonly></div>
        <div><label for="stock">STOCK <span class="req">*</span></label>
            <input type="number" id="stock" name="stock" step="1" min="0" value="${producto.stock}"></div>
        <div><label for="estado">ESTADO</label>
            <select id="estado" name="estado">
                <c:forEach var="e" items="${estados}"><option value="${e}" ${producto.estado == e ? 'selected' : ''}>${e}</option></c:forEach>
            </select></div>
    </div>
    <div class="form-actions">
        <button class="btn" type="submit"><svg class="ico"><use href="#i-check"/></svg> Guardar stock</button>
        <a class="btn ghost" href="${ctx}/productos?accion=listar&modo=stock">Cancelar</a>
    </div>
</form>
<aside class="card preview">
    <img src="${ctx}/img/productos/${producto.codigo}.jpg" alt="Vista previa"
         onerror="this.onerror=null;this.src='${ctx}/img/${empty producto.imagen ? 'productos/sin-foto.jpg' : producto.imagen}'">
    <h3>${producto.nombre}</h3>
    <p style="color:var(--mut);margin-top:.3rem">Con stock 0 el estado pasa automáticamente a Agotado.</p>
</aside>
</div>

<jsp:include page="/includes/footer.jsp"/>
