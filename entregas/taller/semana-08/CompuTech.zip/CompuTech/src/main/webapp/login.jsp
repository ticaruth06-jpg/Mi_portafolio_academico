<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Iniciar sesión · CompuTech</title>
    <link rel="icon" type="image/png" href="${ctx}/img/logo-icon.png">
    <link rel="stylesheet" href="${ctx}/css/estilos.css?v=5">
</head>
<body class="login">
<div class="login-wrap">
    <section class="login-art">
        <div>
            <span class="tag">● Tecnología al mejor precio</span>
            <h2>Equípate con lo último en computación.</h2>
            <p>Laptops, PCs gamer, monitores, componentes y periféricos con garantía oficial y envíos a todo el Perú.</p>
        </div>
    </section>
    <section class="login-form">
        <form class="login-box" method="post" action="${ctx}/login">
            <a class="logo" href="#"><img class="logo-img" src="${ctx}/img/logo-icon.png" alt="CompuTech" width="44" height="44" style="width:44px;height:44px;border-radius:12px;flex:none"><span>Compu<b>Tech</b></span></a>
            <h1>Bienvenido</h1>
            <p>Ingresa a tu cuenta para continuar.</p>

            <c:if test="${not empty error}"><div class="msg err">${error}</div></c:if>
            <c:if test="${param.salio == '1'}"><div class="msg ok">Sesión cerrada correctamente.</div></c:if>

            <div class="field"><label for="login">USUARIO</label>
                <input type="text" id="login" name="login" placeholder="Tu usuario" required autofocus></div>
            <div class="field"><label for="clave">CONTRASEÑA</label>
                <div class="pwd"><input type="password" id="clave" name="clave" placeholder="••••••••" required><button type="button" class="eye" onclick="verClave('clave',this)">Ver</button></div></div>
            <button class="btn" type="submit">Ingresar al sistema</button>

            <p style="text-align:center;margin-top:1.4rem;color:var(--mut)">¿Eres cliente y aún no tienes cuenta?
                <a href="${ctx}/registro"><b>Crear mi cuenta</b></a></p>
        </form>
    </section>
</div>
<script src="${ctx}/js/validaciones.js?v=5"></script>
</body>
</html>
