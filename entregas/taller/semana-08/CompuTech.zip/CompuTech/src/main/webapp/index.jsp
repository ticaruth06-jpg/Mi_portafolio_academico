<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%-- Si se entra directo a index.jsp, el controlador InicioServlet prepara los datos --%>
<c:if test="${empty totalProductos}"><jsp:forward page="/inicio"/></c:if>
<c:set var="paginaTitulo" value="Inicio" scope="request"/>
<c:set var="activo" value="inicio" scope="request"/>
<jsp:include page="/includes/header.jsp"/>

<section class="hero">
    <div class="hero-in">
        <span class="tag">● CompuTech · Sistema de Gestión de Productos</span>
        <h1>Potencia tu mundo con <span>tecnología real</span></h1>
        <p>Plataforma web para registrar, consultar, actualizar y controlar el inventario de nuestra tienda de computadoras y accesorios.</p>
        <div class="acts">
            <c:choose>
                <c:when test="${sessionScope.usuario.admin}">
                    <a class="btn" href="${ctx}/productos?accion=nuevo"><svg class="ico"><use href="#i-plus"/></svg> Registrar producto</a>
                    <a class="btn ghost" href="${ctx}/productos?accion=listar">Ver inventario</a>
                </c:when>
                <c:when test="${sessionScope.usuario.almacenero}">
                    <a class="btn" href="${ctx}/productos?accion=listar&modo=stock"><svg class="ico"><use href="#i-edit"/></svg> Actualizar stock</a>
                    <a class="btn ghost" href="${ctx}/productos?accion=listar">Ver inventario</a>
                </c:when>
                <c:otherwise>
                    <a class="btn" href="${ctx}/productos?accion=catalogo"><svg class="ico"><use href="#i-box"/></svg> Ver catálogo</a>
                    <a class="btn ghost" href="${ctx}/reportes?tipo=disponibles">Productos disponibles</a>
                </c:otherwise>
            </c:choose>
        </div>
    </div>
</section>

<section class="stats">
    <div class="card stat"><div class="ic"><svg><use href="#i-box"/></svg></div>
        <div><small>Productos registrados</small><strong>${totalProductos}</strong></div></div>
    <div class="card stat"><div class="ic"><svg><use href="#i-cpu"/></svg></div>
        <div><small>Sistema</small><strong style="font-size:1.1rem">CompuTech</strong></div></div>
    <div class="card stat"><div class="ic"><svg><use href="#i-info"/></svg></div>
        <div><small>Fecha actual</small><strong style="font-size:1.05rem">${fechaActual}</strong></div></div>
    <div class="card stat"><div class="ic"><svg><use href="#i-check"/></svg></div>
        <div><small>Usuario conectado</small><strong style="font-size:1.1rem">${sessionScope.usuario.nombre}</strong></div></div>
</section>

<div class="section-h"><h2>Accesos rápidos</h2></div>
<div class="quick">
    <c:if test="${sessionScope.usuario.admin}">
        <a href="${ctx}/productos?accion=nuevo"><div class="qi"><svg><use href="#i-plus"/></svg></div><b>Registrar producto</b><span>Agrega un nuevo equipo al inventario</span></a>
        <a href="${ctx}/productos?accion=listar"><div class="qi"><svg><use href="#i-list"/></svg></div><b>Listar productos</b><span>Edita o elimina registros</span></a>
        <a href="${ctx}/reportes?tipo=resumen"><div class="qi"><svg><use href="#i-chart"/></svg></div><b>Resumen de productos</b><span>Stock total y valor del inventario</span></a>
    </c:if>
    <c:if test="${sessionScope.usuario.almacenero}">
        <a href="${ctx}/productos?accion=listar&modo=stock"><div class="qi"><svg><use href="#i-edit"/></svg></div><b>Actualizar stock</b><span>Cambia el stock y el estado</span></a>
        <a href="${ctx}/reportes?tipo=resumen"><div class="qi"><svg><use href="#i-chart"/></svg></div><b>Resumen de productos</b><span>Stock total y valor del inventario</span></a>
    </c:if>
    <c:if test="${sessionScope.usuario.cliente}">
        <a href="${ctx}/productos?accion=catalogo"><div class="qi"><svg><use href="#i-box"/></svg></div><b>Catálogo</b><span>Explora todos los productos</span></a>
    </c:if>
    <c:if test="${false}">
        <a href="${ctx}/productos?accion=catalogo"><div class="qi"><svg><use href="#i-box"/></svg></div><b>Catálogo</b><span>Explora todos los productos</span></a>
    </c:if>
    <a href="${ctx}/productos?accion=buscar"><div class="qi"><svg><use href="#i-search"/></svg></div><b>Buscar producto</b><span>Por código, nombre o categoría</span></a>
    <a href="${ctx}/reportes?tipo=disponibles"><div class="qi"><svg><use href="#i-check"/></svg></div><b>Productos disponibles</b><span>Solo los que tienen stock</span></a>
</div>

<div class="section-h"><h2>Productos destacados</h2>
    <a href="${ctx}/productos?accion=catalogo">Ver todo →</a></div>
<div class="grid">
    <c:forEach var="p" items="${destacados}">
        <article class="pcard">
            <div class="ribbon"><span class="badge ${p.estado == 'Disponible' ? 'b-ok' : (p.estado == 'Agotado' ? 'b-bad' : 'b-warn')}">${p.estado}</span></div>
            <div class="pic"><img src="${ctx}/img/productos/${p.codigo}.jpg" onerror="this.onerror=null;this.src='${ctx}/img/${p.imagen}'" alt="${p.nombre}"></div>
            <div class="info">
                <span class="cat">${p.categoria}</span>
                <h3>${p.nombre}</h3><span class="brand">${p.marca}</span>
                <div class="price"><small>S/</small> <fmt:formatNumber value="${p.precio}" pattern="#,##0.00"/></div>
                <div class="foot"><span class="brand">Stock: ${p.stock}</span>
                    <a class="btn sm ghost" href="${ctx}/productos?accion=detalle&codigo=${p.codigo}">Ver detalle</a></div>
            </div>
        </article>
    </c:forEach>
</div>

<jsp:include page="/includes/footer.jsp"/>
