/* validaciones.js · validación en el navegador (la validación definitiva está en ProductoService) */
(function () {
  'use strict';

  function marcar(campo, malo) {
    campo.classList.toggle('err-input', malo);
  }

  /** Valida el formulario de registrar / editar producto. */
  window.validarProducto = function (form) {
    var errores = [];
    var codigo = form.codigo, nombre = form.nombre, categoria = form.categoria,
        precio = form.precio, stock = form.stock;

    marcar(codigo, !codigo.value.trim());
    if (!codigo.value.trim()) errores.push('El código es obligatorio.');

    marcar(nombre, !nombre.value.trim());
    if (!nombre.value.trim()) errores.push('El nombre es obligatorio.');

    marcar(categoria, !categoria.value);
    if (!categoria.value) errores.push('La categoría es obligatoria.');

    var p = parseFloat(precio.value);
    marcar(precio, isNaN(p) || p <= 0);
    if (isNaN(p) || p <= 0) errores.push('El precio debe ser mayor que cero.');

    var s = parseInt(stock.value, 10);
    marcar(stock, isNaN(s) || s < 0);
    if (isNaN(s) || s < 0) errores.push('El stock debe ser mayor o igual a cero.');

    var caja = document.getElementById('erroresJs');
    if (caja) {
      if (errores.length) {
        caja.innerHTML = '<strong>Corrija los siguientes campos:</strong><ul><li>' +
                         errores.join('</li><li>') + '</li></ul>';
        caja.style.display = 'block';
        caja.scrollIntoView({behavior: 'smooth', block: 'center'});
      } else {
        caja.style.display = 'none';
      }
    }
    return errores.length === 0;
  };

  /** Pide confirmación antes de eliminar (modal). */
  window.confirmarEliminar = function (codigo, nombre) {
    document.getElementById('modalNombre').textContent = codigo + ' · ' + nombre;
    document.getElementById('modalCodigo').value = codigo;
    document.getElementById('modalEliminar').classList.add('show');
    return false;
  };
  window.cerrarModal = function () {
    document.getElementById('modalEliminar').classList.remove('show');
  };

  /** (La vista previa ahora muestra la foto subida; ya no depende de la categoría.) */
  window.actualizarVista = function () {};

  /** Valida el formulario de creación de cuenta. */
  window.validarRegistro = function (form) {
    var errores = [];
    function chk(campo, malo, msg) { marcar(campo, malo); if (malo) errores.push(msg); }
    chk(form.nombre, form.nombre.value.trim().length < 3, 'Ingrese su nombre completo (mínimo 3 caracteres).');
    chk(form.login, !/^[A-Za-z0-9_.]{4,20}$/.test(form.login.value.trim()), 'El usuario debe tener de 4 a 20 caracteres (letras, números, punto o guion bajo).');
    chk(form.correo, !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.correo.value.trim()), 'Ingrese un correo electrónico válido.');
    chk(form.clave, form.clave.value.length < 6, 'La contraseña debe tener al menos 6 caracteres.');
    chk(form.clave2, form.clave.value !== form.clave2.value, 'Las contraseñas no coinciden.');
    var caja = document.getElementById('erroresJs');
    if (caja) {
      if (errores.length) {
        caja.innerHTML = '<strong>Corrija los siguientes campos:</strong><ul><li>' + errores.join('</li><li>') + '</li></ul>';
        caja.style.display = 'block';
      } else { caja.style.display = 'none'; }
    }
    return errores.length === 0;
  };
  /** Muestra u oculta la contraseña. */
  window.verClave = function (id, boton) {
    var c = document.getElementById(id);
    var ver = c.type === 'password';
    c.type = ver ? 'text' : 'password';
    boton.textContent = ver ? 'Ocultar' : 'Ver';
  };

  function numeroWsp() {
    var m = document.querySelector('meta[name="wsp"]');
    return m ? m.content : '';
  }
  function abrirWsp(texto) {
    window.open('https://wa.me/' + numeroWsp() + '?text=' + encodeURIComponent(texto), '_blank');
  }
  /** Comprar un producto por WhatsApp (botón con data-nombre, data-codigo, data-precio). */
  window.comprarWsp = function (btn) {
    var precio = parseFloat(btn.dataset.precio).toFixed(2);
    abrirWsp('Hola CompuTech, quiero comprar: ' + btn.dataset.nombre + ' (código ' + btn.dataset.codigo +
             ') - S/ ' + precio + '. ¿Está disponible?');
  };
  /** Enviar todo el carrito por WhatsApp. */
  window.pedirCarritoWsp = function () {
    var filas = document.querySelectorAll('.fila-carrito'), total = 0, txt = 'Hola CompuTech, quiero hacer este pedido:\n';
    filas.forEach(function (f) {
      var c = parseInt(f.dataset.cant, 10), p = parseFloat(f.dataset.precio);
      total += c * p;
      txt += '- ' + c + ' x ' + f.dataset.nombre + ' (S/ ' + (c * p).toFixed(2) + ')\n';
    });
    txt += 'Total: S/ ' + total.toFixed(2);
    abrirWsp(txt);
  };

  /** Vista previa de la foto elegida antes de guardar. */
  window.vistaArchivo = function (input) {
    var img = document.getElementById('vistaImg');
    if (!input.files || !input.files[0] || !img) return;
    var f = input.files[0];
    if (f.size > 5 * 1024 * 1024) { alert('La foto supera los 5 MB.'); input.value = ''; return; }
    var lector = new FileReader();
    lector.onload = function (e) { img.src = e.target.result; };
    lector.readAsDataURL(f);
  };
})();
