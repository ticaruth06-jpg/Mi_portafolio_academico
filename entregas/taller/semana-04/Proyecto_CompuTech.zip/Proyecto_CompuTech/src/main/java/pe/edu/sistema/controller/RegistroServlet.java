package pe.edu.sistema.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;
import pe.edu.sistema.model.Usuario;
import pe.edu.sistema.service.UsuarioService;

/** Controlador del registro de nuevos clientes (siempre rol USUARIO). */
@WebServlet("/registro")
public class RegistroServlet extends HttpServlet {

    private final UsuarioService usuarioService = UsuarioService.getInstance();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/registro.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String nombre = request.getParameter("nombre");
        String login = request.getParameter("login");
        String correo = request.getParameter("correo");
        String clave = request.getParameter("clave");
        String clave2 = request.getParameter("clave2");

        List<String> errores = usuarioService.validarRegistro(nombre, login, correo, clave, clave2);
        if (!errores.isEmpty()) {
            request.setAttribute("errores", errores);
            request.setAttribute("nombre", nombre);
            request.setAttribute("login", login);
            request.setAttribute("correo", correo);
            request.getRequestDispatcher("/registro.jsp").forward(request, response);
            return;
        }

        Usuario u = usuarioService.registrar(nombre, login, correo, clave);
        request.getSession(true).setAttribute("usuario", u);   // entra directamente
        response.sendRedirect(request.getContextPath() + "/inicio");
    }
}
