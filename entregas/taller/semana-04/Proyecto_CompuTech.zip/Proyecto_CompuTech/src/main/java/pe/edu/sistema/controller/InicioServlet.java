package pe.edu.sistema.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import pe.edu.sistema.model.Producto;
import pe.edu.sistema.service.ProductoService;

/** Controlador de la página de inicio. */
@WebServlet("/inicio")
public class InicioServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ProductoService servicio = ProductoService.getInstance();
        String fecha = LocalDate.now().format(
                DateTimeFormatter.ofPattern("EEEE d 'de' MMMM 'de' yyyy", new Locale("es", "PE")));

        fecha = Character.toUpperCase(fecha.charAt(0)) + fecha.substring(1);

        List<Producto> todos = servicio.listar();
        request.setAttribute("fechaActual", fecha);
        request.setAttribute("totalProductos", servicio.totalProductos());
        request.setAttribute("destacados", todos.subList(0, Math.min(4, todos.size())));
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }
}
