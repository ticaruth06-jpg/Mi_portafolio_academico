package pe.edu.sistema.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import pe.edu.sistema.service.ProductoService;

/** Controlador del módulo de reportes. ?tipo=disponibles | resumen */
@WebServlet("/reportes")
public class ReporteServlet extends HttpServlet {

    private final ProductoService servicio = ProductoService.getInstance();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String tipo = request.getParameter("tipo");
        if ("resumen".equals(tipo)) {
            request.setAttribute("total", servicio.totalProductos());
            request.setAttribute("disponibles", servicio.totalDisponibles());
            request.setAttribute("agotados", servicio.totalAgotados());
            request.setAttribute("valorInventario", servicio.valorTotalInventario());
            request.setAttribute("stockTotal", servicio.stockTotal());
            request.setAttribute("productos", servicio.listar());
            request.getRequestDispatcher("/reportes/resumen.jsp").forward(request, response);
        } else {
            request.setAttribute("productos", servicio.disponibles());
            request.getRequestDispatcher("/reportes/disponibles.jsp").forward(request, response);
        }
    }
}
