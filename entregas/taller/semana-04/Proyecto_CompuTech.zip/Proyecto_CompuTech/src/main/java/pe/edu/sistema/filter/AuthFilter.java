package pe.edu.sistema.filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;

/** Filtro: obliga a iniciar sesión para acceder a cualquier página del sistema. */
@WebFilter("/*")
public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        String ruta = request.getRequestURI().substring(request.getContextPath().length());
        boolean publico = ruta.equals("/login") || ruta.equals("/login.jsp")
                || ruta.equals("/registro") || ruta.equals("/registro.jsp")
                || ruta.startsWith("/css/") || ruta.startsWith("/js/") || ruta.startsWith("/img/");

        HttpSession sesion = request.getSession(false);
        boolean autenticado = sesion != null && sesion.getAttribute("usuario") != null;

        if (publico || autenticado) {
            chain.doFilter(req, res);
        } else {
            response.sendRedirect(request.getContextPath() + "/login");
        }
    }
}
