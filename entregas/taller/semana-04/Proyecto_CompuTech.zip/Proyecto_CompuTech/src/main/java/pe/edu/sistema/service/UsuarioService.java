package pe.edu.sistema.service;

import java.util.ArrayList;
import java.util.List;
import pe.edu.sistema.model.Usuario;

/**
 * Servicio de cuentas (en memoria, sin base de datos).
 * Solo existe UN administrador (admin); cualquier persona que se registre
 * recibe siempre el rol USUARIO.
 */
public class UsuarioService {

    private static final UsuarioService INSTANCIA = new UsuarioService();

    private final List<Usuario> usuarios = new ArrayList<>();

    private UsuarioService() {
        usuarios.add(new Usuario("admin", "admin123", "Administrador CompuTech",
                "admin@computech.pe", Usuario.ADMIN));
    }

    public static UsuarioService getInstance() { return INSTANCIA; }

    /** Devuelve el usuario si las credenciales son correctas; si no, null. */
    public synchronized Usuario autenticar(String login, String clave) {
        if (login == null || clave == null) return null;
        Usuario u = buscar(login);
        return (u != null && u.getClave().equals(clave)) ? u : null;
    }

    public synchronized Usuario buscar(String login) {
        if (login == null) return null;
        for (Usuario u : usuarios) {
            if (u.getLogin().equalsIgnoreCase(login.trim())) return u;
        }
        return null;
    }

    /** Valida los datos de un registro. Devuelve la lista de errores (vacía si es válido). */
    public List<String> validarRegistro(String nombre, String login, String correo,
                                        String clave, String clave2) {
        List<String> errores = new ArrayList<>();
        if (nombre == null || nombre.trim().length() < 3) {
            errores.add("Ingrese su nombre completo (mínimo 3 caracteres).");
        }
        if (login == null || !login.trim().matches("[A-Za-z0-9_.]{4,20}")) {
            errores.add("El usuario debe tener de 4 a 20 caracteres (letras, números, punto o guion bajo).");
        } else if (buscar(login) != null) {
            errores.add("El usuario \"" + login.trim() + "\" ya está en uso. Elija otro.");
        }
        if (correo == null || !correo.trim().matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {
            errores.add("Ingrese un correo electrónico válido.");
        }
        if (clave == null || clave.length() < 6) {
            errores.add("La contraseña debe tener al menos 6 caracteres.");
        } else if (!clave.equals(clave2)) {
            errores.add("Las contraseñas no coinciden.");
        }
        return errores;
    }

    /** Crea una cuenta nueva. SIEMPRE con rol USUARIO (nunca administrador). */
    public synchronized Usuario registrar(String nombre, String login, String correo, String clave) {
        Usuario u = new Usuario(login.trim(), clave, nombre.trim(), correo.trim(), Usuario.USUARIO);
        usuarios.add(u);
        return u;
    }
}
