package pe.edu.sistema.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import pe.edu.sistema.model.Usuario;
import pe.edu.sistema.service.UsuarioService;

/** Controlador de inicio y cierre de sesión. */
@WebServlet(urlPatterns = {"/login", "/logout"})
public class LoginServlet extends HttpServlet {

    private final UsuarioService usuarioService = UsuarioService.getInstance();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (request.getServletPath().equals("/logout")) {
            HttpSession sesion = request.getSession(false);
            if (sesion != null) sesion.invalidate();
            response.sendRedirect(request.getContextPath() + "/login?salio=1");
            return;
        }
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        Usuario u = usuarioService.autenticar(request.getParameter("login"),
                                              request.getParameter("clave"));
        if (u == null) {
            request.setAttribute("error", "Usuario o contraseña incorrectos.");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
            return;
        }
        HttpSession sesion = request.getSession(true);
        sesion.setAttribute("usuario", u);
        response.sendRedirect(request.getContextPath() + "/inicio");
    }
}
