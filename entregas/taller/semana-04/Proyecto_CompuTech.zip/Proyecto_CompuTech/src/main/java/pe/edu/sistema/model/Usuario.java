package pe.edu.sistema.model;

/** Modelo: usuario del sistema con rol ADMIN o USUARIO. */
public class Usuario {

    public static final String ADMIN = "ADMIN";
    public static final String USUARIO = "USUARIO";

    private final String login;
    private final String clave;
    private final String nombre;
    private final String correo;
    private final String rol;

    public Usuario(String login, String clave, String nombre, String correo, String rol) {
        this.login = login;
        this.clave = clave;
        this.nombre = nombre;
        this.correo = correo;
        this.rol = rol;
    }

    public String getLogin() { return login; }
    public String getClave() { return clave; }
    public String getNombre() { return nombre; }
    public String getCorreo() { return correo; }
    public String getRol() { return rol; }
    public boolean isAdmin() { return ADMIN.equals(rol); }
}
