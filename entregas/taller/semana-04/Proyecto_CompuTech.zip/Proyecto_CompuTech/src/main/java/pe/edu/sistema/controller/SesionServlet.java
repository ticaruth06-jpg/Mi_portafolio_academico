package pe.edu.sistema.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Controlador de las opciones "Información" y "Cerrar sesión" del menú.
 */
@WebServlet(name = "SesionServlet", urlPatterns = {"/informacion", "/cerrar"})
public class SesionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if ("/cerrar".equals(req.getServletPath())) {
            HttpSession s = req.getSession(false);
            if (s != null) {
                s.invalidate();
            }
            req.getRequestDispatcher("/WEB-INF/views/cerrado.jsp").forward(req, resp);
        } else {
            req.getRequestDispatcher("/WEB-INF/views/informacion.jsp").forward(req, resp);
        }
    }
}
