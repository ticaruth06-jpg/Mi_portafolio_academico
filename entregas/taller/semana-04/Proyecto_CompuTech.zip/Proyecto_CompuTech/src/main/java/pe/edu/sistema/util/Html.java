package pe.edu.sistema.util;

import java.util.Locale;

/**
 * Utilidades de presentación para los JSP (sin depender de JSTL).
 */
public final class Html {

    private Html() {
    }

    /** Escapa texto para mostrarlo de forma segura en HTML. */
    public static String esc(String s) {
        if (s == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder(s.length() + 16);
        for (char c : s.toCharArray()) {
            switch (c) {
                case '&' -> sb.append("&amp;");
                case '<' -> sb.append("&lt;");
                case '>' -> sb.append("&gt;");
                case '"' -> sb.append("&quot;");
                case '\'' -> sb.append("&#39;");
                default -> sb.append(c);
            }
        }
        return sb.toString();
    }

    /** 2500.0 -> "2,500.00" */
    public static String num(double v) {
        return String.format(Locale.US, "%,.2f", v);
    }

    /** 35850 -> "S/ 35,850.00" */
    public static String soles(double v) {
        return "S/ " + num(v);
    }
}
