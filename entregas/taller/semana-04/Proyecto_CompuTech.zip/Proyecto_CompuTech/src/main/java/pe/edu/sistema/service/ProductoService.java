package pe.edu.sistema.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import pe.edu.sistema.model.Producto;

/**
 * Servicio de productos. Almacena todo en un ArrayList en memoria
 * (no se utiliza base de datos). Es un singleton para que todos los
 * servlets compartan la misma colección.
 */
public class ProductoService {

    public static final List<String> CATEGORIAS = Arrays.asList(
            "Laptops", "Computadoras", "Monitores", "Periféricos",
            "Componentes", "Almacenamiento", "Redes", "Audio");

    public static final List<String> ESTADOS = Arrays.asList(
            "Disponible", "Agotado", "Descontinuado");

    private static final ProductoService INSTANCIA = new ProductoService();

    private final List<Producto> productos = new ArrayList<>();

    private ProductoService() {
        cargarDatosIniciales();
    }

    public static ProductoService getInstance() { return INSTANCIA; }

    private void cargarDatosIniciales() {
        productos.add(new Producto("P001", "Laptop Lenovo IdeaPad 3 14\"", "Lenovo", "Laptops", 2199.00, 10, "Disponible",
                "Ryzen 5, 8 GB RAM, SSD 512 GB y pantalla Full HD de 14\".", "laptop.svg"));
        productos.add(new Producto("P002", "Mouse Logitech G502 Hero", "Logitech", "Periféricos", 189.00, 25, "Disponible",
                "Sensor óptico de 25 600 DPI, 11 botones programables.", "mouse.svg"));
        productos.add(new Producto("P003", "Teclado Redragon Kumara", "Redragon", "Periféricos", 150.00, 0, "Agotado",
                "Teclado mecánico TKL retroiluminado RGB, switches rojos.", "teclado.svg"));
        productos.add(new Producto("P004", "Monitor Teros Gamer 24\"", "Teros", "Monitores", 649.00, 8, "Disponible",
                "Full HD, 75 Hz, panel IPS con bordes ultradelgados y base reforzada.", "monitor.svg"));
        productos.add(new Producto("P005", "Tarjeta de video MSI GeForce RTX Gaming X", "MSI", "Componentes", 2999.00, 5, "Disponible",
                "8 GB GDDR6, doble ventilador Twin Frozr e iluminación RGB Mystic Light.", "gpu.svg"));
        productos.add(new Producto("P006", "SSD Kingston NV2 1 TB", "Kingston", "Almacenamiento", 259.00, 40, "Disponible",
                "NVMe PCIe 4.0, lectura hasta 3 500 MB/s.", "ssd.svg"));
        productos.add(new Producto("P007", "PC Gamer Machine Blanca RGB", "Gamer Machine", "Computadoras", 5499.00, 4, "Disponible",
                "Core i7, RTX 4070, 32 GB DDR5, refrigeración líquida y gabinete de cristal blanco.", "pc.svg"));
        productos.add(new Producto("P008", "Auriculares Logitech G733 Lightspeed", "Logitech", "Audio", 329.00, 18, "Disponible",
                "Inalámbricos, iluminación RGB Lightsync y micrófono Blue Voice.", "auriculares.svg"));
        productos.add(new Producto("P009", "Memoria RAM Corsair 16 GB DDR5", "Corsair", "Componentes", 289.00, 30, "Disponible",
                "Kit 2x8 GB, 5600 MHz, iluminación RGB.", "ram.svg"));
        productos.add(new Producto("P010", "Router ASUS ROG Rapture GT-AX11000 Pro", "ASUS", "Redes", 1899.00, 0, "Agotado",
                "Wi-Fi 6 tri-banda para gaming con 8 antenas y puertos de 2.5 Gigabit.", "router.svg"));
        productos.add(new Producto("P011", "Webcam Logitech C920 HD Pro", "Logitech", "Periféricos", 219.00, 14, "Disponible",
                "Full HD 1080p con micrófono estéreo integrado.", "webcam.svg"));
        productos.add(new Producto("P012", "Laptop Lenovo IdeaPad 3 15\"", "Lenovo", "Laptops", 2599.00, 12, "Disponible",
                "Core i5, 8 GB RAM, SSD 512 GB, pantalla Full HD de 15.6\".", "laptop.svg"));
    }

    // ---------------------------------------------------------------- consultas

    public List<Producto> listar() { return new ArrayList<>(productos); }

    public Producto buscarPorCodigo(String codigo) {
        if (codigo == null) return null;
        for (Producto p : productos) {
            if (p.getCodigo().equalsIgnoreCase(codigo.trim())) return p;
        }
        return null;
    }

    /** Busca por "codigo", "nombre", "categoria" o "todos". */
    public List<Producto> buscar(String criterio, String texto) {
        List<Producto> resultado = new ArrayList<>();
        String t = texto == null ? "" : texto.trim().toLowerCase();
        for (Producto p : productos) {
            boolean coincide;
            switch (criterio == null ? "todos" : criterio) {
                case "codigo":    coincide = p.getCodigo().toLowerCase().contains(t); break;
                case "nombre":    coincide = p.getNombre().toLowerCase().contains(t); break;
                case "categoria": coincide = p.getCategoria().toLowerCase().contains(t); break;
                default:
                    coincide = p.getCodigo().toLowerCase().contains(t)
                            || p.getNombre().toLowerCase().contains(t)
                            || p.getCategoria().toLowerCase().contains(t);
            }
            if (coincide) resultado.add(p);
        }
        return resultado;
    }

    // ------------------------------------------------------------- validaciones

    /**
     * Valida un producto. Devuelve la lista de errores (vacía si es válido).
     * @param esNuevo true al registrar (se comprueba que el código no esté duplicado)
     */
    public List<String> validar(Producto p, boolean esNuevo) {
        List<String> errores = new ArrayList<>();
        if (p.getCodigo() == null || p.getCodigo().trim().isEmpty()) {
            errores.add("El código es obligatorio.");
        } else if (esNuevo && buscarPorCodigo(p.getCodigo()) != null) {
            errores.add("El código " + p.getCodigo().trim().toUpperCase() + " ya existe: no se permiten códigos duplicados.");
        }
        if (p.getNombre() == null || p.getNombre().trim().isEmpty()) {
            errores.add("El nombre es obligatorio.");
        }
        if (p.getCategoria() == null || p.getCategoria().trim().isEmpty()) {
            errores.add("La categoría es obligatoria.");
        }
        if (p.getPrecio() <= 0) {
            errores.add("El precio debe ser mayor que cero.");
        }
        if (p.getStock() < 0) {
            errores.add("El stock debe ser mayor o igual a cero.");
        }
        return errores;
    }

    // --------------------------------------------------------------------- CRUD

    public void registrar(Producto p) {
        normalizar(p);
        productos.add(p);
    }

    public void actualizar(Producto nuevo) {
        normalizar(nuevo);
        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).getCodigo().equalsIgnoreCase(nuevo.getCodigo())) {
                if (nuevo.getImagen() == null || nuevo.getImagen().isEmpty()) {
                    nuevo.setImagen(productos.get(i).getImagen());
                }
                productos.set(i, nuevo);
                return;
            }
        }
    }

    public boolean eliminar(String codigo) {
        Producto p = buscarPorCodigo(codigo);
        return p != null && productos.remove(p);
    }

    /** Ajusta código, estado e imagen por defecto antes de guardar. */
    private void normalizar(Producto p) {
        p.setCodigo(p.getCodigo().trim().toUpperCase());
        p.setNombre(p.getNombre().trim());
        if (p.getStock() == 0 && !"Descontinuado".equals(p.getEstado())) {
            p.setEstado("Agotado");
        } else if (p.getStock() > 0 && "Agotado".equals(p.getEstado())) {
            p.setEstado("Disponible");
        }
        if (p.getImagen() == null || p.getImagen().isEmpty()) {
            p.setImagen(imagenPorCategoria(p.getCategoria()));
        }
        if (p.getMarca() == null) p.setMarca("");
        if (p.getDescripcion() == null) p.setDescripcion("");
    }

    private String imagenPorCategoria(String categoria) {
        switch (categoria) {
            case "Laptops":        return "laptop.svg";
            case "Computadoras":   return "pc.svg";
            case "Monitores":      return "monitor.svg";
            case "Componentes":    return "gpu.svg";
            case "Almacenamiento": return "ssd.svg";
            case "Redes":          return "router.svg";
            case "Audio":          return "auriculares.svg";
            default:               return "mouse.svg";
        }
    }

    // ----------------------------------------------------------------- reportes

    public List<Producto> disponibles() {
        List<Producto> lista = new ArrayList<>();
        for (Producto p : productos) {
            if (p.getStock() > 0) lista.add(p);
        }
        return lista;
    }

    public int totalProductos() { return productos.size(); }
    public int totalDisponibles() { return disponibles().size(); }
    public int totalAgotados() { return totalProductos() - totalDisponibles(); }

    public double valorTotalInventario() {
        double total = 0;
        for (Producto p : productos) total += p.getValorInventario();
        return total;
    }

    public int stockTotal() {
        int total = 0;
        for (Producto p : productos) total += p.getStock();
        return total;
    }
}
