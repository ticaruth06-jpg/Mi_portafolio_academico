<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
</div></main>
<footer>
    <div class="wrap foot-grid">
        <div>
            <a class="logo" href="${ctx}/inicio" style="font-size:1.2rem"><span>Compu<b>Tech</b></span></a>
            <p style="margin-top:.8rem">Tu tienda de tecnología y computadoras. Laptops, componentes, monitores y periféricos con garantía y el mejor precio.</p>
        </div>
        <div><h4>Tienda</h4><ul>
            <li><a href="${ctx}/productos?accion=catalogo&categoria=Laptops">Laptops</a></li>
            <li><a href="${ctx}/productos?accion=catalogo&categoria=Componentes">Componentes</a></li>
            <li><a href="${ctx}/productos?accion=catalogo&categoria=Monitores">Monitores</a></li>
            <li><a href="${ctx}/productos?accion=catalogo&categoria=Periféricos">Periféricos</a></li></ul></div>
        <div><h4>Sistema</h4><ul>
            <li><a href="${ctx}/inicio">Inicio</a></li>
            <li><a href="${ctx}/reportes?tipo=disponibles">Disponibles</a></li>
            <li><a href="${ctx}/informacion.jsp">Información</a></li></ul></div>
        <div><h4>Contacto</h4><ul>
            <li>Huancayo, Junín - Perú</li><li>ventas@computech.pe</li><li>Lun a Sáb · 9:00 - 20:00</li></ul></div>
    </div>
    <div class="copy">© 2026 CompuTech · Desarrollo de Aplicaciones I · Universidad Peruana Los Andes</div>
</footer>
</body>
</html>
