<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Iniciar sesión · CompuTech</title>
    <link rel="stylesheet" href="${ctx}/css/estilos.css">
</head>
<body class="login">
<div class="login-wrap">
    <section class="login-art">
        <div>
            <span class="tag">● Tecnología al mejor precio</span>
            <h2>Equípate con lo último en computación.</h2>
            <p>Laptops, PCs gamer, monitores, componentes y periféricos con garantía oficial y envíos a todo el Perú.</p>
        </div>
    </section>
    <section class="login-form">
        <form class="login-box" method="post" action="${ctx}/login">
            <a class="logo" href="#"><span class="logo-mark">
                <svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="5" width="14" height="14" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 1v4M15 1v4M9 19v4M15 19v4M1 9h4M1 15h4M19 9h4M19 15h4"/></svg>
            </span><span>Compu<b>Tech</b></span></a>
            <h1>Bienvenido</h1>
            <p>Ingresa a tu cuenta para continuar.</p>

            <c:if test="${not empty error}"><div class="msg err">${error}</div></c:if>
            <c:if test="${param.salio == '1'}"><div class="msg ok">Sesión cerrada correctamente.</div></c:if>

            <div class="field"><label for="login">USUARIO</label>
                <input type="text" id="login" name="login" placeholder="Tu usuario" required autofocus></div>
            <div class="field"><label for="clave">CONTRASEÑA</label>
                <input type="password" id="clave" name="clave" placeholder="••••••••" required></div>
            <button class="btn" type="submit">Ingresar al sistema</button>

            <p style="text-align:center;margin-top:1.4rem;color:var(--mut)">¿Eres cliente y aún no tienes cuenta?
                <a href="${ctx}/registro"><b>Crear mi cuenta</b></a></p>
            <div class="demo">Acceso del administrador: <code>admin</code> / <code>admin123</code></div>
        </form>
    </section>
</div>
</body>
</html>
