/* validaciones.js · validación en el navegador (la validación definitiva está en ProductoService) */
(function () {
  'use strict';

  function marcar(campo, malo) {
    campo.classList.toggle('err-input', malo);
  }

  /** Valida el formulario de registrar / editar producto. */
  window.validarProducto = function (form) {
    var errores = [];
    var codigo = form.codigo, nombre = form.nombre, categoria = form.categoria,
        precio = form.precio, stock = form.stock;

    marcar(codigo, !codigo.value.trim());
    if (!codigo.value.trim()) errores.push('El código es obligatorio.');

    marcar(nombre, !nombre.value.trim());
    if (!nombre.value.trim()) errores.push('El nombre es obligatorio.');

    marcar(categoria, !categoria.value);
    if (!categoria.value) errores.push('La categoría es obligatoria.');

    var p = parseFloat(precio.value);
    marcar(precio, isNaN(p) || p <= 0);
    if (isNaN(p) || p <= 0) errores.push('El precio debe ser mayor que cero.');

    var s = parseInt(stock.value, 10);
    marcar(stock, isNaN(s) || s < 0);
    if (isNaN(s) || s < 0) errores.push('El stock debe ser mayor o igual a cero.');

    var caja = document.getElementById('erroresJs');
    if (caja) {
      if (errores.length) {
        caja.innerHTML = '<strong>Corrija los siguientes campos:</strong><ul><li>' +
                         errores.join('</li><li>') + '</li></ul>';
        caja.style.display = 'block';
        caja.scrollIntoView({behavior: 'smooth', block: 'center'});
      } else {
        caja.style.display = 'none';
      }
    }
    return errores.length === 0;
  };

  /** Pide confirmación antes de eliminar (modal). */
  window.confirmarEliminar = function (codigo, nombre) {
    document.getElementById('modalNombre').textContent = codigo + ' · ' + nombre;
    document.getElementById('modalCodigo').value = codigo;
    document.getElementById('modalEliminar').classList.add('show');
    return false;
  };
  window.cerrarModal = function () {
    document.getElementById('modalEliminar').classList.remove('show');
  };

  /** Vista previa de la imagen según la categoría elegida. */
  window.actualizarVista = function (sel) {
    var mapa = {'Laptops':'laptop','Computadoras':'pc','Monitores':'monitor','Componentes':'gpu',
                'Almacenamiento':'ssd','Redes':'router','Audio':'auriculares','Periféricos':'mouse'};
    var img = document.getElementById('vistaImg');
    var campo = document.getElementById('imagenActual');
    if (img && campo && !campo.value && mapa[sel.value]) {
      img.src = img.dataset.base + mapa[sel.value] + '.svg';
    }
  };
  /** Valida el formulario de creación de cuenta. */
  window.validarRegistro = function (form) {
    var errores = [];
    function chk(campo, malo, msg) { marcar(campo, malo); if (malo) errores.push(msg); }
    chk(form.nombre, form.nombre.value.trim().length < 3, 'Ingrese su nombre completo (mínimo 3 caracteres).');
    chk(form.login, !/^[A-Za-z0-9_.]{4,20}$/.test(form.login.value.trim()), 'El usuario debe tener de 4 a 20 caracteres (letras, números, punto o guion bajo).');
    chk(form.correo, !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.correo.value.trim()), 'Ingrese un correo electrónico válido.');
    chk(form.clave, form.clave.value.length < 6, 'La contraseña debe tener al menos 6 caracteres.');
    chk(form.clave2, form.clave.value !== form.clave2.value, 'Las contraseñas no coinciden.');
    var caja = document.getElementById('erroresJs');
    if (caja) {
      if (errores.length) {
        caja.innerHTML = '<strong>Corrija los siguientes campos:</strong><ul><li>' + errores.join('</li><li>') + '</li></ul>';
        caja.style.display = 'block';
      } else { caja.style.display = 'none'; }
    }
    return errores.length === 0;
  };
})();
