<%@ page contentType="text/html;charset=UTF-8" language="java" isErrorPage="true" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="paginaTitulo" value="Página no encontrada" scope="request"/>
<jsp:include page="/includes/header.jsp"/>
<div class="card" style="text-align:center;padding:4rem 1rem">
    <h1 style="font-size:4rem">404</h1>
    <p style="color:var(--mut);margin:.5rem 0 1.5rem">La página que buscas no existe.</p>
    <a class="btn" href="${ctx}/inicio">Volver al inicio</a>
</div>
<jsp:include page="/includes/footer.jsp"/>
