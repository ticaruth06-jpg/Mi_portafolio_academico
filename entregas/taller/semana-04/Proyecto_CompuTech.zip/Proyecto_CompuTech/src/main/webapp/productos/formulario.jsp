<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="paginaTitulo" value="${esNuevo ? 'Registrar producto' : 'Editar producto'}" scope="request"/>
<c:set var="activo" value="productos" scope="request"/>
<jsp:include page="/includes/header.jsp"/>

<div class="page-title">
    <div><div class="crumbs"><a href="${ctx}/inicio">Inicio</a> / Productos / ${esNuevo ? 'Registrar' : 'Editar'}</div>
        <h1>${esNuevo ? 'Registrar producto' : 'Editar producto'}</h1>
        <p>${esNuevo ? 'Completa el formulario para agregar un producto al inventario.' : 'Modifica los datos del producto seleccionado.'}</p></div>
</div>

<c:if test="${not empty errores}">
    <div class="msg err"><strong>No se pudo guardar el producto:</strong>
        <ul><c:forEach var="e" items="${errores}"><li>${e}</li></c:forEach></ul></div>
</c:if>
<div class="msg err" id="erroresJs" style="display:none"></div>

<div class="layout-2">
<form class="card" method="post" action="${ctx}/productos" onsubmit="return validarProducto(this)" novalidate>
    <input type="hidden" name="accion" value="${esNuevo ? 'guardar' : 'actualizar'}">
    <input type="hidden" name="imagen" id="imagenActual" value="${producto.imagen}">
    <div class="form-grid">
        <div><label for="codigo">CÓDIGO <span class="req">*</span></label>
            <input type="text" id="codigo" name="codigo" value="${producto.codigo}" placeholder="P013" maxlength="10" ${esNuevo ? '' : 'readonly'}></div>
        <div><label for="categoria">CATEGORÍA <span class="req">*</span></label>
            <select id="categoria" name="categoria" onchange="actualizarVista(this)">
                <option value="">— Seleccione —</option>
                <c:forEach var="c" items="${categorias}"><option value="${c}" ${producto.categoria == c ? 'selected' : ''}>${c}</option></c:forEach>
            </select></div>
        <div class="full"><label for="nombre">NOMBRE DEL PRODUCTO <span class="req">*</span></label>
            <input type="text" id="nombre" name="nombre" value="${producto.nombre}" placeholder="Ej.: Laptop ASUS TUF Gaming"></div>
        <div><label for="marca">MARCA</label>
            <input type="text" id="marca" name="marca" value="${producto.marca}" placeholder="ASUS"></div>
        <div><label for="estado">ESTADO</label>
            <select id="estado" name="estado">
                <c:forEach var="e" items="${estados}"><option value="${e}" ${producto.estado == e ? 'selected' : ''}>${e}</option></c:forEach>
            </select></div>
        <div><label for="precio">PRECIO (S/) <span class="req">*</span></label>
            <input type="number" id="precio" name="precio" step="0.01" value="${producto.precio > 0 ? producto.precio : ''}" placeholder="0.00"></div>
        <div><label for="stock">STOCK <span class="req">*</span></label>
            <input type="number" id="stock" name="stock" step="1" value="${producto.stock >= 0 && !esNuevo ? producto.stock : ''}" placeholder="0"></div>
        <div class="full"><label for="descripcion">DESCRIPCIÓN</label>
            <textarea id="descripcion" name="descripcion" rows="3" placeholder="Características principales">${producto.descripcion}</textarea></div>
    </div>
    <div class="form-actions">
        <button class="btn" type="submit"><svg class="ico"><use href="#i-check"/></svg> ${esNuevo ? 'Guardar producto' : 'Guardar cambios'}</button>
        <a class="btn ghost" href="${ctx}/productos?accion=listar">Cancelar</a>
    </div>
</form>

<aside class="card preview">
    <img id="vistaImg" data-base="${ctx}/img/"
         src="${ctx}/img/${empty producto.imagen ? 'laptop.svg' : producto.imagen}" alt="Vista previa">
    <h3>${empty producto.nombre ? 'Nuevo producto' : producto.nombre}</h3>
    <p style="color:var(--mut);margin-top:.3rem">La imagen se asigna según la categoría elegida.</p>
</aside>
</div>

<jsp:include page="/includes/footer.jsp"/>
