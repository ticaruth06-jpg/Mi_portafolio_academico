<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="paginaTitulo" value="Resumen de productos" scope="request"/>
<c:set var="activo" value="reportes" scope="request"/>
<jsp:include page="/includes/header.jsp"/>

<div class="page-title">
    <div><div class="crumbs"><a href="${ctx}/inicio">Inicio</a> / Reportes / Resumen</div>
        <h1>Resumen de productos</h1>
        <p>Estado general del inventario de CompuTech.</p></div>
</div>

<div class="big-stats">
    <div class="big g1"><small>Total de productos</small><strong>${total}</strong></div>
    <div class="big g2"><small>Productos disponibles</small><strong>${disponibles}</strong></div>
    <div class="big g3"><small>Productos agotados</small><strong>${agotados}</strong></div>
</div>

<div class="layout-2">
    <div class="card">
        <h3 style="margin-bottom:1rem">Valor por producto</h3>
        <c:forEach var="p" items="${productos}">
            <div style="display:grid;grid-template-columns:220px 1fr 110px;gap:.8rem;align-items:center;margin:.55rem 0;font-size:.88rem">
                <span>${p.nombre}</span>
                <div class="bar"><i style="width:${valorInventario > 0 ? (p.valorInventario * 100 / valorInventario) * 4 : 0}%;max-width:100%"></i></div>
                <span style="text-align:right">S/ <fmt:formatNumber value="${p.valorInventario}" pattern="#,##0"/></span>
            </div>
        </c:forEach>
    </div>
    <div>
<div class="ascii">RESUMEN DEL SISTEMA

Total de productos:     ${total}
Productos disponibles:  ${disponibles}
Productos agotados:     ${agotados}

Valor total del inventario:
S/ <fmt:formatNumber value="${valorInventario}" pattern="#,##0.00"/>

Stock total:
${stockTotal} unidades</div>
    </div>
</div>

<jsp:include page="/includes/footer.jsp"/>
