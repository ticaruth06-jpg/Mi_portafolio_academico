<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="paginaTitulo" value="Información" scope="request"/>
<c:set var="activo" value="info" scope="request"/>
<jsp:include page="/includes/header.jsp"/>

<div class="page-title">
    <div><div class="crumbs"><a href="${ctx}/inicio">Inicio</a> / Información</div>
        <h1>Información del proyecto</h1>
        <p>Sistema Web de Gestión de Productos · CompuTech</p></div>
</div>

<div class="layout-2">
    <div class="card">
        <h3>Acerca del sistema</h3>
        <p style="color:#b6c1e3;margin-top:.6rem">Aplicación web de nivel intermedio que permite registrar, consultar, actualizar y eliminar productos de la tienda de tecnología CompuTech. No utiliza base de datos: los productos se almacenan temporalmente en una colección <b>ArrayList</b> en memoria.</p>
        <div class="tech"><span>Java 17+</span><span>JSP</span><span>Servlets</span><span>JSTL</span><span>Maven</span><span>Apache Tomcat 11</span><span>CSS3</span><span>JavaScript</span><span>MVC</span></div>
        <h3 style="margin-top:1.6rem">Arquitectura MVC</h3>
        <div class="team" style="margin-top:.8rem">
            <div class="card"><b>Modelo</b><p style="color:var(--mut)">Producto, Usuario y servicios con la lógica de negocio.</p></div>
            <div class="card"><b>Vista</b><p style="color:var(--mut)">Páginas JSP, CSS3 y JavaScript.</p></div>
            <div class="card"><b>Controlador</b><p style="color:var(--mut)">ProductoServlet, ReporteServlet, LoginServlet.</p></div>
        </div>
    </div>
    <div class="card">
        <h3>Datos académicos</h3>
        <div class="spec">
            <span>Universidad</span><b>Universidad Peruana Los Andes</b>
            <span>Facultad</span><b>Ingeniería</b>
            <span>Escuela</span><b>Ingeniería de Sistemas y Computación</b>
            <span>Curso</span><b>Desarrollo de Aplicaciones I</b>
            <span>Docente</span><b>Mg. Ing. Raúl Fernández Bejarano</b>
            <span>Actividad</span><b>N° 04 · Arquitectura MVC</b>
            <span>Versión</span><b>1.0.0 · 2026</b>
        </div>
        <h3>Roles del sistema</h3>
        <p style="color:var(--mut);margin-top:.5rem"><b style="color:#f472b6">Administrador:</b> registra, edita, elimina y consulta productos.<br><b style="color:var(--cy)">Usuario:</b> cualquier cliente puede crear su cuenta; solo visualiza el catálogo, busca y consulta productos disponibles.</p>
    </div>
</div>

<jsp:include page="/includes/footer.jsp"/>
