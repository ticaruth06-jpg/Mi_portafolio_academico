<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora de la Hipotenusa - Actividad 02</title>
    <!-- Enlace a la hoja de estilos CSS -->
    <link rel="stylesheet" href="css/estilo.css">
    <!-- Fuente Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>

    <div class="main-wrapper">
        
        <!-- Barra Superior con Actividad y Logotipo UPLA a la derecha -->
        <header class="top-nav-bar">
            <div class="nav-left">
                <div class="nav-icon-box">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1-2.5-2.5Z"/><path d="M6 6h10M6 10h10"/></svg>
                </div>
                <span class="nav-title">Actividad 02</span>
            </div>
            <div class="nav-right">
                <!-- Coloca tu logo en la carpeta images/upla_logo.png o ajusta la ruta -->
                <div class="upla-logo-container">
                    <img src="images/Logo.jpg" alt="Logotipo UPLA" class="upla-logo-img" onerror="this.style.display='none'; document.getElementById('upla-fallback').style.display='flex';">
                    <!-- Fallback por si la imagen tarda en cargarse o no está -->
                    <div id="upla-fallback" class="upla-fallback-box" style="display:none;">
                        <div class="upla-badge-icon"></div>
                        <span class="upla-text">UPLA</span>
                    </div>
                </div>
            </div>
        </header>

        <!-- Título Principal de la Página -->
        <section class="main-header">
            <h1>La Hipotenusa de un Triángulo Rectángulo</h1>
            <p>Una herramienta diseñada para estudiantes y entusiastas. Aprende la lógica y visualiza cómo interactúan los lados en tiempo real.</p>
        </section>

        <!-- Contenedor de las dos columnas principales -->
        <div class="calculator-container-grid">
            
            <!-- COLUMNA IZQUIERDA: Formulario y Resultados -->
            <div class="column-left">
                <div class="card form-card">
                    <h2>Cálculo del Triángulo</h2>
                    <p class="card-subtitle">Ingresa las longitudes de los lados menores (catetos) para calcular la longitud del lado mayor (hipotenusa).</p>
                    
                    <form action="CalculoServlet" method="POST">
                        
                        <!-- Selector de Unidad con pestañas -->
                        <div class="form-group">
                            <label>Unidad de Medida</label>
                            <div class="unit-tabs">
                                <input type="radio" id="unit-cm" name="unidad" value="cm" ${empty unidad || unidad == 'cm' ? 'checked' : ''} onchange="actualizarUnidadVisual()">
                                <label for="unit-cm" class="tab-btn">cm</label>

                                <input type="radio" id="unit-m" name="unidad" value="m" ${unidad == 'm' ? 'checked' : ''} onchange="actualizarUnidadVisual()">
                                <label for="unit-m" class="tab-btn">m</label>

                                <input type="radio" id="unit-pulg" name="unidad" value="Pulg" ${unidad == 'Pulg' ? 'checked' : ''} onchange="actualizarUnidadVisual()">
                                <label for="unit-pulg" class="tab-btn">Pulg</label>
                            </div>
                        </div>

                        <!-- Cateto A -->
                        <div class="form-group">
                            <div class="label-row">
                                <label for="catetoA">Cateto A (Altura)</label>
                                <span class="input-hint">Valor numérico</span>
                            </div>
                            <div class="input-with-badge">
                                <input type="number" step="any" id="catetoA" name="catetoA" class="form-control" 
                                       value="${not empty catetoA ? catetoA : '3'}" placeholder="3" required>
                                <span class="badge-unit display-unidad">cm</span>
                            </div>
                        </div>

                        <!-- Cateto B -->
                        <div class="form-group">
                            <div class="label-row">
                                <label for="catetoB">Cateto B (Base)</label>
                                <span class="input-hint">Valor numérico</span>
                            </div>
                            <div class="input-with-badge">
                                <input type="number" step="any" id="catetoB" name="catetoB" class="form-control" 
                                       value="${not empty catetoB ? catetoB : '4'}" placeholder="4" required>
                                <span class="badge-unit display-unidad">cm</span>
                            </div>
                        </div>

                        <button type="submit" class="btn-calculate">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" style="vertical-align: middle; margin-right: 6px;"><rect width="16" height="20" x="4" y="2" rx="2"/><line x1="8" x2="16" y1="6" y2="6"/><line x1="16" x2="16" y1="14" y2="18"/><path d="M8 10h.01"/><path d="M12 10h.01"/><path d="M16 10h.01"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M8 18h.01"/><path d="M12 18h.01"/></svg>
                            Calcular Hipotenusa
                        </button>
                    </form>
                </div>

                <!-- Tarjeta de Resultado con Paso a Paso -->
                <div class="card result-card-success">
                    <div class="result-header-row">
                        <span class="success-dot-title">🟢 Resultado Calculado</span>
                        <span class="badge-success-tag">ÉXITO</span>
                    </div>
                    
                    <div class="result-main-info">
                        <span class="result-label-small">Hipotenusa (c)</span>
                        <div class="result-big-number">
                            <span class="highlight-num">${not empty resultado ? resultado : '5'}</span> 
                            <span class="display-unidad highlight-unidad">${not empty unidad ? unidad : 'cm'}</span>
                        </div>
                    </div>

                    <div class="steps-section">
                        <p class="steps-title">PASO A PASO DEL TEOREMA:</p>
                        
                        <div class="step-item">
                            <span class="check-icon">✓</span>
                            <div>
                                <span class="step-name">Sustitución de valores</span>
                                <p class="step-formula">c = √(a² + b²) = <b>√(${not empty catetoA ? catetoA : '3'}² + ${not empty catetoB ? catetoB : '4'}²)</b></p>
                            </div>
                        </div>

                        <div class="step-item">
                            <span class="check-icon">✓</span>
                            <div>
                                <span class="step-name">Suma de cuadrados</span>
                                <p class="step-formula">c = √(${not empty catetoA ? catetoA * catetoA : '9'} + ${not empty catetoB ? catetoB * catetoB : '16'}) = <b>√${(not empty catetoA ? catetoA * catetoA : 9) + (not empty catetoB ? catetoB * catetoB : 16)}</b></p>
                            </div>
                        </div>

                        <div class="step-item">
                            <span class="check-icon">✓</span>
                            <div>
                                <span class="step-name">Raíz cuadrada (Resultado)</span>
                                <p class="step-formula">c = <b>${not empty resultado ? resultado : '5'} ${not empty unidad ? unidad : 'cm'}</b></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- COLUMNA DERECHA: Representación Geométrica y Teoría -->
            <div class="column-right">
                <div class="card geometry-card">
                    <h2>Representación Geométrica</h2>
                    <p class="card-subtitle">Visualización de la relación matemática establecida por Pitágoras. El cuadrado de la hipotenusa es igual a la suma de los cuadrados de los catetos.</p>
                    
                    <!-- Lienzo SVG del Triángulo Corregido -->
                    <div class="schema-box">
                        <div class="triangle-svg-container">
                            <svg viewBox="0 0 220 140" class="triangle-svg">
                                <polygon points="50,15 50,120 190,120" fill="#f0f6ff" />
                                <line x1="50" y1="15" x2="190" y2="120" stroke="#2563eb" stroke-width="3.5" stroke-linecap="round"/>
                                <line x1="50" y1="15" x2="50" y2="120" stroke="#2563eb" stroke-width="3.5" stroke-linecap="round"/>
                                <line x1="50" y1="120" x2="190" y2="120" stroke="#2563eb" stroke-width="3.5" stroke-linecap="round"/>
                                
                                <!-- Símbolo de 90 grados -->
                                <rect x="50" y="102" width="18" height="18" fill="none" stroke="#2563eb" stroke-width="1.8"/>
                                <text x="54" y="115" font-size="9" fill="#2563eb" font-weight="bold" font-family="sans-serif">90°</text>
                            </svg>

                            <!-- Etiquetas de los lados -->
                            <span class="tag-cateto-a">
                                <strong style="color: #2563eb;">a</strong><br>
                                Cateto A<br>
                                <small>(${not empty catetoA ? catetoA : '3'} <span class="display-unidad">cm</span>)</small>
                            </span>
                            
                            <span class="tag-cateto-b">
                                <strong style="color: #2563eb;">b</strong><br>
                                Cateto B (${not empty catetoB ? catetoB : '4'} <span class="display-unidad">cm</span>)
                            </span>
                            
                            <span class="tag-hipotenusa">
                                <strong style="color: #2563eb;">c</strong><br>
                                Hipotenusa<br>
                                <small>(${not empty resultado ? resultado : '5'} <span class="display-unidad">cm</span>)</small>
                            </span>
                        </div>
                    </div>

                    <!-- Fórmula Teórica -->
                    <div class="formula-box">
                        <span class="formula-subtitle">LA FÓRMULA TEÓRICA</span>
                        <div class="formula-math">
                            c = √(a² + b²)
                        </div>
                        <p class="formula-desc">Donde <b>c</b> representa la hipotenusa, y <b>a</b> y <b>b</b> son los catetos perpendiculares del triángulo rectángulo.</p>
                    </div>

                    <!-- Sabías qué -->
                    <div class="trivia-box">
                        <div class="trivia-icon">💡</div>
                        <div>
                            <span class="trivia-title">¿Sabías qué?</span>
                            <p class="trivia-text">La combinación <b>3, 4 y 5</b> se conoce como un "Trío Pitagórico". Es la forma más simple de números enteros que satisfacen exactamente el teorema de Pitágoras.</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Pie de página con tu nombre -->
        <footer class="page-footer">
            <p>Ruth Nayeli Quispe Tica</p>
        </footer>
    </div>

    <!-- Script para sincronizar unidades -->
    <script>
        function actualizarUnidadVisual() {
            const radios = document.getElementsByName("unidad");
            let unidadSeleccionada = "cm";
            for (const r of radios) {
                if (r.checked) {
                    unidadSeleccionada = r.value;
                    break;
                }
            }
            const spans = document.getElementsByClassName("display-unidad");
            for (let s of spans) {
                s.innerText = unidadSeleccionada;
            }
        }
        window.onload = actualizarUnidadVisual;
    </script>
</body>
</html>