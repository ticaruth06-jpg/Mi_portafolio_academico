import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "ServletHipotenusa", urlPatterns = {"/ServletHipotenusa", "/CalculoServlet"})
public class ServletHipotenusa extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        
        try {
            String strA = request.getParameter("catetoA");
            String strB = request.getParameter("catetoB");
            String unidad = request.getParameter("unidad");
            
            if (unidad == null || unidad.isEmpty()) {
                unidad = "cm";
            }
            
            double a = Double.parseDouble(strA);
            double b = Double.parseDouble(strB);
            
            double c = Math.sqrt((a * a) + (b * b));
            double resultadoRedondeado = Math.round(c * 100.0) / 100.0;
            
            request.setAttribute("catetoA", a);
            request.setAttribute("catetoB", b);
            request.setAttribute("resultado", resultadoRedondeado);
            request.setAttribute("unidad", unidad);
            
        } catch (NumberFormatException e) {
            request.setAttribute("catetoA", 3.0);
            request.setAttribute("catetoB", 4.0);
            request.setAttribute("resultado", 5.0);
            request.setAttribute("unidad", "cm");
        }
        
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("index.jsp");
    }
}