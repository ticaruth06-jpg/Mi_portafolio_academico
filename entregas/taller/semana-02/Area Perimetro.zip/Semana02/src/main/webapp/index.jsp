<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Actividad 01 - Área y Perímetro</title>

    <link rel="stylesheet"
          href="${pageContext.request.contextPath}/css/estilo.css">
</head>

<body>

<header class="topbar">

    <div class="topbar-title">
        <div class="topbar-icon">
            <span></span>
        </div>

        <h1>Actividad 01</h1>
    </div>

    <!-- Solamente el logo de la universidad es una imagen -->
    <img
        class="university-logo"
        src="${pageContext.request.contextPath}/images/Logo.jpg"
        alt="Logo de la universidad">

</header>

<main class="page-container">

    <section class="layout">

        <div class="left-column">

            <section class="calculator-card">

                <h2>
                    Área y Perímetro de un<br>
                    Rectángulo
                </h2>

                <label class="section-label">
                    Unidad de Medida
                </label>

                <div class="units">

                    <button
                        type="button"
                        class="unit active"
                        data-unit="cm">
                        cm
                    </button>

                    <button
                        type="button"
                        class="unit"
                        data-unit="m">
                        m
                    </button>

                    <button
                        type="button"
                        class="unit"
                        data-unit="Pulg">
                        Pulg
                    </button>

                </div>

                <div class="field-group">

                    <label for="base">
                        Base (Ancho)
                    </label>

                    <div class="input-wrapper">

                        <span class="ruler-icon">▤</span>

                        <input
                            id="base"
                            type="number"
                            min="0"
                            step="any"
                            value="8">

                        <span class="input-unit">
                            cm
                        </span>

                    </div>

                </div>

                <div class="field-group">

                    <label for="altura">
                        Altura
                    </label>

                    <div class="input-wrapper">

                        <span class="ruler-icon">▤</span>

                        <input
                            id="altura"
                            type="number"
                            min="0"
                            step="any"
                            value="5">

                        <span class="input-unit">
                            cm
                        </span>

                    </div>

                </div>

                <button
                    id="calculateButton"
                    class="calculate-button"
                    type="button">

                    <span class="calculator-icon">▦</span>

                    Calcular Resultados

                </button>

            </section>

            <section class="results-section">

                <h3>
                    Resultados Calculados
                </h3>

                <div class="results-grid">

                    <article class="result-card">

                        <div class="result-header">
                            <span>Área</span>
                            <small>Base × Altura</small>
                        </div>

                        <div class="result-value">
                            <strong id="areaResult">40</strong>
                            <span id="areaUnit">cm²</span>
                        </div>

                    </article>

                    <article class="result-card">

                        <div class="result-header">
                            <span>Perímetro</span>
                            <small>2 × (Base + Altura)</small>
                        </div>

                        <div class="result-value">
                            <strong id="perimeterResult">26</strong>
                            <span id="perimeterUnit">cm</span>
                        </div>

                    </article>

                </div>

            </section>

        </div>

        <div class="right-column">

            <section class="diagram-card">

                <div class="diagram-header">

                    <h2>
                        Esquema Geométrico
                    </h2>

                    <span id="proportionText">
                        Proporciones : 8 × 5
                    </span>

                </div>

                <div class="diagram-area">

                    <div class="height-label">

                        <span>
                            Altura
                        </span>

                        <strong id="diagramHeight">
                            h = 5 cm
                        </strong>

                    </div>

                    <!-- Rectángulo construido con HTML y CSS -->
                    <div class="rectangle-wrapper">

                        <div class="rectangle-shape">

                            <i class="corner top-left"></i>
                            <i class="corner top-right"></i>
                            <i class="corner bottom-left"></i>
                            <i class="corner bottom-right"></i>

                        </div>

                        <div class="base-label">

                            <span>
                                Base (Ancho)
                            </span>

                            <strong id="diagramBase">
                                b = 8 cm
                            </strong>

                        </div>

                    </div>

                </div>

            </section>

            <section class="concepts-card">

                <h2>
                    Conceptos Clave
                </h2>

                <div class="concept">

                    <span class="concept-dot blue"></span>

                    <div>

                        <h3>
                            El Área (A)
                        </h3>

                        <p>
                            Representa el espacio bidimensional dentro de los
                            bordes del rectángulo. Se mide en unidades cuadradas
                            (cm²).
                        </p>

                    </div>

                </div>

                <div class="concept">

                    <span class="concept-dot orange"></span>

                    <div>

                        <h3>
                            El Perímetro (P)
                        </h3>

                        <p>
                            Es la longitud total del contorno del rectángulo.
                            Se obtiene sumando la longitud de todos sus cuatro
                            lados.
                        </p>

                    </div>

                </div>

            </section>

        </div>

    </section>

    <p class="author">
        Ruth Nayeli Quispe Tica
    </p>

</main>

<script src="${pageContext.request.contextPath}/js/calculadora.js"></script>

</body>
</html>