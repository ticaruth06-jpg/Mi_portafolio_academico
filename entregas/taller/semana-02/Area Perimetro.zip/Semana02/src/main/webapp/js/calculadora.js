document.addEventListener("DOMContentLoaded", function () {

    const baseInput = document.getElementById("base");
    const alturaInput = document.getElementById("altura");
    const calculateButton =
        document.getElementById("calculateButton");

    const areaResult =
        document.getElementById("areaResult");

    const perimeterResult =
        document.getElementById("perimeterResult");

    const areaUnit =
        document.getElementById("areaUnit");

    const perimeterUnit =
        document.getElementById("perimeterUnit");

    const diagramBase =
        document.getElementById("diagramBase");

    const diagramHeight =
        document.getElementById("diagramHeight");

    const proportionText =
        document.getElementById("proportionText");

    const unitButtons =
        document.querySelectorAll(".unit");

    const inputUnits =
        document.querySelectorAll(".input-unit");

    let selectedUnit = "cm";

    unitButtons.forEach(function (button) {

        button.addEventListener("click", function () {

            unitButtons.forEach(function (item) {
                item.classList.remove("active");
            });

            button.classList.add("active");

            selectedUnit = button.dataset.unit;

            inputUnits.forEach(function (unit) {
                unit.textContent = selectedUnit;
            });

            calcular();
        });
    });

    calculateButton.addEventListener("click", calcular);

    baseInput.addEventListener("input", calcular);
    alturaInput.addEventListener("input", calcular);

    function formatearNumero(numero) {
        return Number.isInteger(numero)
            ? numero
            : Number(numero.toFixed(2));
    }

    function calcular() {

        const base = parseFloat(baseInput.value);
        const altura = parseFloat(alturaInput.value);

        if (
            Number.isNaN(base) ||
            Number.isNaN(altura) ||
            base < 0 ||
            altura < 0
        ) {
            areaResult.textContent = "0";
            perimeterResult.textContent = "0";

            diagramBase.textContent =
                "b = 0 " + selectedUnit;

            diagramHeight.textContent =
                "h = 0 " + selectedUnit;

            proportionText.textContent =
                "Proporciones : 0 × 0";

            return;
        }

        const area = base * altura;
        const perimetro = 2 * (base + altura);

        const baseFormateada =
            formatearNumero(base);

        const alturaFormateada =
            formatearNumero(altura);

        areaResult.textContent =
            formatearNumero(area);

        perimeterResult.textContent =
            formatearNumero(perimetro);

        areaUnit.textContent =
            selectedUnit + "²";

        perimeterUnit.textContent =
            selectedUnit;

        diagramBase.textContent =
            "b = " +
            baseFormateada +
            " " +
            selectedUnit;

        diagramHeight.textContent =
            "h = " +
            alturaFormateada +
            " " +
            selectedUnit;

        proportionText.textContent =
            "Proporciones : " +
            baseFormateada +
            " × " +
            alturaFormateada;
    }

    calcular();
});