package com.mycompany.semana02;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/RectanguloServlet")
public class RectanguloServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        double base = Double.parseDouble(request.getParameter("base"));
        double altura = Double.parseDouble(request.getParameter("altura"));
        String unidad = request.getParameter("unidad");

        Rectangulo rectangulo = new Rectangulo(base, altura);

        double area = rectangulo.calcularArea();
        double perimetro = rectangulo.calcularPerimetro();

        request.setAttribute("base", base);
        request.setAttribute("altura", altura);
        request.setAttribute("unidad", unidad);
        request.setAttribute("area", area);
        request.setAttribute("perimetro", perimetro);

        request.getRequestDispatcher("index.jsp")
                .forward(request, response);
    }
}