package pe.edu.sistema.model;

/** Modelo: usuario del sistema con rol ADMIN o USUARIO. La contraseña se guarda cifrada (hash). */
public class Usuario {

    public static final String ADMIN = "ADMIN";
    public static final String USUARIO = "USUARIO";

    private final String login;
    private final String claveHash;
    private final String nombre;
    private final String correo;
    private final String rol;

    public Usuario(String login, String claveHash, String nombre, String correo, String rol) {
        this.login = login;
        this.claveHash = claveHash;
        this.nombre = nombre;
        this.correo = correo;
        this.rol = rol;
    }

    public String getLogin() { return login; }
    public String getClaveHash() { return claveHash; }
    public String getNombre() { return nombre; }
    public String getCorreo() { return correo; }
    public String getRol() { return rol; }
    public boolean isAdmin() { return ADMIN.equals(rol); }
}
