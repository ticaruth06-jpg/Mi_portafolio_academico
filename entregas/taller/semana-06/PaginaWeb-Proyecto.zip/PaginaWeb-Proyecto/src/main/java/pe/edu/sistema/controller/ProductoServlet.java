package pe.edu.sistema.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.List;
import pe.edu.sistema.model.Producto;
import pe.edu.sistema.model.Usuario;
import pe.edu.sistema.service.ProductoService;

/**
 * Controlador del módulo de productos.
 * Acciones (?accion=): listar, catalogo, detalle, buscar, nuevo, guardar,
 *                      editar, actualizar, eliminar.
 * Solo el ADMIN puede: nuevo, guardar, editar, actualizar y eliminar.
 */
@WebServlet("/productos")
@MultipartConfig(maxFileSize = 5 * 1024 * 1024, maxRequestSize = 6 * 1024 * 1024)
public class ProductoServlet extends HttpServlet {

    private final ProductoService servicio = ProductoService.getInstance();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        procesar(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        procesar(request, response);
    }

    private void procesar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");
        if (accion == null) accion = "listar";

        Usuario usuario = (Usuario) request.getSession().getAttribute("usuario");
        boolean soloAdmin = accion.equals("nuevo") || accion.equals("guardar")
                || accion.equals("editar") || accion.equals("actualizar")
                || accion.equals("eliminar");
        if (soloAdmin && (usuario == null || !usuario.isAdmin())) {
            request.setAttribute("mensajeError", "Acceso denegado: esta acción es solo para administradores.");
            accion = "catalogo";
        }

        request.setAttribute("categorias", ProductoService.CATEGORIAS);
        request.setAttribute("estados", ProductoService.ESTADOS);

        switch (accion) {
            case "catalogo":   catalogo(request, response); break;
            case "detalle":    detalle(request, response); break;
            case "buscar":     buscar(request, response); break;
            case "nuevo":      nuevo(request, response); break;
            case "guardar":    guardar(request, response); break;
            case "editar":     editar(request, response); break;
            case "actualizar": actualizar(request, response); break;
            case "eliminar":   eliminar(request, response); break;
            default:           listar(request, response);
        }
    }

    private void listar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("productos", servicio.listar());
        request.setAttribute("modo", request.getParameter("modo")); // editar | eliminar | null
        request.getRequestDispatcher("/productos/listar.jsp").forward(request, response);
    }

    private void catalogo(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String categoria = request.getParameter("categoria");
        List<Producto> lista = (categoria == null || categoria.isEmpty())
                ? servicio.listar() : servicio.buscar("categoria", categoria);
        request.setAttribute("productos", lista);
        request.setAttribute("categoriaSel", categoria);
        request.getRequestDispatcher("/productos/catalogo.jsp").forward(request, response);
    }

    private void detalle(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Producto p = servicio.buscarPorCodigo(request.getParameter("codigo"));
        if (p == null) {
            response.sendRedirect(request.getContextPath() + "/productos?accion=catalogo");
            return;
        }
        request.setAttribute("producto", p);
        request.getRequestDispatcher("/productos/detalle.jsp").forward(request, response);
    }

    private void buscar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String criterio = request.getParameter("criterio");
        String texto = request.getParameter("texto");
        if (texto != null) {
            request.setAttribute("resultados", servicio.buscar(criterio, texto));
        }
        request.setAttribute("criterio", criterio);
        request.setAttribute("texto", texto);
        request.getRequestDispatcher("/productos/buscar.jsp").forward(request, response);
    }

    private void nuevo(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("producto", new Producto());
        request.setAttribute("esNuevo", true);
        request.getRequestDispatcher("/productos/formulario.jsp").forward(request, response);
    }

    private void guardar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Producto p = leerFormulario(request);
        List<String> errores = servicio.validar(p, true);
        if (!errores.isEmpty()) {
            request.setAttribute("errores", errores);
            request.setAttribute("producto", p);
            request.setAttribute("esNuevo", true);
            request.getRequestDispatcher("/productos/formulario.jsp").forward(request, response);
            return;
        }
        servicio.registrar(p);
        guardarFoto(request, p.getCodigo());
        request.getSession().setAttribute("flash", "Producto " + p.getCodigo() + " registrado correctamente.");
        response.sendRedirect(request.getContextPath() + "/productos?accion=listar");
    }

    private void editar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Producto p = servicio.buscarPorCodigo(request.getParameter("codigo"));
        if (p == null) {
            response.sendRedirect(request.getContextPath() + "/productos?accion=listar");
            return;
        }
        request.setAttribute("producto", p);
        request.setAttribute("esNuevo", false);
        request.getRequestDispatcher("/productos/formulario.jsp").forward(request, response);
    }

    private void actualizar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Producto p = leerFormulario(request);
        List<String> errores = servicio.validar(p, false);
        if (!errores.isEmpty()) {
            request.setAttribute("errores", errores);
            request.setAttribute("producto", p);
            request.setAttribute("esNuevo", false);
            request.getRequestDispatcher("/productos/formulario.jsp").forward(request, response);
            return;
        }
        servicio.actualizar(p);
        guardarFoto(request, p.getCodigo());
        request.getSession().setAttribute("flash", "Producto " + p.getCodigo() + " actualizado correctamente.");
        response.sendRedirect(request.getContextPath() + "/productos?accion=listar");
    }

    private void eliminar(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String codigo = request.getParameter("codigo");
        if (servicio.eliminar(codigo)) {
            request.getSession().setAttribute("flash", "Producto " + codigo + " eliminado.");
        }
        response.sendRedirect(request.getContextPath() + "/productos?accion=listar");
    }

    /** Lee los campos del formulario; precio y stock inválidos se tratan como valores no permitidos. */
    private Producto leerFormulario(HttpServletRequest request) {
        Producto p = new Producto();
        p.setCodigo(request.getParameter("codigo"));
        p.setNombre(request.getParameter("nombre"));
        p.setMarca(request.getParameter("marca"));
        p.setCategoria(request.getParameter("categoria"));
        p.setEstado(request.getParameter("estado"));
        p.setDescripcion(request.getParameter("descripcion"));
        p.setImagen(request.getParameter("imagen"));
        try {
            p.setPrecio(Double.parseDouble(request.getParameter("precio").trim()));
        } catch (Exception e) {
            p.setPrecio(0);
        }
        try {
            p.setStock(Integer.parseInt(request.getParameter("stock").trim()));
        } catch (Exception e) {
            p.setStock(-1);
        }
        return p;
    }

    /**
     * Guarda la foto subida (campo "foto") como img/productos/CODIGO.jpg en 800x600
     * con fondo blanco. Si no se sube foto, se conserva la anterior o la ilustración.
     */
    private void guardarFoto(HttpServletRequest request, String codigo) {
        try {
            Part parte = request.getPart("foto");
            if (parte == null || parte.getSize() == 0) return;
            BufferedImage original = ImageIO.read(parte.getInputStream());
            if (original == null) return;                       // no era una imagen válida

            BufferedImage lienzo = new BufferedImage(800, 600, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = lienzo.createGraphics();
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, 800, 600);
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            double escala = Math.min(760.0 / original.getWidth(), 560.0 / original.getHeight());
            int w = (int) (original.getWidth() * escala), h = (int) (original.getHeight() * escala);
            g.drawImage(original, (800 - w) / 2, (600 - h) / 2, w, h, null);
            g.dispose();

            String ruta = getServletContext().getRealPath("/img/productos");
            if (ruta == null) return;
            File carpeta = new File(ruta);
            carpeta.mkdirs();
            ImageIO.write(lienzo, "jpg", new File(carpeta, codigo + ".jpg"));
        } catch (Exception e) {
            // si algo falla se mantiene la ilustración por defecto
        }
    }
}
