package pe.edu.sistema.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import pe.edu.sistema.model.ItemCarrito;
import pe.edu.sistema.model.Producto;
import pe.edu.sistema.service.ProductoService;

/**
 * Carrito de compras del cliente (se guarda en la sesión: código -> cantidad).
 * ?accion= ver (por defecto) | agregar | quitar | vaciar
 */
@WebServlet("/carrito")
public class CarritoServlet extends HttpServlet {

    private final ProductoService servicio = ProductoService.getInstance();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ver(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        HttpSession sesion = request.getSession();
        Map<String, Integer> carrito = obtener(sesion);
        String accion = request.getParameter("accion");
        String codigo = request.getParameter("codigo");

        if ("agregar".equals(accion) && codigo != null) {
            Producto p = servicio.buscarPorCodigo(codigo);
            if (p == null) {
                sesion.setAttribute("flashCarrito", "El producto no existe.");
            } else if (p.getStock() <= 0) {
                sesion.setAttribute("flashCarrito", "\"" + p.getNombre() + "\" está agotado.");
            } else {
                int actual = carrito.getOrDefault(p.getCodigo(), 0);
                if (actual >= p.getStock()) {
                    sesion.setAttribute("flashCarrito", "Solo hay " + p.getStock() + " unidades de \"" + p.getNombre() + "\".");
                } else {
                    carrito.put(p.getCodigo(), actual + 1);
                    sesion.setAttribute("flashCarrito", "Se añadió \"" + p.getNombre() + "\" al carrito.");
                }
            }
        } else if ("quitar".equals(accion) && codigo != null) {
            carrito.remove(codigo.trim().toUpperCase());
        } else if ("vaciar".equals(accion)) {
            carrito.clear();
        }
        response.sendRedirect(request.getContextPath() + "/carrito");
    }

    private void ver(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Map<String, Integer> carrito = obtener(request.getSession());
        List<ItemCarrito> items = new ArrayList<>();
        double total = 0;
        for (Map.Entry<String, Integer> e : new ArrayList<>(carrito.entrySet())) {
            Producto p = servicio.buscarPorCodigo(e.getKey());
            if (p == null || p.getStock() <= 0) { carrito.remove(e.getKey()); continue; }
            ItemCarrito it = new ItemCarrito(p, Math.min(e.getValue(), p.getStock()));
            items.add(it);
            total += it.getSubtotal();
        }
        request.setAttribute("items", items);
        request.setAttribute("total", total);
        request.getRequestDispatcher("/carrito.jsp").forward(request, response);
    }

    @SuppressWarnings("unchecked")
    private Map<String, Integer> obtener(HttpSession sesion) {
        Map<String, Integer> c = (Map<String, Integer>) sesion.getAttribute("carrito");
        if (c == null) {
            c = new LinkedHashMap<>();
            sesion.setAttribute("carrito", c);
        }
        return c;
    }
}
