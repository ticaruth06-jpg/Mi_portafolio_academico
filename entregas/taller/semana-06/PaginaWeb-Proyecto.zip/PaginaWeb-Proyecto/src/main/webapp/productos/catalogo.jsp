<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<c:set var="paginaTitulo" value="Catálogo" scope="request"/>
<c:set var="activo" value="productos" scope="request"/>
<jsp:include page="/includes/header.jsp"/>

<div class="page-title">
    <div><div class="crumbs"><a href="${ctx}/inicio">Inicio</a> / Productos</div>
        <h1>Catálogo de productos</h1>
        <p>Explora los equipos y accesorios disponibles en CompuTech.</p></div>
</div>

<c:if test="${not empty mensajeError}"><div class="msg err">${mensajeError}</div></c:if>

<div class="chips">
    <a class="chip ${empty categoriaSel ? 'act' : ''}" href="${ctx}/productos?accion=catalogo">Todos</a>
    <c:forEach var="cat" items="${categorias}">
        <a class="chip ${categoriaSel == cat ? 'act' : ''}" href="${ctx}/productos?accion=catalogo&categoria=${cat}">${cat}</a>
    </c:forEach>
</div>

<div class="grid">
    <c:forEach var="p" items="${productos}">
        <article class="pcard">
            <div class="ribbon"><span class="badge ${p.estado == 'Disponible' ? 'b-ok' : (p.estado == 'Agotado' ? 'b-bad' : 'b-bad')}">${p.estado}</span></div>
            <div class="pic"><img src="${ctx}/img/productos/${p.codigo}.jpg" onerror="this.onerror=null;this.src='${ctx}/img/${p.imagen}'" alt="${p.nombre}"></div>
            <div class="info">
                <span class="cat">${p.categoria}</span>
                <h3>${p.nombre}</h3><span class="brand">${p.marca} · ${p.codigo}</span>
                <div class="price"><small>S/</small> <fmt:formatNumber value="${p.precio}" pattern="#,##0.00"/></div>
                <div class="foot"><span class="brand">Stock: ${p.stock}</span>
                    <a class="btn sm ghost" href="${ctx}/productos?accion=detalle&codigo=${p.codigo}">Ver detalle</a></div>
                <c:if test="${!sessionScope.usuario.admin}">
                <div class="buy-row">
                    <form method="post" action="${ctx}/carrito" style="margin:0">
                        <input type="hidden" name="accion" value="agregar"><input type="hidden" name="codigo" value="${p.codigo}">
                        <button class="btn sm cart" type="submit" ${p.stock > 0 ? '' : 'disabled'}>Añadir al carrito</button></form>
                    <button class="btn sm wsp" type="button" ${p.stock > 0 ? '' : 'disabled'}
                            data-nombre="${fn:escapeXml(p.nombre)}" data-codigo="${p.codigo}" data-precio="${p.precio}"
                            onclick="comprarWsp(this)">WhatsApp</button>
                </div></c:if>
            </div>
        </article>
    </c:forEach>
</div>
<c:if test="${empty productos}"><div class="msg info">No hay productos en esta categoría.</div></c:if>

<jsp:include page="/includes/footer.jsp"/>
