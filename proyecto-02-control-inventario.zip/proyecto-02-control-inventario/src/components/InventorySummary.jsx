import { Box, CircleAlert, Layers, ArrowUpRight } from 'lucide-react'
import { money, valorTotal, unidades, requierenAtencion, estado } from '../utils/inventory.js'

const dos = (n) => String(n).padStart(2, '0')

export default function InventorySummary({ productos }) {
  const alertas = requierenAtencion(productos)
  const bajos = alertas.filter((p) => estado(p) === 'bajo').length
  const agotados = alertas.length - bajos
  const categorias = new Set(productos.map((p) => p.categoria)).size
  return (
    <div className="stats">
      <div className="card stat dark">
        <div className="stat-top"><span>Valor total del inventario</span><ArrowUpRight size={16} /></div>
        <strong>{money(valorTotal(productos))}</strong>
        <small>Precio unitario × existencias disponibles</small>
      </div>
      <div className="card stat">
        <div className="stat-top"><span>Productos registrados</span><Box size={18} /></div>
        <strong>{dos(productos.length)}</strong><small>En {categorias} categorías</small>
      </div>
      <div className="card stat">
        <div className="stat-top"><span>Unidades disponibles</span><Layers size={18} /></div>
        <strong>{unidades(productos)}</strong><small>Existencias en almacén</small>
      </div>
      <div className="card stat">
        <div className="stat-top"><span>Requieren atención</span><CircleAlert size={18} /></div>
        <strong>{dos(alertas.length)}</strong>
        <small className="warn">{bajos} bajo mínimo · {agotados} agotado{agotados === 1 ? '' : 's'}</small>
      </div>
    </div>
  )
}
