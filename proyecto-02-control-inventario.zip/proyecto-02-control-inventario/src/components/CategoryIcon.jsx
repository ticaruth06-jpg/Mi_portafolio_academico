import { Archive, LampDesk, Package, PenLine, Sparkles } from 'lucide-react'

const ICONOS = { Papelería: PenLine, Organización: Archive, Iluminación: LampDesk, Decoración: Sparkles }

export default function CategoryIcon({ categoria, size = 20 }) {
  const Icon = ICONOS[categoria] ?? Package
  return <Icon size={size} />
}
