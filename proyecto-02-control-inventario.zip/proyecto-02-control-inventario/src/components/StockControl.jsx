import { useEffect, useState } from 'react'
import { ArrowLeftRight, Check, Minus, Plus, ShieldCheck } from 'lucide-react'

// Registra entradas y salidas. Las salidas no pueden superar el stock (RNF03).
export default function StockControl({ producto, onApply }) {
  const [tipo, setTipo] = useState('entrada')
  const [cantidad, setCantidad] = useState(1)
  const [error, setError] = useState('')

  useEffect(() => { setCantidad(1); setError('') }, [producto?.id])

  if (!producto) {
    return (
      <section className="card">
        <div className="card-head"><h3>Ajustar existencias</h3><ArrowLeftRight size={18} /></div>
        <p className="empty">Selecciona un producto de la tabla para registrar una entrada o una salida.</p>
      </section>
    )
  }

  const delta = tipo === 'entrada' ? cantidad : -cantidad
  const resultante = producto.stock + delta

  const confirmar = () => {
    if (!Number.isInteger(cantidad) || cantidad < 1) return setError('Ingresa una cantidad entera mayor que cero.')
    if (resultante < 0) return setError(`La salida supera el stock disponible (${producto.stock}).`)
    onApply(producto.id, delta)
    setCantidad(1)
    setError('')
  }

  return (
    <section className="card adjust">
      <div className="card-head"><h3>Ajustar existencias</h3><ArrowLeftRight size={18} /></div>
      <b>{producto.nombre}</b>
      <small>{producto.codigo} · {producto.stock} unidades actuales</small>
      <div className="seg">
        <button className={tipo === 'entrada' ? 'on' : ''} onClick={() => { setTipo('entrada'); setError('') }}>+ Entrada</button>
        <button className={tipo === 'salida' ? 'on' : ''} onClick={() => { setTipo('salida'); setError('') }}>− Salida</button>
      </div>
      <div className="qty">
        <button aria-label="Menos" onClick={() => setCantidad((c) => Math.max(1, c - 1))}><Minus size={16} /></button>
        <input type="number" min="1" value={cantidad} onChange={(e) => setCantidad(Math.floor(Number(e.target.value)))} />
        <button aria-label="Más" onClick={() => setCantidad((c) => c + 1)}><Plus size={16} /></button>
      </div>
      <div className="result"><small>Stock resultante</small><b className={resultante < 0 ? 'neg' : ''}>{resultante} unidades</b></div>
      {error && <em className="error">{error}</em>}
      <button className="btn primary block" onClick={confirmar}><Check size={16} /> Confirmar {tipo}</button>
      <small className="note"><ShieldCheck size={13} /> Las salidas no pueden superar el stock disponible.</small>
    </section>
  )
}
