import { useState } from 'react'
import { Eye, History, ShieldCheck, Trash2, TriangleAlert, Upload } from 'lucide-react'
import CategoryIcon from './CategoryIcon.jsx'
import { estado, ETIQUETA, money } from '../utils/inventory.js'

const fecha = (d) => d.toLocaleDateString('es-ES', { day: 'numeric', month: 'short', year: 'numeric' })
const hora = (d) => d.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })

// Registra (RF01) y edita (RF02). Valida precio y cantidades (RNF02, RNF03).
export default function ProductForm({ producto, productos, categorias, onSave, onDelete }) {
  const nuevo = !producto
  const [f, setF] = useState({
    codigo: producto?.codigo ?? '',
    categoria: producto?.categoria ?? '',
    nombre: producto?.nombre ?? '',
    descripcion: producto?.descripcion ?? '',
    precio: producto ? String(producto.precio) : '',
    stock: producto ? String(producto.stock) : '',
    minimo: producto ? String(producto.minimo) : '',
    imagen: producto?.imagen ?? '',
  })
  const [err, setErr] = useState({})
  const set = (k) => (e) => setF((x) => ({ ...x, [k]: e.target.value }))

  const precio = Number(f.precio), stock = Number(f.stock), minimo = Number(f.minimo)
  const vistaPrevia = { precio: precio >= 0 ? precio : 0, stock: stock >= 0 ? stock : 0, minimo: minimo >= 0 ? minimo : 0 }
  const est = estado(vistaPrevia)
  const faltan = vistaPrevia.minimo - vistaPrevia.stock

  const validar = () => {
    const e = {}
    const codigo = f.codigo.trim().toUpperCase()
    if (!codigo) e.codigo = 'Ingresa el código del producto.'
    else if (productos.some((p) => p.codigo === codigo && p.id !== producto?.id)) e.codigo = 'Ese código ya existe en el catálogo.'
    if (!f.categoria) e.categoria = 'Selecciona una categoría.'
    if (!f.nombre.trim()) e.nombre = 'Ingresa el nombre del producto.'
    if (f.precio.trim() === '' || Number.isNaN(precio) || precio < 0) e.precio = 'El precio debe ser un número mayor o igual a 0.'
    if (f.stock.trim() === '' || !Number.isInteger(stock) || stock < 0) e.stock = 'Usa un número entero mayor o igual a 0.'
    if (f.minimo.trim() === '' || !Number.isInteger(minimo) || minimo < 0) e.minimo = 'Usa un número entero mayor o igual a 0.'
    setErr(e)
    return Object.keys(e).length === 0
  }

  const submit = (ev) => {
    ev.preventDefault()
    if (!validar()) return
    onSave({
      codigo: f.codigo.trim().toUpperCase(), categoria: f.categoria, nombre: f.nombre.trim(),
      descripcion: f.descripcion.trim(), imagen: f.imagen || null, precio: Math.round(precio * 100) / 100, stock, minimo,
    })
  }

  // Imagen del producto: se guarda como data URL en memoria (máx. 2 MB).
  const subirImagen = (ev) => {
    const archivo = ev.target.files?.[0]
    if (!archivo) return
    if (!archivo.type.startsWith('image/')) return setErr((e) => ({ ...e, imagen: 'Elige un archivo de imagen (JPG, PNG o WebP).' }))
    if (archivo.size > 2 * 1024 * 1024) return setErr((e) => ({ ...e, imagen: 'La imagen supera los 2 MB. Elige una más liviana.' }))
    const lector = new FileReader()
    lector.onload = () => { setF((x) => ({ ...x, imagen: lector.result })); setErr((e) => ({ ...e, imagen: undefined })) }
    lector.readAsDataURL(archivo)
  }

  const campo = (k, label, props = {}, suffix) => (
    <label className="field">
      <span>{label}</span>
      <div className="suffix"><input value={f[k]} onChange={set(k)} {...props} />{suffix && <em>{suffix}</em>}</div>
      {err[k] && <em className="error">{err[k]}</em>}
    </label>
  )

  return (
    <form id="producto-form" className="form-grid" onSubmit={submit} noValidate>
      <div className="form-main">
        <section className="card">
          <h3><i className="num-badge">01</i> Información general</h3>
          <small className="muted">Los campos con * son obligatorios.</small>
          <div className="two">
            <div>{campo('codigo', 'Código del producto *', { placeholder: 'ILU-009' })}<small className="hint">Identificador único del catálogo.</small></div>
            <label className="field">
              <span>Categoría *</span>
              <select value={f.categoria} onChange={set('categoria')}>
                <option value="">Seleccionar categoría</option>
                {categorias.map((c) => <option key={c}>{c}</option>)}
              </select>
              {err.categoria && <em className="error">{err.categoria}</em>}
            </label>
          </div>
          {campo('nombre', 'Nombre del producto *')}
          <div className="field">
            <span>Imagen del producto <small>Opcional</small></span>
            <div className="upload">
              <label className="btn"><Upload size={15} /> {f.imagen ? 'Cambiar imagen' : 'Subir imagen'}
                <input type="file" accept="image/*" hidden onChange={subirImagen} /></label>
              {f.imagen && <button type="button" className="btn" onClick={() => setF((x) => ({ ...x, imagen: '' }))}>Quitar</button>}
            </div>
            {err.imagen && <em className="error">{err.imagen}</em>}
          </div>
          <label className="field">
            <span className="between">Descripción <small>Opcional</small></span>
            <textarea rows="3" value={f.descripcion} onChange={set('descripcion')} />
          </label>
        </section>

        <section className="card">
          <h3><i className="num-badge">02</i> Precio y existencias</h3>
          <small className="muted">Define el valor unitario y el punto de reposición.</small>
          <div className="three">
            {campo('precio', 'Precio unitario *', { inputMode: 'decimal' }, 'PEN')}
            {campo('stock', 'Stock actual *', { inputMode: 'numeric' }, 'unidades')}
            {campo('minimo', 'Stock mínimo *', { inputMode: 'numeric' }, 'unidades')}
          </div>
          <small className="hint"><ShieldCheck size={13} /> Precio ≥ 0 · Cantidades enteras ≥ 0 · No se permite stock negativo.</small>
          {est !== 'disponible' && (
            <div className="alert">
              <TriangleAlert size={18} />
              <div>
                <b>{est === 'agotado' ? 'Este producto está agotado.' : 'Este producto está por debajo del stock mínimo.'}</b>
                <small>Faltan {faltan} unidades para alcanzar el nivel mínimo de {vistaPrevia.minimo}.</small>
              </div>
            </div>
          )}
        </section>
        <div className="bottom-actions">
          <small className="muted">Los cambios se aplican al guardar.</small>
        </div>
      </div>

      <aside className="form-side">
        <section className="card preview">
          <div className="preview-head"><small>VISTA PREVIA DEL PRODUCTO</small><Eye size={15} /></div>
          {f.imagen
            ? <img src={f.imagen} alt={f.nombre} />
            : <div className="ph"><CategoryIcon categoria={f.categoria} size={40} /></div>}
          <div className="preview-body">
            <div className="between"><small>{f.codigo || 'CÓDIGO'}</small><span className={`pill ${est}`}>● {ETIQUETA[est]}</span></div>
            <h2>{f.nombre || 'Nuevo producto'}</h2>
            <small>{f.categoria || 'Sin categoría'}</small>
            <div className="price-row">
              <div><small>PRECIO UNITARIO</small><strong>{money(vistaPrevia.precio)}</strong></div>
              <div className="r"><small>EN ALMACÉN</small><strong>{vistaPrevia.stock} uds.</strong></div>
            </div>
            <div className="value"><span>Valor en inventario</span><b>{money(vistaPrevia.precio * vistaPrevia.stock)}</b></div>
          </div>
        </section>
        {!nuevo && (
          <div className="trace">
            <b><History size={14} /> Trazabilidad del producto</b>
            <small>Creado el {fecha(producto.creado)} por Lucía Vega.</small>
            <small>Última edición: {producto.editado.toDateString() === new Date().toDateString() ? 'hoy' : fecha(producto.editado)}, {hora(producto.editado)}.</small>
            <button type="button" className="link-danger" onClick={() => onDelete(producto)}><Trash2 size={14} /> Eliminar producto</button>
          </div>
        )}
      </aside>
    </form>
  )
}
