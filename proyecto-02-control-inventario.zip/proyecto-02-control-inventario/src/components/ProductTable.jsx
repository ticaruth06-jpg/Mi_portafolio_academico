import { Minus, Pencil, Plus, Trash2 } from 'lucide-react'
import CategoryIcon from './CategoryIcon.jsx'
import { estado, ETIQUETA, money } from '../utils/inventory.js'

export default function ProductTable({ productos, total, selectedId, onSelect, onStep, onEdit, onDelete }) {
  if (productos.length === 0) {
    return <p className="empty">No hay productos con esos filtros. Limpia la búsqueda o registra un producto nuevo.</p>
  }
  return (
    <div className="table-wrap">
      <table className="table">
        <thead>
          <tr><th>Producto</th><th>Categoría</th><th className="r">Precio</th><th>Existencias</th><th>Estado</th><th className="r">Gestión</th></tr>
        </thead>
        <tbody>
          {productos.map((p) => {
            const e = estado(p)
            return (
              <tr key={p.id} className={p.id === selectedId ? 'selected' : ''} onClick={() => onSelect(p.id)}>
                <td>
                  <div className="prod">
                    <span className="thumb">{p.imagen ? <img src={p.imagen} alt="" /> : <CategoryIcon categoria={p.categoria} />}</span>
                    <div><b>{p.nombre}</b><small>{p.codigo}</small></div>
                  </div>
                </td>
                <td className="muted">{p.categoria}</td>
                <td className="r">{money(p.precio)}</td>
                <td onClick={(ev) => ev.stopPropagation()}>
                  <div className="stepper">
                    <button aria-label="Disminuir" disabled={p.stock === 0} onClick={() => onStep(p.id, -1)}><Minus size={13} /></button>
                    <b>{p.stock}</b>
                    <button aria-label="Aumentar" onClick={() => onStep(p.id, 1)}><Plus size={13} /></button>
                  </div>
                </td>
                <td><span className={`pill ${e}`}>● {ETIQUETA[e]}</span></td>
                <td className="r actions-cell">
                  <button className="icon-btn" aria-label="Editar" onClick={(ev) => { ev.stopPropagation(); onEdit(p.id) }}><Pencil size={15} /></button>
                  <button className="icon-btn danger" aria-label="Eliminar" onClick={(ev) => { ev.stopPropagation(); onDelete(p) }}><Trash2 size={15} /></button>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
      <div className="table-foot">Mostrando {productos.length} de {total} productos</div>
    </div>
  )
}
