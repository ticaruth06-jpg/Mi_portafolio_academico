import { ArrowLeftRight, BarChart3, Boxes, HelpCircle, Layers, ShieldCheck, Tag } from 'lucide-react'

const ITEMS = [
  { id: 'inventario', label: 'Inventario', icon: Boxes },
  { id: 'movimientos', label: 'Movimientos', icon: ArrowLeftRight },
  { id: 'categorias', label: 'Categorías', icon: Tag },
  { id: 'informes', label: 'Informes', icon: BarChart3 },
]

export default function Sidebar({ seccion, totalProductos, totalMovimientos, onNavigate }) {
  const conteo = { inventario: totalProductos, movimientos: totalMovimientos }
  return (
    <aside className="sidebar">
      <div className="brand"><span className="brand-mark"><Layers size={18} /></span><span>folio</span></div>
      <div className="workspace"><small>ESPACIO DE TRABAJO</small><b>Estudio Norte</b></div>
      <p className="nav-label">GESTIÓN</p>
      <nav>
        {ITEMS.map(({ id, label, icon: Icon }) => (
          <button key={id} className={`nav-item ${seccion === id ? 'active' : ''}`} onClick={() => onNavigate(id)}>
            <Icon size={18} /><span>{label}</span>
            {conteo[id] > 0 && <em>{String(conteo[id]).padStart(2, '0')}</em>}
          </button>
        ))}
      </nav>
      <div className="footer-note"><ShieldCheck size={18} /><b>Todo en su lugar.</b><small>Tu inventario, siempre bajo control.</small></div>
      <button className={`help ${seccion === 'ayuda' ? 'on' : ''}`} onClick={() => onNavigate('ayuda')}><HelpCircle size={16} /> Centro de ayuda</button>
      <div className="me"><span className="avatar">LV</span><div><b>Lucía Vega</b><small>Administradora</small></div></div>
    </aside>
  )
}
