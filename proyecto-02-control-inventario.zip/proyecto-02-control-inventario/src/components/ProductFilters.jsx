import { Search } from 'lucide-react'

export default function ProductFilters({ categorias, busqueda, categoria, estadoFiltro, onBusqueda, onCategoria, onEstado }) {
  return (
    <div className="filters">
      <label className="search">
        <Search size={16} />
        <input type="search" placeholder="Buscar por nombre o código…" value={busqueda} onChange={(e) => onBusqueda(e.target.value)} />
      </label>
      <select value={categoria} onChange={(e) => onCategoria(e.target.value)} aria-label="Categoría">
        <option value="">Categoría: todas</option>
        {categorias.map((c) => <option key={c}>{c}</option>)}
      </select>
      <select value={estadoFiltro} onChange={(e) => onEstado(e.target.value)} aria-label="Estado">
        <option value="">Estado: todos</option>
        <option value="disponible">Disponible</option>
        <option value="bajo">Bajo mínimo</option>
        <option value="agotado">Agotado</option>
      </select>
    </div>
  )
}
