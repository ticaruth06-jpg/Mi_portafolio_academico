const GUIAS = [
  ['Registrar un producto', 'En Inventario pulsa «Nuevo producto», completa código, categoría, nombre, precio y stock, y guarda. Puedes subir una foto del producto.'],
  ['Ajustar existencias', 'Usa los botones + y − de la tabla para cambios rápidos, o selecciona un producto y usa «Ajustar existencias» para registrar una entrada o una salida por cantidad.'],
  ['Entender las alertas', 'Un producto queda «Bajo mínimo» cuando su stock es menor que el mínimo definido, y «Agotado» cuando llega a cero. Ambos aparecen en «Necesitan atención».'],
  ['Revisar movimientos', 'Cada cambio de stock queda en Movimientos con fecha, tipo, cantidad y stock resultante. Puedes filtrarlos y exportarlos.'],
  ['Gestionar categorías', 'En Categorías puedes crear, renombrar y eliminar. Al renombrar, los productos se actualizan solos. No se puede eliminar una categoría con productos.'],
  ['Sacar informes', 'En Informes verás el valor por categoría, los productos de mayor valor y la reposición sugerida. «Descargar informe» genera un CSV que abre Excel.'],
]

export default function Ayuda() {
  return (
    <>
      <div className="page-header">
        <div>
          <p className="eyebrow">CENTRO DE AYUDA</p>
          <h1>Todo lo que necesitas saber.</h1>
          <p className="subtitle">Guías cortas para cada parte de Folio. Los datos viven en la memoria del navegador y se pierden al recargar la página.</p>
        </div>
      </div>
      <div className="help-grid">
        {GUIAS.map(([titulo, texto]) => (
          <article className="card" key={titulo}><h3>{titulo}</h3><p>{texto}</p></article>
        ))}
      </div>
    </>
  )
}
