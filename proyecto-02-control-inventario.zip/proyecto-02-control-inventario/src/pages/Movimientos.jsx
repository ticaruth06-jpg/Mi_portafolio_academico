import { useMemo, useState } from 'react'
import { ArrowDownToLine, ArrowUpFromLine, Download, ListChecks, Search } from 'lucide-react'
import { descargarCSV, fechaHora } from '../utils/inventory.js'

export default function Movimientos({ movimientos }) {
  const [busqueda, setBusqueda] = useState('')
  const [tipo, setTipo] = useState('')

  const visibles = useMemo(() => {
    const q = busqueda.trim().toLowerCase()
    return movimientos.filter((m) => (!tipo || m.tipo === tipo) && (!q || `${m.nombre} ${m.codigo}`.toLowerCase().includes(q)))
  }, [movimientos, busqueda, tipo])

  const suma = (t) => movimientos.filter((m) => m.tipo === t).reduce((acc, m) => acc + m.cantidad, 0)

  return (
    <>
      <div className="page-header">
        <div>
          <p className="eyebrow">CONTROL DE INVENTARIO / 02</p>
          <h1>Cada movimiento, a la vista.</h1>
          <p className="subtitle">Entradas y salidas de existencias, en el orden en que ocurrieron.</p>
        </div>
        <div className="actions">
          <button className="btn" disabled={visibles.length === 0}
            onClick={() => descargarCSV('movimientos.csv', [['Fecha', 'Código', 'Producto', 'Tipo', 'Cantidad', 'Stock resultante', 'Origen'],
              ...visibles.map((m) => [fechaHora(m.fecha), m.codigo, m.nombre, m.tipo, m.cantidad, m.stockFinal, m.origen])])}>
            <Download size={16} /> Exportar
          </button>
        </div>
      </div>

      <div className="stats three-up">
        <div className="card stat"><div className="stat-top"><span>Movimientos registrados</span><ListChecks size={18} /></div><strong>{String(movimientos.length).padStart(2, '0')}</strong><small>Desde que abriste la aplicación</small></div>
        <div className="card stat"><div className="stat-top"><span>Unidades que entraron</span><ArrowDownToLine size={18} /></div><strong>{suma('entrada')}</strong><small>Entradas y reposiciones</small></div>
        <div className="card stat"><div className="stat-top"><span>Unidades que salieron</span><ArrowUpFromLine size={18} /></div><strong>{suma('salida')}</strong><small>Salidas y ventas</small></div>
      </div>

      <section className="card">
        <div className="card-head"><h3>Historial <span className="chip">{visibles.length} registros</span></h3></div>
        <div className="filters two-cols">
          <label className="search"><Search size={16} />
            <input type="search" placeholder="Buscar por producto o código…" value={busqueda} onChange={(e) => setBusqueda(e.target.value)} /></label>
          <select value={tipo} onChange={(e) => setTipo(e.target.value)} aria-label="Tipo de movimiento">
            <option value="">Tipo: todos</option><option value="entrada">Entradas</option><option value="salida">Salidas</option>
          </select>
        </div>
        {movimientos.length === 0
          ? <p className="empty">Aún no hay movimientos. Ajusta existencias desde Inventario (botones +/− o «Ajustar existencias») y aparecerán aquí.</p>
          : visibles.length === 0
            ? <p className="empty">Ningún movimiento coincide con esos filtros.</p>
            : <div className="table-wrap">
              <table className="table static">
                <thead><tr><th>Fecha y hora</th><th>Producto</th><th>Tipo</th><th className="r">Cantidad</th><th className="r">Stock resultante</th><th>Origen</th></tr></thead>
                <tbody>
                  {visibles.map((m) => (
                    <tr key={m.id}>
                      <td className="muted">{fechaHora(m.fecha)}</td>
                      <td><div className="prod"><div><b>{m.nombre}</b><small>{m.codigo}</small></div></div></td>
                      <td><span className={`pill ${m.tipo === 'entrada' ? 'disponible' : 'bajo'}`}>● {m.tipo === 'entrada' ? 'Entrada' : 'Salida'}</span></td>
                      <td className="r"><b>{m.tipo === 'entrada' ? '+' : '−'}{m.cantidad}</b></td>
                      <td className="r">{m.stockFinal}</td>
                      <td className="muted">{m.origen}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>}
      </section>
    </>
  )
}
