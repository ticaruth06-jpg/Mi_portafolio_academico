import { useMemo, useState } from 'react'
import { CircleAlert, Plus, Download, ArrowUpRight } from 'lucide-react'
import InventorySummary from '../components/InventorySummary.jsx'
import ProductFilters from '../components/ProductFilters.jsx'
import ProductTable from '../components/ProductTable.jsx'
import StockControl from '../components/StockControl.jsx'
import { descargarCSV, estado, requierenAtencion } from '../utils/inventory.js'

export default function Inventario({ categorias, productos, selectedId, onSelect, onStep, onAdjust, onNew, onEdit, onDelete }) {
  const [busqueda, setBusqueda] = useState('')
  const [categoria, setCategoria] = useState('')
  const [estadoFiltro, setEstadoFiltro] = useState('')

  // RF04 + RF05: filter() combina búsqueda, categoría y estado.
  const visibles = useMemo(() => {
    const q = busqueda.trim().toLowerCase()
    return productos.filter((p) =>
      (!q || `${p.nombre} ${p.codigo}`.toLowerCase().includes(q)) &&
      (!categoria || p.categoria === categoria) &&
      (!estadoFiltro || estado(p) === estadoFiltro))
  }, [productos, busqueda, categoria, estadoFiltro])

  const alertas = requierenAtencion(productos)
  const seleccionado = productos.find((p) => p.id === selectedId) ?? null

  const exportar = () =>
    descargarCSV('inventario.csv', [['Código', 'Producto', 'Categoría', 'Precio (S/)', 'Stock', 'Stock mínimo'], ...productos.map((p) => [p.codigo, p.nombre, p.categoria, p.precio, p.stock, p.minimo])])

  return (
    <>
      <div className="page-header">
        <div>
          <p className="eyebrow">CONTROL DE INVENTARIO / 01</p>
          <h1>Cada producto, en orden.</h1>
          <p className="subtitle">Una visión clara de tus existencias y de lo que necesita atención.</p>
        </div>
        <div className="actions">
          <button className="btn" onClick={exportar}><Download size={16} /> Exportar</button>
          <button className="btn primary" onClick={onNew}><Plus size={16} /> Nuevo producto</button>
        </div>
      </div>

      <InventorySummary productos={productos} />

      <div className="split">
        <section className="card">
          <div className="card-head"><h3>Productos <span className="chip">{productos.length} registros</span></h3><small className="muted">Precios en soles (S/)</small></div>
          <ProductFilters categorias={categorias} busqueda={busqueda} categoria={categoria} estadoFiltro={estadoFiltro}
            onBusqueda={setBusqueda} onCategoria={setCategoria} onEstado={setEstadoFiltro} />
          <ProductTable productos={visibles} total={productos.length} selectedId={selectedId}
            onSelect={onSelect} onStep={onStep} onEdit={onEdit} onDelete={onDelete} />
        </section>

        <div className="side-col">
          <section className="card attention">
            <div className="card-head"><h3>Necesitan atención</h3><CircleAlert size={18} className="warn" /></div>
            {alertas.length === 0
              ? <p className="empty">Todo el inventario está por encima del mínimo.</p>
              : <>
                <small className="muted">{alertas.length} productos han alcanzado su nivel mínimo de existencias.</small>
                <ul>
                  {alertas.map((p) => (
                    <li key={p.id}><button onClick={() => onSelect(p.id)}>
                      <span><b>{p.nombre}</b><small><i className={estado(p) === 'agotado' ? 'neg' : 'warn'}>{p.stock} disponibles</i> / mínimo {p.minimo}</small></span>
                      <ArrowUpRight size={14} />
                    </button></li>
                  ))}
                </ul>
              </>}
          </section>
          <StockControl producto={seleccionado} onApply={onAdjust} />
        </div>
      </div>
    </>
  )
}
