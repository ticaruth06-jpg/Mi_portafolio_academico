import { useState } from 'react'
import { Check, Pencil, Plus, Trash2, X } from 'lucide-react'
import { money, unidades, valorTotal } from '../utils/inventory.js'

export default function Categorias({ categorias, productos, onAdd, onRename, onDelete }) {
  const [nueva, setNueva] = useState('')
  const [error, setError] = useState('')
  const [editando, setEditando] = useState(null) // { original, valor }
  const [errorEdicion, setErrorEdicion] = useState('')

  const agregar = (e) => {
    e.preventDefault()
    const msg = onAdd(nueva)
    setError(msg ?? '')
    if (!msg) setNueva('')
  }

  const guardarNombre = () => {
    const msg = onRename(editando.original, editando.valor)
    setErrorEdicion(msg ?? '')
    if (!msg) setEditando(null)
  }

  return (
    <>
      <div className="page-header">
        <div>
          <p className="eyebrow">CONTROL DE INVENTARIO / 03</p>
          <h1>Todo en su categoría.</h1>
          <p className="subtitle">Organiza el catálogo. Una categoría con productos no se puede eliminar.</p>
        </div>
      </div>

      <form className="card cat-add" onSubmit={agregar} noValidate>
        <label className="field"><span>Nueva categoría</span>
          <input value={nueva} onChange={(e) => { setNueva(e.target.value); setError('') }} placeholder="Ej. Mobiliario" maxLength={30} /></label>
        <button className="btn primary" type="submit"><Plus size={16} /> Agregar categoría</button>
        {error && <em className="error">{error}</em>}
      </form>

      <section className="card">
        <div className="card-head"><h3>Categorías <span className="chip">{categorias.length}</span></h3></div>
        {errorEdicion && <em className="error">{errorEdicion}</em>}
        <div className="table-wrap">
          <table className="table static">
            <thead><tr><th>Categoría</th><th className="r">Productos</th><th className="r">Unidades</th><th className="r">Valor en inventario</th><th className="r">Gestión</th></tr></thead>
            <tbody>
              {categorias.map((c) => {
                const lista = productos.filter((p) => p.categoria === c)
                const enEdicion = editando?.original === c
                return (
                  <tr key={c}>
                    <td>
                      {enEdicion
                        ? <input className="inline-input" autoFocus value={editando.valor} maxLength={30}
                            onChange={(e) => setEditando({ ...editando, valor: e.target.value })}
                            onKeyDown={(e) => { if (e.key === 'Enter') guardarNombre(); if (e.key === 'Escape') setEditando(null) }} />
                        : <b>{c}</b>}
                    </td>
                    <td className="r">{lista.length}</td>
                    <td className="r">{unidades(lista)}</td>
                    <td className="r">{money(valorTotal(lista))}</td>
                    <td className="r actions-cell">
                      {enEdicion ? (
                        <>
                          <button className="icon-btn" aria-label="Guardar nombre" onClick={guardarNombre}><Check size={15} /></button>
                          <button className="icon-btn" aria-label="Cancelar" onClick={() => { setEditando(null); setErrorEdicion('') }}><X size={15} /></button>
                        </>
                      ) : (
                        <>
                          <button className="icon-btn" aria-label={`Renombrar ${c}`} onClick={() => { setEditando({ original: c, valor: c }); setErrorEdicion('') }}><Pencil size={15} /></button>
                          <button className="icon-btn danger" aria-label={`Eliminar ${c}`} disabled={lista.length > 0}
                            title={lista.length > 0 ? 'Mueve o elimina sus productos antes de borrarla' : 'Eliminar categoría'}
                            onClick={() => window.confirm(`¿Eliminar la categoría «${c}»?`) && onDelete(c)}><Trash2 size={15} /></button>
                        </>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
        {categorias.length === 0 && <p className="empty">No hay categorías. Agrega la primera para poder registrar productos.</p>}
      </section>
    </>
  )
}
