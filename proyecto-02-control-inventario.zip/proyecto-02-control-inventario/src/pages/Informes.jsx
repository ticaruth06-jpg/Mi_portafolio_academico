import { Download } from 'lucide-react'
import { descargarCSV, estado, ETIQUETA, money, requierenAtencion, unidades, valorTotal } from '../utils/inventory.js'

export default function Informes({ productos, categorias, movimientos }) {
  const total = valorTotal(productos)
  const porCategoria = categorias
    .map((c) => ({ c, valor: valorTotal(productos.filter((p) => p.categoria === c)), uds: unidades(productos.filter((p) => p.categoria === c)) }))
    .sort((a, b) => b.valor - a.valor)
  const masValiosos = [...productos].sort((a, b) => b.precio * b.stock - a.precio * a.stock).slice(0, 5)
  const reposicion = requierenAtencion(productos).map((p) => ({ p, faltan: p.minimo - p.stock, costo: (p.minimo - p.stock) * p.precio }))
  const costoTotal = reposicion.reduce((acc, r) => acc + r.costo, 0)

  const descargar = () =>
    descargarCSV('informe-inventario.csv', [
      ['Código', 'Producto', 'Categoría', 'Precio (S/)', 'Stock', 'Stock mínimo', 'Valor (S/)', 'Estado'],
      ...productos.map((p) => [p.codigo, p.nombre, p.categoria, p.precio, p.stock, p.minimo, (p.precio * p.stock).toFixed(2), ETIQUETA[estado(p)]]),
    ])

  return (
    <>
      <div className="page-header">
        <div>
          <p className="eyebrow">CONTROL DE INVENTARIO / 04</p>
          <h1>Datos para decidir.</h1>
          <p className="subtitle">Valor, rotación y reposición de tu inventario en una sola mirada.</p>
        </div>
        <div className="actions"><button className="btn primary" onClick={descargar}><Download size={16} /> Descargar informe</button></div>
      </div>

      <div className="stats">
        <div className="card stat dark"><div className="stat-top"><span>Valor total del inventario</span></div><strong>{money(total)}</strong><small>Precio unitario × existencias</small></div>
        <div className="card stat"><div className="stat-top"><span>Productos</span></div><strong>{String(productos.length).padStart(2, '0')}</strong><small>En {categorias.length} categorías</small></div>
        <div className="card stat"><div className="stat-top"><span>Unidades en almacén</span></div><strong>{unidades(productos)}</strong><small>{movimientos.length} movimientos en esta sesión</small></div>
        <div className="card stat"><div className="stat-top"><span>Costo de reposición</span></div><strong>{money(costoTotal)}</strong><small>Para llegar al stock mínimo</small></div>
      </div>

      <div className="report-grid">
        <section className="card">
          <h3>Valor por categoría</h3><small className="muted">Participación sobre el valor total</small>
          <ul className="bars">
            {porCategoria.map(({ c, valor, uds }) => (
              <li key={c}>
                <div className="between"><span>{c} <small>· {uds} uds.</small></span><b>{money(valor)}</b></div>
                <div className="track"><i style={{ width: `${total ? (valor / total) * 100 : 0}%` }} /></div>
              </li>
            ))}
          </ul>
        </section>

        <section className="card">
          <h3>Productos de mayor valor</h3><small className="muted">Precio × existencias</small>
          <ol className="top-list">
            {masValiosos.map((p) => (
              <li key={p.id}><span><b>{p.nombre}</b><small>{p.codigo} · {p.stock} uds.</small></span><b>{money(p.precio * p.stock)}</b></li>
            ))}
          </ol>
        </section>

        <section className="card wide">
          <h3>Reposición sugerida</h3><small className="muted">Productos por debajo de su stock mínimo</small>
          {reposicion.length === 0
            ? <p className="empty">Todo el inventario está por encima del mínimo. No hace falta reponer.</p>
            : <div className="table-wrap"><table className="table static">
              <thead><tr><th>Producto</th><th>Estado</th><th className="r">Stock</th><th className="r">Mínimo</th><th className="r">Reponer</th><th className="r">Costo estimado</th></tr></thead>
              <tbody>{reposicion.map(({ p, faltan, costo }) => (
                <tr key={p.id}><td><b>{p.nombre}</b><small className="block">{p.codigo}</small></td>
                  <td><span className={`pill ${estado(p)}`}>● {ETIQUETA[estado(p)]}</span></td>
                  <td className="r">{p.stock}</td><td className="r">{p.minimo}</td><td className="r"><b>{faltan}</b></td><td className="r">{money(costo)}</td></tr>
              ))}</tbody></table></div>}
        </section>
      </div>
    </>
  )
}
