import { useState } from 'react'
import { ArrowLeft, Check } from 'lucide-react'
import Sidebar from './components/Sidebar.jsx'
import ProductForm from './components/ProductForm.jsx'
import Inventario from './pages/Inventario.jsx'
import Movimientos from './pages/Movimientos.jsx'
import Categorias from './pages/Categorias.jsx'
import Informes from './pages/Informes.jsx'
import Ayuda from './pages/Ayuda.jsx'
import { initialProducts } from './data/initialProducts.js'
import { CATEGORIAS_INICIALES } from './utils/inventory.js'

const TITULOS = { inventario: 'Inventario', movimientos: 'Movimientos', categorias: 'Categorías', informes: 'Informes', ayuda: 'Centro de ayuda' }

export default function App() {
  // Estado principal: todo vive en memoria (se pierde al recargar).
  const [productos, setProductos] = useState(initialProducts)
  const [categorias, setCategorias] = useState(CATEGORIAS_INICIALES)
  const [movimientos, setMovimientos] = useState([])
  const [vista, setVista] = useState({ nombre: 'inventario' }) // nombre: inventario | form | movimientos | categorias | informes | ayuda
  const [selectedId, setSelectedId] = useState(3)
  const hora = new Date().toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit' })

  const anotar = (p, tipo, cantidad, stockFinal, origen) =>
    setMovimientos((prev) => [{ id: `${Date.now()}-${Math.random()}`, fecha: new Date(), productoId: p.id, codigo: p.codigo, nombre: p.nombre, tipo, cantidad, stockFinal, origen }, ...prev])

  // RF06: cambia solo el stock (map sin mutar), nunca baja de 0 (RNF03) y deja un movimiento.
  const cambiarStock = (id, delta, origen) => {
    const p = productos.find((x) => x.id === id)
    if (!p) return
    const nuevo = Math.max(0, p.stock + delta)
    const real = nuevo - p.stock
    if (real === 0) return
    setProductos((prev) => prev.map((x) => (x.id === id ? { ...x, stock: nuevo, editado: new Date() } : x)))
    anotar(p, real > 0 ? 'entrada' : 'salida', Math.abs(real), nuevo, origen)
  }

  const guardar = (data) => {
    const ahora = new Date()
    if (vista.id) {
      const previo = productos.find((p) => p.id === vista.id)
      setProductos((prev) => prev.map((p) => (p.id === vista.id ? { ...p, ...data, editado: ahora } : p)))
      if (previo && data.stock !== previo.stock) {
        const dif = data.stock - previo.stock
        anotar({ ...previo, ...data }, dif > 0 ? 'entrada' : 'salida', Math.abs(dif), data.stock, 'Edición de producto')
      }
    } else {
      const nuevo = { id: Date.now(), ...data, creado: ahora, editado: ahora }
      setProductos((prev) => [...prev, nuevo])
      setSelectedId(nuevo.id)
      if (data.stock > 0) anotar(nuevo, 'entrada', data.stock, data.stock, 'Stock inicial')
    }
    setVista({ nombre: 'inventario' })
  }

  const eliminar = (p) => {
    if (!window.confirm(`¿Eliminar "${p.nombre}" del inventario?`)) return
    setProductos((prev) => prev.filter((x) => x.id !== p.id))
    if (selectedId === p.id) setSelectedId(null)
    setVista({ nombre: 'inventario' })
  }

  // Categorías: devuelven un mensaje de error (o null si todo salió bien).
  const existe = (nombre, excepto) => categorias.some((c) => c.toLowerCase() === nombre.toLowerCase() && c !== excepto)
  const agregarCategoria = (texto) => {
    const nombre = texto.trim()
    if (!nombre) return 'Escribe el nombre de la categoría.'
    if (existe(nombre)) return 'Esa categoría ya existe.'
    setCategorias((prev) => [...prev, nombre])
    return null
  }
  const renombrarCategoria = (original, texto) => {
    const nombre = texto.trim()
    if (!nombre) return 'El nombre no puede quedar vacío.'
    if (existe(nombre, original)) return 'Ya existe una categoría con ese nombre.'
    setCategorias((prev) => prev.map((c) => (c === original ? nombre : c)))
    setProductos((prev) => prev.map((p) => (p.categoria === original ? { ...p, categoria: nombre } : p)))
    return null
  }
  const eliminarCategoria = (nombre) => {
    if (productos.some((p) => p.categoria === nombre)) return
    setCategorias((prev) => prev.filter((c) => c !== nombre))
  }

  const ir = (nombre) => setVista({ nombre })
  const enForm = vista.nombre === 'form'
  const seccion = enForm ? 'inventario' : vista.nombre
  const editando = enForm && vista.id ? productos.find((p) => p.id === vista.id) : null

  return (
    <div className="shell">
      <Sidebar seccion={seccion} totalProductos={productos.length} totalMovimientos={movimientos.length} onNavigate={ir} />
      <div className="main">
        <header className="topbar">
          <nav className="crumbs">
            <span>Gestión</span><span>/</span>
            {enForm
              ? <><button className="crumb-link" onClick={() => ir('inventario')}>Inventario</button><span>/</span><b>{editando ? 'Editar producto' : 'Nuevo producto'}</b></>
              : <b>{TITULOS[seccion]}</b>}
          </nav>
          <small className="live">● Actualizado a las {hora}</small>
        </header>
        <main className="content">
          {vista.nombre === 'inventario' && (
            <Inventario categorias={categorias} productos={productos} selectedId={selectedId} onSelect={setSelectedId}
              onStep={(id, d) => cambiarStock(id, d, 'Ajuste rápido')} onAdjust={(id, d) => cambiarStock(id, d, 'Ajuste de existencias')}
              onNew={() => setVista({ nombre: 'form', id: null })} onEdit={(id) => setVista({ nombre: 'form', id })} onDelete={eliminar} />
          )}
          {vista.nombre === 'movimientos' && <Movimientos movimientos={movimientos} />}
          {vista.nombre === 'categorias' && (
            <Categorias categorias={categorias} productos={productos} onAdd={agregarCategoria} onRename={renombrarCategoria} onDelete={eliminarCategoria} />
          )}
          {vista.nombre === 'informes' && <Informes productos={productos} categorias={categorias} movimientos={movimientos} />}
          {vista.nombre === 'ayuda' && <Ayuda />}
          {enForm && (
            <>
              <button className="back" onClick={() => ir('inventario')}><ArrowLeft size={15} /> Volver al inventario</button>
              <div className="page-header">
                <div>
                  <p className="eyebrow">CATÁLOGO / {editando?.codigo ?? 'NUEVO'} <span className="chip">{editando ? 'Edición' : 'Registro'}</span></p>
                  <h1>{editando ? 'Editar producto' : 'Nuevo producto'}</h1>
                  <p className="subtitle">Cuida los detalles. Un inventario preciso empieza aquí.</p>
                </div>
                <div className="actions">
                  <button type="button" className="btn" onClick={() => ir('inventario')}>Cancelar</button>
                  <button type="submit" form="producto-form" className="btn primary"><Check size={16} /> Guardar cambios</button>
                </div>
              </div>
              <ProductForm key={vista.id ?? 'nuevo'} producto={editando} productos={productos} categorias={categorias} onSave={guardar} onDelete={eliminar} />
            </>
          )}
        </main>
      </div>
    </div>
  )
}
