// Moneda: soles peruanos (PEN). Formato: S/ 5,894.00
const pen = new Intl.NumberFormat('es-PE', { style: 'currency', currency: 'PEN', minimumFractionDigits: 2, useGrouping: 'always' })
export const money = (n) => pen.format(n)

export const CATEGORIAS_INICIALES = ['Papelería', 'Organización', 'Iluminación', 'Decoración']

// Estado derivado del stock (RF07 / RNF04).
export const estado = (p) => (p.stock === 0 ? 'agotado' : p.stock < p.minimo ? 'bajo' : 'disponible')
export const ETIQUETA = { disponible: 'Disponible', bajo: 'Bajo mínimo', agotado: 'Agotado' }

// RF08: valor total = suma de precio × existencias, con reduce().
export const valorTotal = (productos) => productos.reduce((acc, p) => acc + p.precio * p.stock, 0)
export const unidades = (productos) => productos.reduce((acc, p) => acc + p.stock, 0)
export const requierenAtencion = (productos) => productos.filter((p) => estado(p) !== 'disponible')

export const fechaHora = (d) =>
  d.toLocaleString('es-PE', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }).replace(/\./g, '')

// Descarga un CSV (con BOM para que Excel respete las tildes).
export const descargarCSV = (nombre, filas) => {
  const celda = (v) => `"${String(v).replace(/"/g, '""')}"`
  const texto = '\ufeff' + filas.map((f) => f.map(celda).join(',')).join('\n')
  const url = URL.createObjectURL(new Blob([texto], { type: 'text/csv;charset=utf-8' }))
  const a = Object.assign(document.createElement('a'), { href: url, download: nombre })
  a.click()
  URL.revokeObjectURL(url)
}
