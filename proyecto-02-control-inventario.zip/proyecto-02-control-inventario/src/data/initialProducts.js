const hace = (dias, h = 10, m = 0) => { const d = new Date(); d.setDate(d.getDate() - dias); d.setHours(h, m, 0, 0); return d }

export const initialProducts = [
  { id: 1, codigo: 'PAP-001', nombre: 'Cuaderno de puntos', categoria: 'Papelería', precio: 18, stock: 48, minimo: 10, descripcion: 'Cuaderno de tapa dura con papel de puntos de 120 g.', creado: hace(30), editado: hace(30) },
  { id: 2, codigo: 'ORG-002', nombre: 'Organizador modular', categoria: 'Organización', precio: 65, stock: 24, minimo: 8, descripcion: 'Organizador apilable para escritorio.', creado: hace(30), editado: hace(30) },
  { id: 3, codigo: 'ILU-003', nombre: 'Lámpara lineal', categoria: 'Iluminación', precio: 220, stock: 6, minimo: 10, descripcion: 'Lámpara de escritorio de aluminio con acabado grafito. Luz cálida regulable y brazo orientable para espacios de trabajo.', imagen: '/img/lampara.jpg', creado: hace(26), editado: hace(0, 9, 15) },
  { id: 4, codigo: 'DEC-004', nombre: 'Jarrón de cerámica', categoria: 'Decoración', precio: 85, stock: 0, minimo: 5, descripcion: 'Jarrón artesanal esmaltado a mano.', imagen: '/img/jarron.jpg', creado: hace(25), editado: hace(2) },
  { id: 5, codigo: 'PAP-005', nombre: 'Bolígrafo de aluminio', categoria: 'Papelería', precio: 12, stock: 32, minimo: 10, descripcion: 'Bolígrafo recargable con cuerpo de aluminio.', creado: hace(24), editado: hace(24) },
  { id: 6, codigo: 'ORG-006', nombre: 'Bandeja de escritorio', categoria: 'Organización', precio: 55, stock: 18, minimo: 6, descripcion: 'Bandeja para documentos de formato A4.', imagen: '/img/bandeja.jpg', creado: hace(20), editado: hace(20) },
  { id: 7, codigo: 'DEC-007', nombre: 'Reloj de sobremesa', categoria: 'Decoración', precio: 120, stock: 4, minimo: 8, descripcion: 'Reloj silencioso de sobremesa.', creado: hace(18), editado: hace(3) },
  { id: 8, codigo: 'PAP-008', nombre: 'Agenda semanal', categoria: 'Papelería', precio: 25, stock: 12, minimo: 6, descripcion: 'Agenda con vista semanal y cierre elástico.', creado: hace(10), editado: hace(10) },
]
