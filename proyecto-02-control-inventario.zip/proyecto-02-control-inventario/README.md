# proyecto-02-control-inventario

Aplicación React + Vite (JavaScript y CSS3). Los datos viven en memoria: se conservan mientras la app está abierta y se pierden al recargar.

## Ejecutar

```bash
npm install
npm run dev
```

Abre la dirección que muestra la terminal (normalmente http://localhost:5173).
